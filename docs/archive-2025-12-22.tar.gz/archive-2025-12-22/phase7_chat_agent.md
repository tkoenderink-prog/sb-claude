# Phase 7: Chat Interface + Agent Mode

**Status:** IMPLEMENTED (2025-12-20)
**Dependencies:** Phases 1-6 (all complete)
**Scope:** Major feature addition - Complete

---

## 1. Overview

Phase 7 adds a comprehensive chat interface with three distinct modes:

1. **Quick Chat** - Direct API calls to LLM providers (Claude, GPT-4) without tools
2. **Tool-Enabled Chat** - Single provider with access to all Phase 1-6 data via tools
3. **Agent Mode** - Claude Agent SDK for autonomous multi-step tasks with subagents

This phase fully leverages all infrastructure built in Phases 1-6.

---

## 2. Phase 1-6 Integration Map

| Phase | What Exists | How Chat Uses It |
|-------|-------------|------------------|
| 1 | Job system, SSE streaming, PostgreSQL | Chat uses same SSE patterns; sessions stored in DB |
| 2 | Processor framework, LockManager | Agent can trigger processor runs |
| 3 | Calendar data (15,688 events) | Tools: `get_today_events`, `get_week_events`, `search_events` |
| 4 | Tasks data (2,232 tasks) | Tools: `get_overdue_tasks`, `get_today_tasks`, `query_tasks` |
| 5 | RAG/Embeddings (8,512 chunks) | Tools: `semantic_search`, `text_search`, `read_file` |
| 6 | Skills system (38 skills) | Attach skills to conversation context |

### Existing API Endpoints Available as Tools

```
Calendar (Phase 3):
  GET /calendar/today        → get_today_events()
  GET /calendar/week         → get_week_events()
  GET /calendar/range        → get_events_in_range(start, end)
  GET /calendar/status       → get_calendar_status()

Tasks (Phase 4):
  GET /tasks/overdue         → get_overdue_tasks()
  GET /tasks/today           → get_today_tasks()
  GET /tasks/week            → get_week_tasks()
  GET /tasks/query           → query_tasks(status, priority, tag)
  GET /tasks/by-project      → get_tasks_by_project()
  GET /tasks/status          → get_tasks_status()

Vault/RAG (Phase 5):
  POST /vault/search         → semantic_search(query, filters)
  GET /vault/read            → read_vault_file(path)
  GET /vault/list            → list_vault_directory(path)
  GET /vault/search/status   → get_search_status()

Skills (Phase 6):
  GET /skills                → list_skills(source)
  GET /skills/{id}           → get_skill(id)
  POST /skills/search        → search_skills(query)

Processors (Phase 2):
  GET /processors            → list_processors()
  POST /processors/run       → run_processor(name)
```

---

## 3. Chat Modes Specification

### 3.1 Quick Chat Mode

**Purpose:** Fast, simple conversations without data access.

**Characteristics:**
- No tools enabled
- Minimal latency
- Any provider (Claude, GPT-4, etc.)
- Good for: brainstorming, explanations, general questions

**Use Case Example:**
> "Explain the difference between semantic and keyword search"

### 3.2 Tool-Enabled Mode

**Purpose:** Conversational access to all Second Brain data.

**Characteristics:**
- Full tool access to Phases 1-6 data
- Single-turn tool use (ask → tool → response)
- Provider must support function calling
- Good for: calendar queries, task lookup, vault search

**Use Case Example:**
> "What's on my calendar today and do I have any overdue tasks?"

**Tool Execution Flow:**
```
User: "What meetings do I have today?"
     ↓
Assistant decides to call tool
     ↓
[Tool Call: get_today_events()]
     ↓
[Tool Result: 3 events returned]
     ↓
Assistant: "You have 3 meetings today: ..."
```

### 3.3 Agent Mode

**Purpose:** Autonomous multi-step tasks with complex reasoning.

**Characteristics:**
- Claude Agent SDK (Anthropic only)
- Multi-turn autonomous operation
- Can spawn subagents for specialized tasks
- Produces artifacts (reports, analyses)
- Good for: complex analysis, synthesis, planning

**Use Case Example:**
> "Analyze my week: look at my calendar, identify overdue tasks, search my notes for relevant context, and create a prioritized action plan"

**Agent Execution Flow:**
```
User: "Analyze my productivity this week"
     ↓
Agent: [Thinking] I need calendar, tasks, and journal data
     ↓
Agent: [Tool Call: get_week_events()]
Agent: [Tool Call: get_week_tasks()]
Agent: [Tool Call: semantic_search("productivity journal")]
     ↓
Agent: [Subagent: TaskAnalyst] Prioritizing tasks...
     ↓
Agent: [Artifact Created: weekly_analysis.md]
     ↓
Assistant: "Here's your weekly productivity analysis..."
```

---

## 4. Provider Support

### 4.1 Anthropic Claude

**Models:**
- `claude-opus-4` - Most capable, best for agent mode
- `claude-sonnet-4` - Balanced performance/cost
- `claude-haiku-3.5` - Fast, cost-effective

**Features:**
- Full tool use support
- Extended thinking (for complex reasoning)
- Agent SDK for autonomous operation

### 4.2 OpenAI GPT

**Models:**
- `gpt-4-turbo` - Most capable
- `gpt-4o` - Optimized, multimodal
- `gpt-4o-mini` - Fast, cost-effective

**Features:**
- Function calling
- Parallel tool use

### 4.3 Future: Local Models

**Planned:**
- Ollama integration for local inference
- Models: llama3, mistral, etc.

---

## 5. Tool Definitions

### 5.1 Calendar Tools

```python
@tool
def get_today_events() -> List[CalendarEvent]:
    """Get all calendar events for today."""

@tool
def get_week_events() -> List[CalendarEvent]:
    """Get calendar events for the next 7 days."""

@tool
def get_events_in_range(start: date, end: date) -> List[CalendarEvent]:
    """Get calendar events within a specific date range."""

@tool
def search_events(query: str) -> List[CalendarEvent]:
    """Search calendar events by title or description."""
```

### 5.2 Tasks Tools

```python
@tool
def get_overdue_tasks() -> List[Task]:
    """Get all tasks that are past their due date."""

@tool
def get_today_tasks() -> List[Task]:
    """Get tasks due today."""

@tool
def get_week_tasks() -> List[Task]:
    """Get tasks due in the next 7 days."""

@tool
def query_tasks(
    status: Optional[str] = None,
    priority: Optional[str] = None,
    tag: Optional[str] = None
) -> List[Task]:
    """Query tasks with optional filters."""

@tool
def get_tasks_by_project() -> Dict[str, List[Task]]:
    """Get tasks grouped by project/folder."""
```

### 5.3 Vault/RAG Tools

```python
@tool
def semantic_search(
    query: str,
    limit: int = 10,
    category: Optional[str] = None,
    tags: Optional[List[str]] = None
) -> List[SearchResult]:
    """Search vault using semantic similarity."""

@tool
def text_search(query: str, path: Optional[str] = None) -> List[SearchResult]:
    """Search vault using exact text matching (ripgrep)."""

@tool
def read_vault_file(path: str) -> VaultFile:
    """Read a specific file from the vault."""

@tool
def list_vault_directory(path: str = "") -> List[VaultEntry]:
    """List contents of a vault directory."""
```

### 5.4 Skills Tools

```python
@tool
def list_skills(source: Optional[str] = None) -> List[SkillSummary]:
    """List available skills, optionally filtered by source."""

@tool
def get_skill(skill_id: str) -> SkillDetail:
    """Get full details of a specific skill."""

@tool
def search_skills(query: str) -> List[SkillSummary]:
    """Search skills by name or description."""
```

---

## 6. Data Models

### 6.1 Chat Models

```python
class ChatMode(str, Enum):
    QUICK = "quick"
    TOOLS = "tools"
    AGENT = "agent"

class ChatMessage(BaseModel):
    id: str
    role: Literal["user", "assistant", "system", "tool"]
    content: str
    timestamp: datetime
    tool_calls: Optional[List[ToolCall]] = None
    tool_results: Optional[List[ToolResult]] = None
    file_refs: Optional[List[FileRef]] = None

class ChatSession(BaseModel):
    id: str
    mode: ChatMode
    provider: str
    model: str
    messages: List[ChatMessage]
    attached_skills: List[str]
    created_at: datetime
    updated_at: datetime

class ToolCall(BaseModel):
    id: str
    tool: str
    arguments: Dict[str, Any]
    status: Literal["pending", "success", "error"]

class ToolResult(BaseModel):
    tool_call_id: str
    result: Any
    error: Optional[str] = None

class FileRef(BaseModel):
    path: str
    obsidian_uri: str
    heading: Optional[str] = None
    score: Optional[float] = None
```

### 6.2 Agent Models

```python
class AgentRun(BaseModel):
    id: str
    task: str
    status: Literal["running", "completed", "failed", "cancelled"]
    started_at: datetime
    ended_at: Optional[datetime]
    turns: int
    tool_calls: int
    artifacts: List[ArtifactRef]
    usage: TokenUsage

class ArtifactRef(BaseModel):
    id: str
    name: str
    type: Literal["report", "analysis", "export", "code", "other"]
    mime_type: str
    size_bytes: int
    download_url: str
    created_at: datetime

class TokenUsage(BaseModel):
    input_tokens: int
    output_tokens: int
    total_tokens: int
    estimated_cost_usd: float
```

### 6.3 SSE Event Types

```python
class ChatEventType(str, Enum):
    TEXT = "text"                # Streamed text content
    TOOL_CALL = "tool_call"      # Tool invocation started
    TOOL_RESULT = "tool_result"  # Tool returned result
    FILE_REF = "file_ref"        # File reference/citation
    ARTIFACT = "artifact"        # Artifact created (agent mode)
    THINKING = "thinking"        # Agent thinking (optional, agent mode)
    ERROR = "error"              # Error occurred
    USAGE = "usage"              # Token usage stats
    DONE = "done"                # Stream complete

class ChatEvent(BaseModel):
    type: ChatEventType
    data: Any
    timestamp: datetime
```

---

## 7. API Endpoints

### 7.1 Chat Endpoints

```
POST /chat
  Description: Send message and get streaming response
  Request: {
    mode: "quick" | "tools" | "agent",
    provider: "anthropic" | "openai",
    model: string,
    messages: ChatMessage[],
    attached_skills: string[],
    session_id: string | null
  }
  Response: SSE stream of ChatEvent

GET /chat/sessions
  Description: List chat sessions
  Response: ChatSession[]

GET /chat/sessions/{id}
  Description: Get session with full history
  Response: ChatSession

DELETE /chat/sessions/{id}
  Description: Delete session
  Response: { success: true }

GET /chat/providers
  Description: List available providers and models
  Response: {
    providers: [{
      id: string,
      name: string,
      models: [{ id: string, name: string, capabilities: string[] }]
    }]
  }
```

### 7.2 Agent Endpoints

```
POST /agent/run
  Description: Start autonomous agent task
  Request: {
    task: string,
    context: string | null,
    tools: string[] | null,  # null = all tools
    max_turns: int = 10,
    attached_skills: string[]
  }
  Response: SSE stream of AgentEvent

GET /agent/runs
  Description: List agent runs
  Response: AgentRun[]

GET /agent/runs/{id}
  Description: Get agent run details
  Response: AgentRun

GET /agent/runs/{id}/artifacts
  Description: List artifacts from run
  Response: ArtifactRef[]

GET /agent/runs/{id}/artifacts/{artifact_id}
  Description: Download artifact
  Response: File download

POST /agent/runs/{id}/cancel
  Description: Cancel running agent
  Response: { success: true }
```

---

## 8. Backend Architecture

### 8.1 Directory Structure

```
services/brain_runtime/
  api/
    chat.py              # Chat endpoints
    agent.py             # Agent endpoints
  core/
    providers/
      __init__.py
      base.py            # BaseProvider abstract class
      anthropic.py       # Anthropic Claude adapter
      openai.py          # OpenAI GPT adapter
    tools/
      __init__.py
      registry.py        # Tool registry and discovery
      calendar_tools.py  # Calendar tool implementations
      tasks_tools.py     # Tasks tool implementations
      vault_tools.py     # Vault/RAG tool implementations
      skills_tools.py    # Skills tool implementations
    agent_runtime.py     # Claude Agent SDK wrapper
    conversation.py      # Conversation/session management
  models/
    chat.py              # Chat-related models
    agent.py             # Agent-related models
```

### 8.2 Provider Adapter Pattern

```python
# core/providers/base.py
from abc import ABC, abstractmethod

class BaseProvider(ABC):
    """Abstract base class for LLM providers."""

    @abstractmethod
    async def chat(
        self,
        messages: List[ChatMessage],
        tools: Optional[List[Tool]] = None,
        stream: bool = True
    ) -> AsyncGenerator[ChatEvent, None]:
        """Send chat request and stream response."""
        pass

    @abstractmethod
    def supports_tools(self) -> bool:
        """Whether this provider supports function calling."""
        pass

    @abstractmethod
    def get_models(self) -> List[ModelInfo]:
        """Get available models for this provider."""
        pass
```

### 8.3 Tool Registry

```python
# core/tools/registry.py
class ToolRegistry:
    """Central registry for all chat tools."""

    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        """Register a tool."""
        self._tools[tool.name] = tool

    def get_tool(self, name: str) -> Optional[Tool]:
        """Get tool by name."""
        return self._tools.get(name)

    def get_all_tools(self) -> List[Tool]:
        """Get all registered tools."""
        return list(self._tools.values())

    def get_tools_for_provider(self, provider: str) -> List[Dict]:
        """Get tools in provider-specific format."""
        # Format tools for Anthropic or OpenAI schema
        pass

    async def execute(self, name: str, arguments: Dict) -> Any:
        """Execute a tool and return result."""
        tool = self._tools.get(name)
        if not tool:
            raise ToolNotFoundError(name)
        return await tool.execute(**arguments)
```

---

## 9. Frontend Architecture

### 9.1 Directory Structure

```
apps/web/src/
  app/
    chat/
      page.tsx           # Chat page
      layout.tsx         # Chat layout with sidebar
  components/
    chat/
      ChatContainer.tsx    # Main chat container
      MessageList.tsx      # Scrollable message history
      MessageInput.tsx     # Input textarea with send
      MessageBubble.tsx    # Individual message display
      ModeSelector.tsx     # Quick/Tools/Agent tabs
      ProviderSelector.tsx # Provider and model dropdowns
      ToolCallCard.tsx     # Tool invocation display
      ToolResultCard.tsx   # Tool result display
      FileChip.tsx         # Clickable file reference
      ArtifactCard.tsx     # Artifact with download
      SkillsPanel.tsx      # Skills attachment sidebar
      StreamingText.tsx    # Animated streaming text
  hooks/
    useChat.ts           # Chat mutation and session state
    useChatStream.ts     # SSE stream handling
    useProviders.ts      # Provider/model fetching
  lib/
    chat-api.ts          # Chat API functions
```

### 9.2 Key Components

```tsx
// ChatContainer.tsx
export function ChatContainer() {
  const [mode, setMode] = useState<ChatMode>('tools')
  const [provider, setProvider] = useState('anthropic')
  const [model, setModel] = useState('claude-sonnet-4')
  const [attachedSkills, setAttachedSkills] = useState<string[]>([])

  return (
    <div className="flex h-screen">
      {/* Skills sidebar */}
      <SkillsPanel
        attached={attachedSkills}
        onAttach={setAttachedSkills}
      />

      {/* Main chat area */}
      <div className="flex-1 flex flex-col">
        {/* Header with mode/provider selectors */}
        <div className="border-b p-4 flex items-center gap-4">
          <ModeSelector value={mode} onChange={setMode} />
          <ProviderSelector
            provider={provider}
            model={model}
            onProviderChange={setProvider}
            onModelChange={setModel}
          />
        </div>

        {/* Messages */}
        <MessageList messages={messages} />

        {/* Input */}
        <MessageInput onSend={handleSend} disabled={isStreaming} />
      </div>
    </div>
  )
}
```

### 9.3 UI Mockup

```
┌────────────────────────────────────────────────────────────────┐
│ Second Brain Chat                                              │
├──────────┬─────────────────────────────────────────────────────┤
│ Skills   │  [Quick] [Tools] [Agent]     [Claude ▼] [Sonnet ▼] │
│          ├─────────────────────────────────────────────────────┤
│ ☐ when-  │                                                     │
│   stuck  │  ┌─────────────────────────────────────────────┐   │
│          │  │ 🤖 Assistant                                │   │
│ ☐ context│  │ Based on your calendar and tasks, here's   │   │
│   -aware │  │ your day:                                   │   │
│          │  │                                             │   │
│ ☑ vault- │  │ **Meetings (3)**                           │   │
│   weekly │  │ • 9:00 AM - Team Standup                   │   │
│          │  │ • 2:00 PM - 1:1 with Sarah                 │   │
│ ☐ solving│  │ • 4:30 PM - Sprint Planning                │   │
│   -with  │  │                                             │   │
│          │  │ **Overdue Tasks (2)** ⚠️                    │   │
│          │  │ • Review PR #142                           │   │
│          │  │ • Update documentation                     │   │
│          │  │                                             │   │
│          │  │ [📅 calendar] [✓ tasks]                    │   │
│          │  └─────────────────────────────────────────────┘   │
│          │                                                     │
│          │  ┌─────────────────────────────────────────────┐   │
│          │  │ 🔧 get_today_events                         │   │
│          │  │ Found 3 calendar events                     │   │
│          │  └─────────────────────────────────────────────┘   │
│          │                                                     │
│          │  ┌─────────────────────────────────────────────┐   │
│          │  │ 🔧 get_overdue_tasks                        │   │
│          │  │ Found 2 overdue tasks                       │   │
│          │  └─────────────────────────────────────────────┘   │
│          │                                                     │
│          │  ┌─────────────────────────────────────────────┐   │
│          │  │ 👤 You                                      │   │
│          │  │ What should I focus on today?               │   │
│          │  └─────────────────────────────────────────────┘   │
│          ├─────────────────────────────────────────────────────┤
│          │ [Type a message...]                      [Send ➤]  │
└──────────┴─────────────────────────────────────────────────────┘
```

---

## 10. Agent Mode Deep Dive

### 10.1 Claude Agent SDK Integration

```python
# core/agent_runtime.py
from anthropic import Anthropic

class AgentRuntime:
    """Wrapper for Claude Agent SDK."""

    def __init__(self):
        self.client = Anthropic()
        self.tool_registry = ToolRegistry()

    async def run(
        self,
        task: str,
        context: Optional[str] = None,
        tools: Optional[List[str]] = None,
        max_turns: int = 10,
        attached_skills: List[str] = None
    ) -> AsyncGenerator[AgentEvent, None]:
        """Run agent task with streaming."""

        # Build system prompt with attached skills
        system_prompt = self._build_system_prompt(attached_skills)

        # Get tools (all or filtered)
        available_tools = self._get_tools(tools)

        # Run agent loop
        messages = [{"role": "user", "content": task}]

        for turn in range(max_turns):
            # Call Claude with tools
            response = await self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=4096,
                system=system_prompt,
                tools=available_tools,
                messages=messages,
                stream=True
            )

            # Process streaming response
            async for event in response:
                yield self._convert_event(event)

            # Check for tool use
            if response.stop_reason == "tool_use":
                # Execute tools
                tool_results = await self._execute_tools(response.content)
                messages.append({"role": "assistant", "content": response.content})
                messages.append({"role": "user", "content": tool_results})
            else:
                # Agent finished
                break
```

### 10.2 Subagent Patterns

```python
# Subagent definitions for complex tasks
SUBAGENT_PATTERNS = {
    "calendar_analyst": {
        "description": "Analyzes calendar for patterns, conflicts, and suggestions",
        "tools": ["get_today_events", "get_week_events", "get_events_in_range"],
        "prompt": "You are a calendar analyst. Analyze the user's schedule..."
    },
    "task_analyst": {
        "description": "Prioritizes tasks and identifies blockers",
        "tools": ["get_overdue_tasks", "get_today_tasks", "query_tasks"],
        "prompt": "You are a task analyst. Review the user's tasks..."
    },
    "knowledge_searcher": {
        "description": "Deep vault search and synthesis",
        "tools": ["semantic_search", "text_search", "read_vault_file"],
        "prompt": "You are a knowledge searcher. Find relevant information..."
    },
    "journal_analyst": {
        "description": "Analyzes journal entries for patterns",
        "tools": ["semantic_search", "read_vault_file"],
        "prompt": "You are a journal analyst. Look for patterns in journals..."
    }
}
```

### 10.3 Artifact Generation

```python
class ArtifactManager:
    """Manages artifact creation and storage."""

    def __init__(self, storage_path: Path):
        self.storage_path = storage_path

    async def create(
        self,
        name: str,
        content: str,
        artifact_type: str,
        mime_type: str = "text/markdown"
    ) -> ArtifactRef:
        """Create and store an artifact."""
        artifact_id = str(uuid.uuid4())

        # Store to disk
        path = self.storage_path / f"{artifact_id}.md"
        path.write_text(content)

        return ArtifactRef(
            id=artifact_id,
            name=name,
            type=artifact_type,
            mime_type=mime_type,
            size_bytes=len(content.encode()),
            download_url=f"/agent/artifacts/{artifact_id}",
            created_at=datetime.now()
        )
```

---

## 11. Skills Integration

### 11.1 Attaching Skills to Chat

Skills can be attached to a chat session to provide:
- **Context**: Background information about a topic
- **Instructions**: Specific procedures or workflows
- **Triggers**: Conditions when the skill should be applied

```python
def build_system_prompt(attached_skills: List[str]) -> str:
    """Build system prompt with attached skills."""
    base_prompt = """You are a helpful AI assistant with access to the user's
    Second Brain system. You can query their calendar, tasks, and knowledge vault."""

    if not attached_skills:
        return base_prompt

    skills_content = []
    for skill_id in attached_skills:
        skill = get_skill(skill_id)
        if skill:
            skills_content.append(f"""
## Skill: {skill.name}

{skill.content}
""")

    return f"""{base_prompt}

# Attached Skills

The following skills are attached to this conversation. Use them when relevant:

{"".join(skills_content)}
"""
```

### 11.2 Skills UI Panel

```tsx
function SkillsPanel({ attached, onAttach }) {
  const { data: skills } = useQuery(['skills'], fetchSkills)

  return (
    <div className="w-64 border-r p-4">
      <h3 className="font-semibold mb-4">Skills</h3>
      <div className="space-y-2">
        {skills?.map(skill => (
          <label key={skill.id} className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={attached.includes(skill.id)}
              onChange={(e) => {
                if (e.target.checked) {
                  onAttach([...attached, skill.id])
                } else {
                  onAttach(attached.filter(id => id !== skill.id))
                }
              }}
            />
            <span className="text-sm">{skill.name}</span>
          </label>
        ))}
      </div>
    </div>
  )
}
```

---

## 12. Database Schema Additions

```sql
-- Chat sessions table
CREATE TABLE chat_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mode VARCHAR(20) NOT NULL CHECK (mode IN ('quick', 'tools', 'agent')),
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    attached_skills JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Chat messages table
CREATE TABLE chat_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES chat_sessions(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'assistant', 'system', 'tool')),
    content TEXT NOT NULL,
    tool_calls JSONB,
    tool_results JSONB,
    file_refs JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agent runs table
CREATE TABLE agent_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task TEXT NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('running', 'completed', 'failed', 'cancelled')),
    attached_skills JSONB DEFAULT '[]',
    turns INTEGER DEFAULT 0,
    tool_calls INTEGER DEFAULT 0,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    started_at TIMESTAMPTZ DEFAULT NOW(),
    ended_at TIMESTAMPTZ
);

-- Agent artifacts table
CREATE TABLE agent_artifacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id UUID REFERENCES agent_runs(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    size_bytes INTEGER NOT NULL,
    storage_path TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_chat_sessions_created ON chat_sessions(created_at DESC);
CREATE INDEX idx_chat_messages_session ON chat_messages(session_id, created_at);
CREATE INDEX idx_agent_runs_status ON agent_runs(status, started_at DESC);
CREATE INDEX idx_agent_artifacts_run ON agent_artifacts(run_id);
```

---

## 13. Implementation Order

### Step 1: Backend Provider Adapters
1. Create `core/providers/base.py` with abstract provider class
2. Implement `core/providers/anthropic.py` for Claude
3. Implement `core/providers/openai.py` for GPT
4. Add provider discovery endpoint

### Step 2: Tool Registry
1. Create `core/tools/registry.py`
2. Implement calendar tools wrapping existing API
3. Implement tasks tools wrapping existing API
4. Implement vault/RAG tools wrapping existing API
5. Implement skills tools wrapping existing API

### Step 3: Chat Endpoint
1. Create `api/chat.py` with POST /chat
2. Implement SSE streaming for responses
3. Add session management endpoints
4. Wire up tool execution

### Step 4: Frontend Chat Page
1. Create `/chat` page layout
2. Implement MessageList component
3. Implement MessageInput component
4. Add SSE stream handling hook

### Step 5: Mode and Provider Selection
1. Create ModeSelector component
2. Create ProviderSelector component
3. Wire up mode-specific behavior

### Step 6: Tool Visualization
1. Create ToolCallCard component
2. Create ToolResultCard component
3. Create FileChip component

### Step 7: Agent Runtime
1. Create `core/agent_runtime.py` with Claude SDK
2. Implement agent loop with tool execution
3. Add artifact creation and storage
4. Create agent API endpoints

### Step 8: Skills Integration
1. Create SkillsPanel component
2. Wire up skill attachment to system prompt
3. Add skills display in chat header

### Step 9: Testing
1. Unit tests for provider adapters
2. Unit tests for tool registry
3. Integration tests for chat flow
4. E2E tests for full chat experience

---

## 14. Acceptance Criteria (All Verified 2025-12-20)

### 14.1 Quick Chat Mode
- [x] User can select Quick Chat mode
- [x] User can choose provider (Claude/GPT) and model
- [x] Messages stream in real-time
- [x] No tools are available in this mode
- [x] Conversation history persists

### 14.2 Tool-Enabled Mode
- [x] User can select Tool-Enabled mode
- [x] All Phase 1-6 data accessible via tools (18 tools)
- [x] Tool calls displayed as cards (ToolCallCard)
- [x] Tool results shown clearly (ToolResultCard)
- [x] File references are clickable (FileChip with obsidian:// URLs)

### 14.3 Agent Mode
- [x] User can select Agent mode
- [x] Agent runs autonomously for up to N turns
- [x] Agent uses real ToolRegistry (not mocks)
- [x] Artifacts are created and downloadable (ArtifactCard)
- [x] Agent runs can be cancelled
- [x] Token usage is tracked and displayed

### 14.4 Skills Integration
- [x] Skills panel shows all available skills (SkillsPanel)
- [x] Skills can be attached/detached from session
- [x] Attached skills influence system prompt
- [x] Skills state persists per session

### 14.5 General
- [x] All existing E2E tests still pass
- [x] New chat E2E tests created (32 tests in phase7-chat.spec.ts)
- [x] Error handling for provider failures
- [x] Session persistence implemented

---

## 15. E2E Test Scenarios

```typescript
test.describe('Phase 7: Chat Interface', () => {
  test('quick chat mode sends message and receives response', async ({ page }) => {
    await page.goto('/chat')
    await page.click('[data-mode="quick"]')
    await page.fill('[data-input]', 'Hello, world!')
    await page.click('[data-send]')
    await expect(page.locator('[data-message="assistant"]')).toBeVisible()
  })

  test('tool-enabled mode can query calendar', async ({ page }) => {
    await page.goto('/chat')
    await page.click('[data-mode="tools"]')
    await page.fill('[data-input]', 'What is on my calendar today?')
    await page.click('[data-send]')
    await expect(page.locator('[data-tool-call="get_today_events"]')).toBeVisible()
    await expect(page.locator('[data-message="assistant"]')).toContainText('event')
  })

  test('agent mode can create artifacts', async ({ page }) => {
    await page.goto('/chat')
    await page.click('[data-mode="agent"]')
    await page.fill('[data-input]', 'Analyze my week and create a summary')
    await page.click('[data-send]')
    await expect(page.locator('[data-artifact]')).toBeVisible({ timeout: 30000 })
  })

  test('skills can be attached to session', async ({ page }) => {
    await page.goto('/chat')
    await page.click('[data-skill="vault-weekly"]')
    await expect(page.locator('[data-attached-skills]')).toContainText('vault-weekly')
  })
})
```

---

## 16. Security Considerations

1. **API Key Management**: Provider API keys stored securely in environment
2. **Tool Sandboxing**: Tools only access allowed data (vault, exports)
3. **Path Validation**: All file paths validated against vault root
4. **Rate Limiting**: Prevent abuse of expensive agent runs
5. **Token Limits**: Cap per-request and per-session token usage
6. **Audit Logging**: Log all tool executions for review

---

## 17. Future Enhancements (Post-Phase 7)

1. **Conversation Memory**: Long-term memory across sessions
2. **Custom Tools**: User-defined tools via config
3. **Voice Input**: Speech-to-text for hands-free
4. **Multi-Modal**: Image input for GPT-4V/Claude Vision
5. **Collaborative**: Shared chat sessions
6. **Webhooks**: Notify external systems on events
