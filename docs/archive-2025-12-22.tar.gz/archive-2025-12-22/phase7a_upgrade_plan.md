# Phase 7A: Complete Chat & Agent System Upgrade (Revised)

**Status:** COMPLETE
**Created:** 2025-12-21
**Completed:** 2025-12-21
**Based on:** Adversarial review against Claude Agent SDK docs, codebase analysis, and implementation clarity audit
**Verified:** Adversarial bullshit detector audit passed - all core components implemented

---

## Executive Summary

Phase 7A addresses critical gaps in the current Phase 7 implementation:

| Issue | Root Cause | Solution |
|-------|------------|----------|
| No chat persistence | Frontend sends only current message; backend doesn't load history | Send full history; load from DB |
| Tools don't execute | Tool calls tracked but never executed; no continuation loop | Add tool execution loop |
| Agent can't create subagents | Feature specified but not implemented | Use Claude Agent SDK with correct API |
| Outdated models | Only Claude 4, missing 4.5 family | Add Opus/Sonnet/Haiku 4.5 |
| No error handling | Zero error handling throughout | Add comprehensive error strategy |

**Key Decision:** Use the **official Claude Agent SDK** for agent mode. The SDK uses `query()` for one-off tasks and `AgentDefinition` for subagents.

---

## Prerequisites (Complete Before Starting)

### P1. Verify Claude Agent SDK Availability

```bash
cd services/brain_runtime
uv add claude-agent-sdk

# Verify imports work
python -c "
from claude_agent_sdk import (
    query,
    ClaudeAgentOptions,
    AgentDefinition,
    create_sdk_mcp_server,
    tool,
)
print('SDK imports OK')
"
```

**If this fails:** The SDK may not be publicly available yet. Fall back to custom agent implementation using raw Anthropic API with tool loop.

### P2. Verify Database Schema

Ensure Phase 7 tables exist:

```sql
-- Check tables exist
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public'
AND table_name IN ('chat_sessions', 'chat_messages', 'agent_runs', 'agent_artifacts');

-- Expected: 4 rows
```

If missing, run migration:
```bash
psql -d second_brain -f services/brain_runtime/migrations/001_add_phase7_tables.sql
```

### P3. Required Environment Variables

```bash
# .env - Required
ANTHROPIC_API_KEY=sk-ant-...      # Required for all Claude modes
DATABASE_URL=postgresql://...      # Required for persistence

# .env - Optional
OPENAI_API_KEY=sk-proj-...        # Optional for GPT fallback
```

### P4. Current File Locations (Verify Exist)

| File | Purpose | Must Exist |
|------|---------|------------|
| `services/brain_runtime/main.py` | FastAPI app | Yes |
| `services/brain_runtime/api/chat.py` | Chat endpoint | Yes |
| `services/brain_runtime/api/agent.py` | Agent endpoint | Yes |
| `services/brain_runtime/core/providers/anthropic.py` | Anthropic adapter | Yes |
| `services/brain_runtime/core/tools/registry.py` | Tool registry | Yes |
| `services/brain_runtime/core/tools/__init__.py` | Tool exports | Yes |
| `apps/web/src/lib/chat-api.ts` | Frontend API client | Yes |
| `apps/web/src/hooks/useChat.ts` | Chat hook | Yes |

---

## Implementation Order

**Changed from original.** New order ensures dependencies are resolved:

1. **Part 1: Tool Execution Loop** - Foundation for chat with tools
2. **Part 2: Model Updates** - Independent, quick win
3. **Part 3: Tool Registration** - Startup hook
4. **Part 4: Chat Persistence** - Requires working tool execution
5. **Part 5: Agent SDK Integration** - After chat is stable
6. **Part 6: Prompt Caching** - Optimization
7. **Part 7: Frontend Updates** - After backend stable
8. **Part 8: Testing** - After implementation complete

---

## Part 1: Tool Execution Loop (CRITICAL)

### Problem

Current code tracks tool calls but never executes them. `chat.py:160` has comment: *"In a full implementation, we'd continue the conversation here"*

### Solution

Add a tool execution loop that:
1. Detects tool calls in LLM response
2. Executes each tool via ToolRegistry
3. Sends results back to LLM
4. Continues until LLM responds with text only (or max turns)

### Step 1.1: Create Tool Executor Service

**New file:** `services/brain_runtime/core/tools/executor.py`

```python
"""Tool execution service with retry and error handling."""

from typing import Any, Optional
from dataclasses import dataclass
import logging
import json

from .registry import ToolRegistry, ToolError

logger = logging.getLogger(__name__)


@dataclass
class ToolCallRequest:
    """A tool call from the LLM."""
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ToolCallResult:
    """Result of executing a tool."""
    tool_call_id: str
    success: bool
    content: str
    error: Optional[str] = None


class ToolExecutor:
    """Executes tools and formats results for LLM consumption."""

    def __init__(self, registry: Optional[ToolRegistry] = None):
        self.registry = registry or ToolRegistry.get_instance()

    async def execute(self, tool_call: ToolCallRequest) -> ToolCallResult:
        """Execute a single tool call with error handling."""
        logger.info(f"Executing tool: {tool_call.name} (id={tool_call.id})")

        try:
            # Validate tool exists
            tool = self.registry.get_tool(tool_call.name)
            if not tool:
                return ToolCallResult(
                    tool_call_id=tool_call.id,
                    success=False,
                    content="",
                    error=f"Unknown tool: {tool_call.name}",
                )

            # Execute tool
            result = await tool.execute(tool_call.arguments)

            # Format result as string
            if isinstance(result, dict):
                content = json.dumps(result, indent=2, default=str)
            elif isinstance(result, str):
                content = result
            else:
                content = str(result)

            logger.info(f"Tool {tool_call.name} completed successfully")
            return ToolCallResult(
                tool_call_id=tool_call.id,
                success=True,
                content=content,
            )

        except ToolError as e:
            logger.warning(f"Tool {tool_call.name} failed: {e}")
            return ToolCallResult(
                tool_call_id=tool_call.id,
                success=False,
                content="",
                error=str(e),
            )
        except Exception as e:
            logger.exception(f"Unexpected error in tool {tool_call.name}")
            return ToolCallResult(
                tool_call_id=tool_call.id,
                success=False,
                content="",
                error=f"Internal error: {type(e).__name__}",
            )

    async def execute_all(
        self, tool_calls: list[ToolCallRequest]
    ) -> list[ToolCallResult]:
        """Execute multiple tool calls (could be parallelized)."""
        results = []
        for tool_call in tool_calls:
            result = await self.execute(tool_call)
            results.append(result)
        return results

    def format_for_anthropic(self, results: list[ToolCallResult]) -> list[dict]:
        """Format tool results for Anthropic API."""
        formatted = []
        for result in results:
            if result.success:
                formatted.append({
                    "type": "tool_result",
                    "tool_use_id": result.tool_call_id,
                    "content": result.content,
                })
            else:
                formatted.append({
                    "type": "tool_result",
                    "tool_use_id": result.tool_call_id,
                    "content": f"Error: {result.error}",
                    "is_error": True,
                })
        return formatted
```

### Step 1.2: Update Chat Endpoint with Tool Loop

**Modify:** `services/brain_runtime/api/chat.py`

Add this function before the chat endpoint:

```python
from core.tools.executor import ToolExecutor, ToolCallRequest


async def chat_with_tool_loop(
    provider: BaseProvider,
    messages: list[dict],
    tools: list[dict],
    max_turns: int = 5,
    on_text: Callable[[str], Awaitable[None]] = None,
    on_tool_call: Callable[[dict], Awaitable[None]] = None,
    on_tool_result: Callable[[dict], Awaitable[None]] = None,
) -> tuple[str, list[dict]]:
    """
    Execute chat with automatic tool execution loop.

    Returns:
        tuple of (final_text_response, all_tool_calls)
    """
    executor = ToolExecutor()
    all_tool_calls = []
    current_messages = messages.copy()

    for turn in range(max_turns):
        # Call LLM
        accumulated_text = []
        pending_tool_calls = []

        async for event in provider.chat(
            messages=current_messages,
            tools=tools,
            stream=True,
        ):
            event_type = event.get("type")

            if event_type == "content":
                text = event.get("data", {}).get("text", "")
                if text:
                    accumulated_text.append(text)
                    if on_text:
                        await on_text(text)

            elif event_type == "tool_call_complete":
                tool_data = event.get("data", {})
                pending_tool_calls.append(ToolCallRequest(
                    id=tool_data["id"],
                    name=tool_data["name"],
                    arguments=tool_data["arguments"],
                ))
                all_tool_calls.append(tool_data)
                if on_tool_call:
                    await on_tool_call(tool_data)

        # If no tool calls, we're done
        if not pending_tool_calls:
            return "".join(accumulated_text), all_tool_calls

        # Execute tools
        results = await executor.execute_all(pending_tool_calls)

        # Notify frontend of results
        for result in results:
            if on_tool_result:
                await on_tool_result({
                    "tool_call_id": result.tool_call_id,
                    "success": result.success,
                    "content": result.content[:500],  # Truncate for display
                    "error": result.error,
                })

        # Add assistant message with tool calls to history
        current_messages.append({
            "role": "assistant",
            "content": [
                {"type": "text", "text": "".join(accumulated_text)} if accumulated_text else None,
                *[{
                    "type": "tool_use",
                    "id": tc.id,
                    "name": tc.name,
                    "input": tc.arguments,
                } for tc in pending_tool_calls],
            ],
        })

        # Add tool results to history
        current_messages.append({
            "role": "user",
            "content": executor.format_for_anthropic(results),
        })

    # Max turns reached
    return "".join(accumulated_text), all_tool_calls
```

### Step 1.3: Update Event Generator to Use Tool Loop

**Modify:** `services/brain_runtime/api/chat.py`

Replace the simple streaming with the tool loop:

```python
async def chat_event_generator(
    request: ChatRequest,
    session_id: str,
    messages: list[dict],
    db: AsyncSession,
) -> AsyncGenerator[str, None]:
    """Generate SSE events for chat with tool execution."""

    provider = get_provider(request.provider)
    tools = get_tools_for_mode(request.mode)

    yield format_sse("status", {"status": "started"})

    async def on_text(text: str):
        yield format_sse("text", {"text": text})

    async def on_tool_call(data: dict):
        yield format_sse("tool_call", data)

    async def on_tool_result(data: dict):
        yield format_sse("tool_result", data)

    try:
        if request.mode == "quick":
            # Quick mode: No tools, single turn
            async for event in provider.chat(messages=messages, stream=True):
                if event.get("type") == "content":
                    text = event.get("data", {}).get("text", "")
                    if text:
                        yield format_sse("text", {"text": text})
        else:
            # Tool-enabled mode: Use tool loop
            final_text, tool_calls = await chat_with_tool_loop(
                provider=provider,
                messages=messages,
                tools=tools,
                max_turns=5,
                on_text=on_text,
                on_tool_call=on_tool_call,
                on_tool_result=on_tool_result,
            )

        yield format_sse("status", {"status": "completed"})
        yield format_sse("done", {})

    except Exception as e:
        logger.exception("Chat error")
        yield format_sse("error", {"error": str(e)})
        yield format_sse("status", {"status": "failed"})
```

---

## Part 2: Model Version Updates

### Current Claude Model Family (December 2025)

**Modify:** `services/brain_runtime/core/providers/anthropic.py`

```python
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional


class ModelCapability(Enum):
    TOOLS = auto()
    VISION = auto()
    STREAMING = auto()
    EXTENDED_THINKING = auto()
    PROMPT_CACHING = auto()


@dataclass
class ProviderModel:
    id: str
    name: str
    capabilities: list[ModelCapability]
    context_window: int
    max_output: int
    input_price_per_m: float  # $ per million tokens
    output_price_per_m: float
    deprecated: bool = False


MODELS = [
    # Claude 4.5 Family (Current Generation - December 2025)
    ProviderModel(
        id="claude-opus-4-5-20251101",
        name="Claude Opus 4.5",
        capabilities=[
            ModelCapability.TOOLS,
            ModelCapability.VISION,
            ModelCapability.STREAMING,
            ModelCapability.EXTENDED_THINKING,
            ModelCapability.PROMPT_CACHING,
        ],
        context_window=200_000,
        max_output=64_000,
        input_price_per_m=5.0,
        output_price_per_m=25.0,
    ),
    ProviderModel(
        id="claude-sonnet-4-5-20250929",
        name="Claude Sonnet 4.5",
        capabilities=[
            ModelCapability.TOOLS,
            ModelCapability.VISION,
            ModelCapability.STREAMING,
            ModelCapability.PROMPT_CACHING,
        ],
        context_window=200_000,  # 1M with beta header
        max_output=64_000,
        input_price_per_m=3.0,
        output_price_per_m=15.0,
    ),
    ProviderModel(
        id="claude-haiku-4-5-20251001",
        name="Claude Haiku 4.5",
        capabilities=[
            ModelCapability.TOOLS,
            ModelCapability.VISION,
            ModelCapability.STREAMING,
            ModelCapability.PROMPT_CACHING,
        ],
        context_window=200_000,
        max_output=64_000,
        input_price_per_m=1.0,
        output_price_per_m=5.0,
    ),
    # Claude 4 Family (Previous Generation - keep for compatibility)
    ProviderModel(
        id="claude-sonnet-4-20250514",
        name="Claude Sonnet 4",
        capabilities=[
            ModelCapability.TOOLS,
            ModelCapability.VISION,
            ModelCapability.STREAMING,
        ],
        context_window=200_000,
        max_output=64_000,
        input_price_per_m=3.0,
        output_price_per_m=15.0,
        deprecated=True,  # Mark as deprecated
    ),
    # Claude 3.5 Family (Budget option)
    ProviderModel(
        id="claude-3-5-haiku-20241022",
        name="Claude 3.5 Haiku",
        capabilities=[
            ModelCapability.TOOLS,
            ModelCapability.STREAMING,
        ],
        context_window=200_000,
        max_output=8_192,
        input_price_per_m=0.80,
        output_price_per_m=4.0,
    ),
]

DEFAULT_MODEL = "claude-sonnet-4-5-20250929"  # Best balance of capability/cost


def get_model(model_id: str) -> Optional[ProviderModel]:
    """Get model by ID, with fallback for deprecated models."""
    for model in MODELS:
        if model.id == model_id:
            return model

    # Handle old model ID aliases
    ALIASES = {
        "claude-sonnet-4": "claude-sonnet-4-20250514",
        "claude-opus-4": "claude-opus-4-5-20251101",
    }
    if model_id in ALIASES:
        return get_model(ALIASES[model_id])

    return None


def get_available_models(include_deprecated: bool = False) -> list[ProviderModel]:
    """Get list of available models."""
    if include_deprecated:
        return MODELS
    return [m for m in MODELS if not m.deprecated]
```

### Model Pricing Reference

| Model | Input | Output | Best For |
|-------|-------|--------|----------|
| Opus 4.5 | $5/M | $25/M | Complex agents, extended thinking |
| Sonnet 4.5 | $3/M | $15/M | Default for most tasks |
| Haiku 4.5 | $1/M | $5/M | High-frequency, subagents |
| Sonnet 4 | $3/M | $15/M | Compatibility (deprecated) |
| Haiku 3.5 | $0.80/M | $4/M | Maximum cost savings |

---

## Part 3: Tool Registration

### Problem

Tools are never registered at application startup. Currently relies on lazy import.

### Step 3.1: Add Startup Hook

**Modify:** `services/brain_runtime/main.py`

```python
from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from core.tools import register_all_tools
from core.database import init_db

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup/shutdown."""
    # Startup
    logger.info("Starting brain-runtime...")

    # Initialize database connection pool
    await init_db()
    logger.info("Database initialized")

    # Register all tools
    tool_count = register_all_tools()
    logger.info(f"Tool registry initialized with {tool_count} tools")

    yield

    # Shutdown
    logger.info("Shutting down brain-runtime...")


app = FastAPI(
    title="Second Brain Runtime",
    version="0.2.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers (existing code)
# ...
```

### Step 3.2: Update Tool Registry Init

**Modify:** `services/brain_runtime/core/tools/__init__.py`

```python
"""Tool registry initialization and exports."""

from .registry import ToolRegistry, tool, ToolError

# Import all tool modules to trigger @tool decorators
from . import calendar_tools
from . import tasks_tools
from . import vault_tools
from . import skills_tools


def register_all_tools() -> int:
    """
    Ensure all tools are registered.

    Returns:
        Number of tools registered.
    """
    registry = ToolRegistry.get_instance()
    tools = registry.get_all_tools()
    return len(tools)


__all__ = [
    "ToolRegistry",
    "tool",
    "ToolError",
    "register_all_tools",
]
```

### Step 3.3: Enable Beta Features

**Modify:** `services/brain_runtime/core/providers/anthropic.py`

```python
# Beta headers for enhanced features
# See: https://docs.anthropic.com/en/api/versioning#beta-headers
BETA_HEADERS = [
    "prompt-caching-2024-07-31",           # Prompt caching (90% cost reduction)
    "extended-cache-ttl-2025-04-11",       # 1-hour cache TTL (vs 5-min default)
    "token-efficient-tools-2025-02-19",    # Optimized tool token usage
]


class AnthropicProvider(BaseProvider):
    """Anthropic Claude provider with beta features."""

    def __init__(self, api_key: str):
        self.client = AsyncAnthropic(
            api_key=api_key,
            default_headers={
                "anthropic-beta": ",".join(BETA_HEADERS)
            }
        )
        self.model = DEFAULT_MODEL

    async def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        system: str | None = None,
        model: str | None = None,
        stream: bool = True,
        **kwargs,
    ) -> AsyncGenerator[dict, None]:
        """Send chat request with streaming."""

        use_model = model or self.model

        # Build system with cache control for long prompts
        system_content = None
        if system:
            system_content = [{
                "type": "text",
                "text": system,
                "cache_control": {"type": "ephemeral"}  # Enable caching
            }]

        params = {
            "model": use_model,
            "messages": messages,
            "max_tokens": kwargs.get("max_tokens", 4096),
        }

        if system_content:
            params["system"] = system_content

        if tools:
            params["tools"] = tools

        if stream:
            async for event in self._stream_chat(**params):
                yield event
        else:
            response = await self.client.messages.create(**params)
            yield self._format_response(response)
```

---

## Part 4: Chat Persistence

### Problem

1. Frontend sends only current message, not full history
2. Backend doesn't load previous messages when session_id provided
3. Assistant messages are not saved to database

### Step 4.1: Add Session Service

**New file:** `services/brain_runtime/core/session_service.py`

```python
"""Chat session management service."""

import uuid
from datetime import datetime, timezone
from typing import Optional
import logging

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from models.db_models import ChatSessionDB, ChatMessageDB

logger = logging.getLogger(__name__)


class SessionService:
    """Manages chat session lifecycle and persistence."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_or_create_session(
        self,
        session_id: Optional[str],
        mode: str,
        provider: str,
        model: str,
        attached_skills: list[str] | None = None,
    ) -> tuple[str, bool]:
        """
        Get existing session or create new one.

        Returns:
            tuple of (session_id, is_new)
        """
        if session_id:
            # Try to find existing session
            result = await self.db.execute(
                select(ChatSessionDB).where(ChatSessionDB.id == uuid.UUID(session_id))
            )
            existing = result.scalar_one_or_none()
            if existing:
                return session_id, False

        # Create new session
        new_id = str(uuid.uuid4())
        session = ChatSessionDB(
            id=uuid.UUID(new_id),
            mode=mode,
            provider=provider,
            model=model,
            attached_skills=attached_skills or [],
            created_at=datetime.now(timezone.utc),
        )
        self.db.add(session)
        await self.db.commit()

        logger.info(f"Created new session: {new_id}")
        return new_id, True

    async def load_messages(self, session_id: str) -> list[dict]:
        """Load all messages for a session, ordered by creation time."""
        result = await self.db.execute(
            select(ChatMessageDB)
            .where(ChatMessageDB.session_id == uuid.UUID(session_id))
            .order_by(ChatMessageDB.created_at)
        )
        messages = result.scalars().all()

        return [
            {"role": msg.role, "content": msg.content}
            for msg in messages
        ]

    async def save_message(
        self,
        session_id: str,
        role: str,
        content: str,
        tool_calls: list[dict] | None = None,
        tool_results: list[dict] | None = None,
    ) -> str:
        """Save a message to the session."""
        message_id = str(uuid.uuid4())

        message = ChatMessageDB(
            id=uuid.UUID(message_id),
            session_id=uuid.UUID(session_id),
            role=role,
            content=content,
            tool_calls=tool_calls,
            tool_results=tool_results,
            created_at=datetime.now(timezone.utc),
        )
        self.db.add(message)
        await self.db.commit()

        return message_id

    async def get_session(self, session_id: str) -> Optional[dict]:
        """Get session with all messages."""
        result = await self.db.execute(
            select(ChatSessionDB).where(ChatSessionDB.id == uuid.UUID(session_id))
        )
        session = result.scalar_one_or_none()

        if not session:
            return None

        messages = await self.load_messages(session_id)

        return {
            "id": str(session.id),
            "mode": session.mode,
            "provider": session.provider,
            "model": session.model,
            "attached_skills": session.attached_skills,
            "created_at": session.created_at.isoformat(),
            "messages": messages,
        }
```

### Step 4.2: Update Chat Endpoint

**Modify:** `services/brain_runtime/api/chat.py`

```python
from core.session_service import SessionService


@router.post("/chat")
async def chat(
    request: ChatRequest,
    db: AsyncSession = Depends(get_db),
):
    """Chat endpoint with session persistence."""

    session_service = SessionService(db)

    # Get or create session
    session_id, is_new = await session_service.get_or_create_session(
        session_id=request.session_id,
        mode=request.mode,
        provider=request.provider,
        model=request.model,
        attached_skills=request.attached_skills,
    )

    # Load existing messages if session exists
    if not is_new:
        existing_messages = await session_service.load_messages(session_id)
    else:
        existing_messages = []

    # Combine with new messages from request
    # Deduplicate by checking if last message matches
    all_messages = existing_messages.copy()
    for msg in request.messages:
        # Only add if not already in history
        if not existing_messages or msg != existing_messages[-1]:
            all_messages.append(msg)
            # Save new user messages
            if msg["role"] == "user":
                await session_service.save_message(
                    session_id=session_id,
                    role="user",
                    content=msg["content"],
                )

    async def event_generator():
        accumulated_response = []
        all_tool_calls = []

        try:
            # ... streaming logic from Part 1 ...

            # After streaming completes, save assistant response
            if accumulated_response:
                await session_service.save_message(
                    session_id=session_id,
                    role="assistant",
                    content="".join(accumulated_response),
                    tool_calls=all_tool_calls if all_tool_calls else None,
                )

            yield format_sse("done", {"session_id": session_id})

        except Exception as e:
            logger.exception("Chat error")
            yield format_sse("error", {"error": str(e)})

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "X-Session-ID": session_id,
            "Cache-Control": "no-cache",
        },
    )


@router.get("/chat/sessions/{session_id}")
async def get_session(
    session_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Get session with full message history."""
    session_service = SessionService(db)
    session = await session_service.get_session(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    return session
```

### Step 4.3: Update Frontend Chat API

**Modify:** `apps/web/src/lib/chat-api.ts`

```typescript
export interface ChatRequest {
  mode: ChatMode
  provider: string
  model: string
  messages: Array<{ role: string; content: string }>  // Full history
  session_id?: string
  attached_skills?: string[]
}

export interface ChatSession {
  id: string
  mode: string
  provider: string
  model: string
  attached_skills: string[]
  created_at: string
  messages: Array<{ role: string; content: string }>
}

/**
 * Fetch existing session with message history.
 */
export async function getSession(sessionId: string): Promise<ChatSession> {
  const response = await fetch(`${API_BASE}/chat/sessions/${sessionId}`)

  if (!response.ok) {
    if (response.status === 404) {
      throw new Error('Session not found')
    }
    throw new Error(`Failed to load session: ${response.status}`)
  }

  return response.json()
}

/**
 * Stream chat response with full message history.
 */
export function streamChatResponse(
  request: ChatRequest,
  callbacks: {
    onText?: (text: string) => void
    onToolCall?: (data: any) => void
    onToolResult?: (data: any) => void
    onDone?: (data: { session_id: string }) => void
    onError?: (error: string) => void
  },
): () => void {
  const abortController = new AbortController()

  const body = {
    mode: request.mode,
    provider: request.provider,
    model: request.model,
    messages: request.messages,  // Send full history
    session_id: request.session_id,
    attached_skills: request.attached_skills || [],
  }

  fetch(`${API_BASE}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: abortController.signal,
  })
    .then(async (response) => {
      if (!response.ok) {
        throw new Error(`Chat failed: ${response.status}`)
      }

      // Get session ID from header
      const sessionId = response.headers.get('X-Session-ID')

      const reader = response.body?.getReader()
      if (!reader) throw new Error('No response body')

      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (line.startsWith('event: ')) {
            const eventType = line.slice(7)
            // Next line is data
            continue
          }
          if (line.startsWith('data: ')) {
            const data = JSON.parse(line.slice(6))

            switch (data.type) {
              case 'text':
                callbacks.onText?.(data.data.text)
                break
              case 'tool_call':
                callbacks.onToolCall?.(data.data)
                break
              case 'tool_result':
                callbacks.onToolResult?.(data.data)
                break
              case 'done':
                callbacks.onDone?.({ session_id: sessionId || data.data.session_id })
                break
              case 'error':
                callbacks.onError?.(data.data.error)
                break
            }
          }
        }
      }
    })
    .catch((error) => {
      if (error.name !== 'AbortError') {
        callbacks.onError?.(error.message)
      }
    })

  return () => abortController.abort()
}
```

### Step 4.4: Update useChat Hook

**Modify:** `apps/web/src/hooks/useChat.ts`

```typescript
import { useState, useCallback, useEffect } from 'react'
import { streamChatResponse, getSession, ChatSession } from '@/lib/chat-api'

interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
  timestamp: string
  toolCalls?: any[]
}

interface UseChatOptions {
  mode: 'quick' | 'tools' | 'agent'
  provider: string
  model: string
  attachedSkills?: string[]
}

const SESSION_KEY = 'chat_session_id'

export function useChat(options: UseChatOptions) {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [sessionId, setSessionId] = useState<string | undefined>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem(SESSION_KEY) || undefined
    }
    return undefined
  })
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingSession, setIsLoadingSession] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Load existing session on mount
  useEffect(() => {
    if (sessionId) {
      loadSession(sessionId)
    }
  }, [])

  const loadSession = async (id: string) => {
    setIsLoadingSession(true)
    try {
      const session = await getSession(id)
      setMessages(
        session.messages.map((m) => ({
          role: m.role as 'user' | 'assistant',
          content: m.content,
          timestamp: new Date().toISOString(),
        }))
      )
    } catch (e) {
      // Session not found or expired, start fresh
      console.warn('Failed to load session:', e)
      setSessionId(undefined)
      localStorage.removeItem(SESSION_KEY)
    } finally {
      setIsLoadingSession(false)
    }
  }

  const sendMessage = useCallback(
    (content: string) => {
      // Add user message to state
      const userMessage: ChatMessage = {
        role: 'user',
        content,
        timestamp: new Date().toISOString(),
      }
      const updatedMessages = [...messages, userMessage]
      setMessages(updatedMessages)
      setIsLoading(true)
      setError(null)

      // Prepare assistant message placeholder
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: '',
        timestamp: new Date().toISOString(),
        toolCalls: [],
      }
      setMessages([...updatedMessages, assistantMessage])

      // Convert to API format (full history)
      const apiMessages = updatedMessages.map((m) => ({
        role: m.role,
        content: m.content,
      }))

      streamChatResponse(
        {
          mode: options.mode,
          provider: options.provider,
          model: options.model,
          messages: apiMessages,
          session_id: sessionId,
          attached_skills: options.attachedSkills,
        },
        {
          onText: (text) => {
            setMessages((prev) => {
              const updated = [...prev]
              const last = updated[updated.length - 1]
              if (last.role === 'assistant') {
                last.content += text
              }
              return updated
            })
          },
          onToolCall: (data) => {
            setMessages((prev) => {
              const updated = [...prev]
              const last = updated[updated.length - 1]
              if (last.role === 'assistant') {
                last.toolCalls = [...(last.toolCalls || []), data]
              }
              return updated
            })
          },
          onDone: (data) => {
            setIsLoading(false)
            // Persist session ID
            if (data.session_id) {
              setSessionId(data.session_id)
              localStorage.setItem(SESSION_KEY, data.session_id)
            }
          },
          onError: (err) => {
            setIsLoading(false)
            setError(err)
          },
        }
      )
    },
    [messages, sessionId, options]
  )

  const clearSession = useCallback(() => {
    setMessages([])
    setSessionId(undefined)
    localStorage.removeItem(SESSION_KEY)
  }, [])

  return {
    messages,
    isLoading,
    isLoadingSession,
    error,
    sessionId,
    sendMessage,
    clearSession,
  }
}
```

---

## Part 5: Agent Mode with Claude Agent SDK

### SDK Availability Check

Before implementing, verify SDK is available:

```bash
uv add claude-agent-sdk
python -c "from claude_agent_sdk import query, AgentDefinition; print('OK')"
```

**If SDK unavailable:** Skip this part and use custom agent loop (see Appendix A).

### Step 5.1: Create MCP Tool Server

**New file:** `services/brain_runtime/core/agent/mcp_tools.py`

```python
"""MCP tool wrappers for Claude Agent SDK."""

import json
from typing import Any

from claude_agent_sdk import tool, create_sdk_mcp_server

from core.tools.registry import ToolRegistry


def create_brain_mcp_server():
    """Create MCP server wrapping all brain tools."""

    registry = ToolRegistry.get_instance()
    mcp_tools = []

    # Dynamically wrap each tool
    for tool_def in registry.get_all_tools():

        # Create wrapper function
        async def make_tool_wrapper(name: str):
            async def wrapper(args: dict) -> dict:
                result = await registry.execute(name, args)
                return {
                    "content": [{
                        "type": "text",
                        "text": json.dumps(result, default=str),
                    }]
                }
            return wrapper

        # Create MCP tool with proper metadata
        mcp_tool = tool(
            tool_def.name,
            tool_def.description,
            tool_def.parameters,  # JSON Schema for parameters
        )(make_tool_wrapper(tool_def.name))

        mcp_tools.append(mcp_tool)

    return create_sdk_mcp_server(
        name="brain-tools",
        version="1.0.0",
        tools=mcp_tools,
    )


# Create singleton server
brain_tools_server = None


def get_brain_tools_server():
    """Get or create the brain tools MCP server."""
    global brain_tools_server
    if brain_tools_server is None:
        brain_tools_server = create_brain_mcp_server()
    return brain_tools_server
```

### Step 5.2: Create Agent Runtime with SDK

**New file:** `services/brain_runtime/core/agent/sdk_runtime.py`

```python
"""Agent runtime using Claude Agent SDK."""

import logging
from typing import AsyncGenerator, Optional

from claude_agent_sdk import (
    query,
    ClaudeAgentOptions,
    AgentDefinition,
    AssistantMessage,
    TextBlock,
    ToolUseBlock,
    ToolResultBlock,
    ResultMessage,
)

from .mcp_tools import get_brain_tools_server

logger = logging.getLogger(__name__)


class SDKAgentRuntime:
    """Agent runtime using official Claude Agent SDK."""

    # Subagent definitions using correct SDK API
    SUBAGENT_DEFINITIONS = {
        "CalendarAnalyst": AgentDefinition(
            description="Analyze calendar and schedule data",
            prompt="""You are a calendar analyst. When given calendar data:
1. Identify scheduling conflicts
2. Analyze time allocation patterns
3. Suggest optimizations for productivity
4. Highlight important upcoming events""",
            tools=[
                "mcp__brain__get_today_events",
                "mcp__brain__get_week_events",
                "mcp__brain__search_events",
            ],
            model="haiku",  # Cost-efficient for subagents
        ),
        "TaskAnalyst": AgentDefinition(
            description="Analyze tasks and prioritization",
            prompt="""You are a task analyst. When given task data:
1. Identify overdue and high-priority items
2. Analyze workload distribution
3. Suggest task ordering for efficiency
4. Identify blockers and dependencies""",
            tools=[
                "mcp__brain__get_overdue_tasks",
                "mcp__brain__get_today_tasks",
                "mcp__brain__query_tasks",
            ],
            model="haiku",
        ),
        "KnowledgeSearcher": AgentDefinition(
            description="Search and synthesize vault knowledge",
            prompt="""You are a knowledge researcher. When asked to find information:
1. Search the vault using semantic and text search
2. Read relevant files to understand context
3. Synthesize findings into coherent insights
4. Cite sources accurately""",
            tools=[
                "mcp__brain__semantic_search",
                "mcp__brain__text_search",
                "mcp__brain__read_vault_file",
            ],
            model="haiku",
        ),
    }

    async def execute(
        self,
        task: str,
        model: str = "claude-sonnet-4-5-20250929",
        max_turns: int = 10,
        attached_skills: list[str] | None = None,
    ) -> AsyncGenerator[dict, None]:
        """Execute agent task with subagent support."""

        # Build system prompt
        system_prompt = self._build_system_prompt(attached_skills)

        # Configure SDK options
        options = ClaudeAgentOptions(
            model=model,
            mcp_servers={"brain": get_brain_tools_server()},
            allowed_tools=["mcp__brain__*", "Task"],  # Task tool for subagents
            max_turns=max_turns,
            agents=self.SUBAGENT_DEFINITIONS,
        )

        try:
            # Stream responses using SDK
            async for message in query(prompt=task, options=options):
                # Handle different message types
                if isinstance(message, AssistantMessage):
                    for block in message.content:
                        if isinstance(block, TextBlock):
                            yield {
                                "type": "text",
                                "data": {"text": block.text},
                            }
                        elif isinstance(block, ToolUseBlock):
                            yield {
                                "type": "tool_call",
                                "data": {
                                    "id": block.id,
                                    "name": block.name,
                                    "arguments": block.input,
                                },
                            }
                        elif isinstance(block, ToolResultBlock):
                            yield {
                                "type": "tool_result",
                                "data": {
                                    "tool_call_id": block.tool_use_id,
                                    "content": block.content[:1000],  # Truncate
                                },
                            }

                elif isinstance(message, ResultMessage):
                    yield {
                        "type": "done",
                        "data": {
                            "turns": message.num_turns,
                            "duration_ms": message.duration_ms,
                            "cost_usd": message.total_cost_usd,
                            "is_error": message.is_error,
                        },
                    }

        except Exception as e:
            logger.exception("Agent execution error")
            yield {
                "type": "error",
                "data": {"error": str(e)},
            }

    def _build_system_prompt(
        self, attached_skills: list[str] | None = None
    ) -> str:
        """Build system prompt with optional skills."""
        base = """You are an AI agent with access to the user's Second Brain system.
You can query their calendar, tasks, and knowledge vault to help with analysis and planning.

## Available Subagents
You can use the Task tool to spawn specialized subagents:
- **CalendarAnalyst**: Schedule analysis, conflict detection, time optimization
- **TaskAnalyst**: Task prioritization, blocker identification, workload analysis
- **KnowledgeSearcher**: Deep vault research, pattern recognition, synthesis

## Execution Guidelines
1. Break complex tasks into subtasks suitable for subagents
2. Spawn subagents in parallel when tasks are independent
3. For simple queries, use tools directly without subagents
4. Synthesize subagent results into cohesive insights
5. Be concise but thorough in your final response
"""

        if attached_skills:
            base += "\n\n## Attached Skills\n"
            for skill_id in attached_skills:
                skill = self._load_skill(skill_id)
                if skill:
                    base += f"\n### {skill['name']}\n{skill['content']}\n"

        return base

    def _load_skill(self, skill_id: str) -> Optional[dict]:
        """Load skill content by ID."""
        try:
            from core.skills import get_skill
            return get_skill(skill_id)
        except Exception as e:
            logger.warning(f"Failed to load skill {skill_id}: {e}")
            return None
```

### Step 5.3: Update Agent API Endpoint

**Modify:** `services/brain_runtime/api/agent.py`

```python
from core.agent.sdk_runtime import SDKAgentRuntime


@router.post("/agent/run")
async def run_agent(
    request: AgentRequest,
    db: AsyncSession = Depends(get_db),
):
    """Run agent task with subagent support."""

    run_id = str(uuid.uuid4())

    # Create agent run record
    agent_run = AgentRunDB(
        id=uuid.UUID(run_id),
        task=request.task,
        model=request.model or "claude-sonnet-4-5-20250929",
        status="running",
        attached_skills=request.attached_skills or [],
        started_at=datetime.now(timezone.utc),
    )
    db.add(agent_run)
    await db.commit()

    runtime = SDKAgentRuntime()

    async def event_generator():
        total_cost = 0.0
        total_turns = 0

        try:
            async for event in runtime.execute(
                task=request.task,
                model=request.model or "claude-sonnet-4-5-20250929",
                max_turns=request.max_turns or 10,
                attached_skills=request.attached_skills,
            ):
                # Add run_id to all events
                event["run_id"] = run_id

                # Track metrics
                if event["type"] == "done":
                    total_cost = event["data"].get("cost_usd", 0)
                    total_turns = event["data"].get("turns", 0)

                yield f"event: {event['type']}\ndata: {json.dumps(event)}\n\n"

            # Update run record
            agent_run.status = "completed"
            agent_run.ended_at = datetime.now(timezone.utc)
            agent_run.turns = total_turns
            agent_run.cost_usd = total_cost
            await db.commit()

        except Exception as e:
            agent_run.status = "failed"
            agent_run.error = str(e)
            agent_run.ended_at = datetime.now(timezone.utc)
            await db.commit()

            yield f"event: error\ndata: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "X-Run-ID": run_id,
            "Cache-Control": "no-cache",
        },
    )
```

---

## Part 6: Error Handling Strategy

### Error Types

**New file:** `services/brain_runtime/core/errors.py`

```python
"""Application error types and handling."""

from enum import Enum
from typing import Optional
from dataclasses import dataclass


class ErrorCode(Enum):
    # Client errors (4xx)
    VALIDATION_ERROR = "VALIDATION_ERROR"
    SESSION_NOT_FOUND = "SESSION_NOT_FOUND"
    TOOL_NOT_FOUND = "TOOL_NOT_FOUND"
    INVALID_MODEL = "INVALID_MODEL"
    RATE_LIMITED = "RATE_LIMITED"

    # Server errors (5xx)
    PROVIDER_ERROR = "PROVIDER_ERROR"
    TOOL_EXECUTION_ERROR = "TOOL_EXECUTION_ERROR"
    DATABASE_ERROR = "DATABASE_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"


@dataclass
class AppError(Exception):
    """Application error with code and details."""
    code: ErrorCode
    message: str
    details: Optional[dict] = None

    def to_dict(self) -> dict:
        return {
            "code": self.code.value,
            "message": self.message,
            "details": self.details,
        }

    @property
    def status_code(self) -> int:
        """Map error code to HTTP status."""
        mapping = {
            ErrorCode.VALIDATION_ERROR: 400,
            ErrorCode.SESSION_NOT_FOUND: 404,
            ErrorCode.TOOL_NOT_FOUND: 404,
            ErrorCode.INVALID_MODEL: 400,
            ErrorCode.RATE_LIMITED: 429,
            ErrorCode.PROVIDER_ERROR: 502,
            ErrorCode.TOOL_EXECUTION_ERROR: 500,
            ErrorCode.DATABASE_ERROR: 500,
            ErrorCode.INTERNAL_ERROR: 500,
        }
        return mapping.get(self.code, 500)


# Exception handler for FastAPI
from fastapi import Request
from fastapi.responses import JSONResponse


async def app_error_handler(request: Request, exc: AppError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.to_dict(),
    )
```

### Register Error Handler

**Modify:** `services/brain_runtime/main.py`

```python
from core.errors import AppError, app_error_handler

# After app creation
app.add_exception_handler(AppError, app_error_handler)
```

### SSE Error Events

All SSE streams should emit error events in consistent format:

```python
def format_sse_error(error: AppError) -> str:
    """Format error for SSE stream."""
    return f"event: error\ndata: {json.dumps(error.to_dict())}\n\n"
```

---

## Part 7: Frontend Updates

### Step 7.1: Update Model Selector

**Modify:** `apps/web/src/components/chat/ProviderSelector.tsx`

```typescript
const MODELS = {
  anthropic: [
    { id: 'claude-sonnet-4-5-20250929', name: 'Claude Sonnet 4.5', default: true },
    { id: 'claude-opus-4-5-20251101', name: 'Claude Opus 4.5' },
    { id: 'claude-haiku-4-5-20251001', name: 'Claude Haiku 4.5' },
    { id: 'claude-3-5-haiku-20241022', name: 'Claude 3.5 Haiku (Budget)' },
  ],
  openai: [
    { id: 'gpt-4o', name: 'GPT-4o', default: true },
    { id: 'gpt-4-turbo', name: 'GPT-4 Turbo' },
    { id: 'gpt-4o-mini', name: 'GPT-4o Mini' },
  ],
}
```

### Step 7.2: Add SubagentCard Component

**New file:** `apps/web/src/components/chat/SubagentCard.tsx`

```typescript
interface SubagentCardProps {
  subagent: {
    id: string
    type: string
    task: string
    status: 'running' | 'completed' | 'failed'
    result?: string
  }
}

export function SubagentCard({ subagent }: SubagentCardProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <div className="border rounded-lg p-3 bg-purple-50 my-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-purple-600 font-medium text-sm">
            {subagent.type}
          </span>
          {subagent.status === 'running' && (
            <span className="animate-pulse text-xs bg-purple-200 px-2 py-0.5 rounded">
              Running...
            </span>
          )}
          {subagent.status === 'completed' && (
            <span className="text-xs bg-green-200 px-2 py-0.5 rounded">
              Done
            </span>
          )}
          {subagent.status === 'failed' && (
            <span className="text-xs bg-red-200 px-2 py-0.5 rounded">
              Failed
            </span>
          )}
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-gray-500 hover:text-gray-700"
        >
          {isExpanded ? '▼' : '▶'}
        </button>
      </div>

      <p className="text-sm text-gray-700 mt-1">{subagent.task}</p>

      {isExpanded && subagent.result && (
        <div className="mt-2 text-sm bg-white p-2 rounded border max-h-40 overflow-auto">
          <pre className="whitespace-pre-wrap">{subagent.result}</pre>
        </div>
      )}
    </div>
  )
}
```

---

## Part 8: Testing Plan

### Unit Test Fixtures

**New file:** `tests/fixtures/chat.py`

```python
import pytest
import uuid
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession

from models.db_models import ChatSessionDB, ChatMessageDB


@pytest.fixture
async def test_session(db: AsyncSession) -> str:
    """Create a test session and return its ID."""
    session_id = str(uuid.uuid4())
    session = ChatSessionDB(
        id=uuid.UUID(session_id),
        mode="tools",
        provider="anthropic",
        model="claude-sonnet-4-5-20250929",
        attached_skills=[],
        created_at=datetime.now(timezone.utc),
    )
    db.add(session)
    await db.commit()
    return session_id


@pytest.fixture
async def test_session_with_messages(db: AsyncSession) -> str:
    """Create a test session with message history."""
    session_id = await test_session(db)

    messages = [
        {"role": "user", "content": "Hello"},
        {"role": "assistant", "content": "Hi there! How can I help?"},
        {"role": "user", "content": "What's on my calendar?"},
    ]

    for msg in messages:
        db.add(ChatMessageDB(
            id=uuid.uuid4(),
            session_id=uuid.UUID(session_id),
            role=msg["role"],
            content=msg["content"],
            created_at=datetime.now(timezone.utc),
        ))

    await db.commit()
    return session_id
```

### Mock LLM Responses

**New file:** `tests/fixtures/llm_mocks.py`

```python
from unittest.mock import AsyncMock, MagicMock


def create_mock_anthropic_provider():
    """Create a mock Anthropic provider for testing."""
    provider = MagicMock()

    async def mock_chat(**kwargs):
        # Simulate streaming response
        yield {"type": "content", "data": {"text": "This is "}}
        yield {"type": "content", "data": {"text": "a test response."}}
        yield {"type": "done", "data": {}}

    provider.chat = mock_chat
    return provider


def create_mock_tool_call_provider():
    """Create a mock provider that makes tool calls."""
    provider = MagicMock()

    async def mock_chat(**kwargs):
        # First call: return tool call
        if len(kwargs.get("messages", [])) == 1:
            yield {
                "type": "tool_call_complete",
                "data": {
                    "id": "call_123",
                    "name": "get_today_events",
                    "arguments": {},
                },
            }
        else:
            # After tool result: return text
            yield {"type": "content", "data": {"text": "Based on your calendar..."}}
            yield {"type": "done", "data": {}}

    provider.chat = mock_chat
    return provider
```

### Integration Tests

**File:** `tests/integration/test_chat_persistence.py`

```python
import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_chat_creates_session(client: AsyncClient):
    """Test that chat creates a new session."""
    response = await client.post("/chat", json={
        "mode": "quick",
        "provider": "anthropic",
        "model": "claude-sonnet-4-5-20250929",
        "messages": [{"role": "user", "content": "Hello"}],
    })

    assert response.status_code == 200
    assert "X-Session-ID" in response.headers


@pytest.mark.asyncio
async def test_chat_loads_history(
    client: AsyncClient,
    test_session_with_messages: str,
):
    """Test that chat loads existing session history."""
    # This requires mocking the LLM to verify it receives full history
    # See llm_mocks.py for mock setup
    pass


@pytest.mark.asyncio
async def test_chat_saves_assistant_response(
    client: AsyncClient,
    db: AsyncSession,
):
    """Test that assistant responses are saved to database."""
    # Send message
    response = await client.post("/chat", json={
        "mode": "quick",
        "provider": "anthropic",
        "model": "claude-sonnet-4-5-20250929",
        "messages": [{"role": "user", "content": "Hello"}],
    })

    session_id = response.headers["X-Session-ID"]

    # Verify message saved
    from models.db_models import ChatMessageDB
    from sqlalchemy import select

    result = await db.execute(
        select(ChatMessageDB)
        .where(ChatMessageDB.session_id == session_id)
        .where(ChatMessageDB.role == "assistant")
    )
    messages = result.scalars().all()

    assert len(messages) == 1
    assert messages[0].content != ""
```

### E2E Test Configuration

**File:** `tests/e2e/playwright.config.ts`

```typescript
import { defineConfig } from '@playwright/test'

export default defineConfig({
  testDir: './tests/e2e',
  timeout: 60000,  // 60s for agent tests
  retries: 2,  // Retry flaky tests

  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
  },

  webServer: [
    {
      command: 'cd services/brain_runtime && uv run uvicorn main:app --port 8000',
      port: 8000,
      reuseExistingServer: !process.env.CI,
    },
    {
      command: 'cd apps/web && pnpm dev',
      port: 3000,
      reuseExistingServer: !process.env.CI,
    },
  ],
})
```

---

## Part 9: Migration Checklist

### Pre-Migration

- [ ] Run `git status` to ensure clean working tree
- [ ] Create backup: `pg_dump second_brain > backup_$(date +%Y%m%d).sql`
- [ ] Document current API behavior: `curl localhost:8000/health`
- [ ] Run existing tests: `pytest && pnpm test`

### Implementation Order

**Day 1: Foundation**
1. [ ] Verify SDK availability (Prerequisites P1)
2. [ ] Part 1: Tool Execution Loop
   - [ ] Create `core/tools/executor.py`
   - [ ] Update `api/chat.py` with tool loop
   - [ ] Test: Send tool-mode message, verify tool executes
3. [ ] Part 3: Tool Registration
   - [ ] Update `main.py` with lifespan
   - [ ] Verify: Check logs for tool count on startup

**Day 2: Models & Persistence**
4. [ ] Part 2: Model Updates
   - [ ] Update `anthropic.py` with new models
   - [ ] Update frontend model selector
   - [ ] Test: Select Claude 4.5 in UI
5. [ ] Part 4: Chat Persistence
   - [ ] Create `core/session_service.py`
   - [ ] Update `api/chat.py` for persistence
   - [ ] Update frontend `useChat` hook
   - [ ] Update `chat-api.ts`
   - [ ] Test: Reload page, verify history persists

**Day 3: Agent Mode**
6. [ ] Part 5: Agent SDK Integration (if SDK available)
   - [ ] Create `core/agent/mcp_tools.py`
   - [ ] Create `core/agent/sdk_runtime.py`
   - [ ] Update `api/agent.py`
   - [ ] Test: Run agent task, verify subagent spawns
7. [ ] Part 6: Error Handling
   - [ ] Create `core/errors.py`
   - [ ] Register error handler
   - [ ] Test: Invalid request returns proper error

**Day 4: Frontend & Polish**
8. [ ] Part 7: Frontend Updates
   - [ ] Update ProviderSelector with new models
   - [ ] Add SubagentCard component
   - [ ] Test: Full E2E flow

**Day 5: Testing**
9. [ ] Part 8: Testing
   - [ ] Create test fixtures
   - [ ] Run unit tests
   - [ ] Run integration tests
   - [ ] Run E2E tests
   - [ ] Fix any failures

### Post-Migration

- [ ] Update CLAUDE.md with Phase 7A status
- [ ] Run full test suite: `pytest && pnpm test && pnpm e2e`
- [ ] Manual smoke test: Quick/Tools/Agent modes
- [ ] Monitor logs for errors: `tail -f data/logs/brain-runtime.log`

### Rollback Plan

If critical issues found:

1. Stop services: `pkill -f uvicorn && pkill -f next`
2. Restore database: `psql second_brain < backup_YYYYMMDD.sql`
3. Revert code: `git checkout HEAD~N .`
4. Restart services

---

## Appendix A: Fallback Agent Implementation

If Claude Agent SDK is unavailable, use custom implementation:

```python
"""Custom agent runtime without SDK."""

class CustomAgentRuntime:
    """Agent runtime using raw Anthropic API with tool loop."""

    async def execute(
        self,
        task: str,
        model: str,
        max_turns: int = 10,
    ) -> AsyncGenerator[dict, None]:
        provider = get_provider("anthropic")
        executor = ToolExecutor()

        messages = [{"role": "user", "content": task}]

        for turn in range(max_turns):
            async for event in provider.chat(
                messages=messages,
                tools=get_all_tools(),
                system=self._get_system_prompt(),
            ):
                # ... handle events and tool calls ...
                pass

            # If no tool calls, done
            if not pending_tool_calls:
                break

            # Execute tools and continue
            results = await executor.execute_all(pending_tool_calls)
            messages.append(...)  # Add tool results
```

---

## Success Criteria

Phase 7A is complete when:

1. ✅ Chat conversations persist across page reloads
2. ✅ LLM receives full conversation history from database
3. ✅ Tools execute successfully and results are sent back to LLM
4. ✅ Tool execution loop continues until text-only response
5. ✅ All Claude 4.5 models are available and selectable
6. ✅ Agent mode works with subagent spawning (if SDK available)
7. ✅ Proper error handling with consistent error format
8. ✅ All tests pass (unit, integration, E2E)
9. ✅ No regressions in existing functionality
