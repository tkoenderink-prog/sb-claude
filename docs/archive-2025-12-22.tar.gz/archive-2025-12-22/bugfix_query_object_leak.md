# Bug Fix: FastAPI Query() Object Leak in Skills API

## Problem

When `skills_tools.py` functions called `api/skills.py` functions directly (not via HTTP), FastAPI's `Query()` defaults were not resolved, causing `Query(None)` objects to leak into SQLAlchemy queries.

### Symptoms

```python
# In api/skills.py
async def list_skills(
    category: Optional[str] = Query(None, description="Filter by category"),
    db: AsyncSession = Depends(get_db),
):
    # When called via HTTP: category = None (resolved by FastAPI)
    # When called directly: category = Query(None) (not resolved!)

    if category:  # Query(None) is truthy! Bug!
        query = query.where(UserSkillDB.category == category)
        # SQLAlchemy error: "invalid input for query argument $1: Query(None)"
```

### Root Cause

FastAPI's `Query()` objects are only resolved to their default values when requests go through the FastAPI middleware. Direct Python function calls bypass this resolution, causing the `Query()` object itself to be passed as the parameter value.

## Solution

Created a clean separation between HTTP layer and business logic:

1. **New Internal Service Layer**: `/services/brain_runtime/core/skills_service.py`
   - Contains all business logic
   - No FastAPI dependencies
   - Works when called directly from tools OR via HTTP routes
   - Uses plain Python types: `Optional[str] = None`

2. **Simplified API Layer**: `/services/brain_runtime/api/skills.py`
   - Thin wrapper around internal service functions
   - Handles FastAPI concerns (Query params, HTTP exceptions, response models)
   - Delegates all logic to internal service

3. **Updated Tool Layer**: `/services/brain_runtime/core/tools/skills_tools.py`
   - Now calls internal service functions directly
   - No more FastAPI Query() objects in the call chain

## Architecture

```
┌─────────────────┐
│   HTTP Client   │
└────────┬────────┘
         │ GET /skills?category=workflow
         ↓
┌─────────────────────────────────────────┐
│  api/skills.py (FastAPI Route Handlers) │
│  - Query() parameter resolution          │
│  - HTTP exception handling               │
│  - Pydantic response models              │
└────────┬────────────────────────────────┘
         │ list_skills_internal(db, category="workflow")
         ↓
┌──────────────────────────────────────────┐
│  core/skills_service.py (Business Logic) │  ←─────────────┐
│  - No FastAPI dependencies               │                │
│  - Plain Optional[str] = None            │                │
│  - SQLAlchemy queries                    │                │
│  - Scanner integration                   │                │
└──────────────────────────────────────────┘                │
         ↑                                                   │
         │ list_skills_internal(db, category=None)          │
         │                                                   │
┌────────┴────────────────────────────────┐                │
│  core/tools/skills_tools.py (Tools)     │                │
│  - Registers Claude tools                │                │
│  - Gets DB session                       │                │
│  - Calls internal service directly       │ ───────────────┘
└──────────────────────────────────────────┘
```

## Changes

### Created Files

- **`core/skills_service.py`**: Internal service functions with no FastAPI dependencies
  - `list_skills_internal(db, source, category, search)`
  - `get_skill_internal(db, skill_id)`
  - `create_skill_internal(db, skill)`
  - `update_skill_internal(db, skill_id, updates)`
  - `delete_skill_internal(db, skill_id)`
  - `search_skills_internal(db, query)`
  - `get_skills_stats_internal(db)`
  - `get_categories_internal(db)`

- **`test_skills_fix.py`**: Verification tests ensuring tools can call service functions

### Modified Files

- **`api/skills.py`**: Simplified to thin wrappers calling internal service
- **`core/tools/skills_tools.py`**: Updated to call internal service functions

## Benefits

1. **Bug Fixed**: No more Query() object leak
2. **Clean Architecture**: Proper separation of concerns
3. **Testable**: Business logic can be tested without FastAPI
4. **Reusable**: Same logic works for HTTP API and internal tool calls
5. **Type Safe**: No implicit type conversions or FastAPI magic

## Testing

All tests pass:

```bash
cd services/brain_runtime
uv run python test_skills_fix.py
# ✓ list_skills with None parameters works
# ✓ category filtering works
# ✓ source filtering works
# ✓ search works
# ✓ stats works
# ✓ tool integration works
```

API endpoints verified:
- `GET /skills` - works
- `GET /skills?category=workflow` - works
- `GET /skills/stats` - works

Tool functions verified:
- `list_skills()` - works
- `list_skills(category="workflow")` - works

## Lessons Learned

1. **Never mix HTTP layer with business logic**: FastAPI decorators should only be in route handlers
2. **Test direct function calls**: Unit tests should call functions directly, not via HTTP
3. **Watch for truthy objects**: `Query(None)` is truthy even though it represents None
4. **Separate concerns**: HTTP, business logic, and data access should be distinct layers

## Related Files

- `/services/brain_runtime/core/skills_service.py` - Internal service layer
- `/services/brain_runtime/api/skills.py` - HTTP API layer
- `/services/brain_runtime/core/tools/skills_tools.py` - Tool wrappers
- `/services/brain_runtime/test_skills_fix.py` - Verification tests

---

**Status**: ✅ Fixed and Tested (2025-12-21)
