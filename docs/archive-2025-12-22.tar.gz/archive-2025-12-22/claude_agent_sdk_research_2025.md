# Claude Agent SDK and Agentic Patterns Research (Late 2025)

**Research Date:** 2025-12-21
**Focus:** Official Anthropic capabilities vs custom implementation requirements

---

## Executive Summary

**Yes, Anthropic has an official Claude Agent SDK** (released late 2025). It's the production-ready infrastructure that powers Claude Code, now available to all developers. The SDK provides native support for agent loops, tool execution, multi-agent orchestration via subagents, and artifact creation.

### Key Takeaways for Second Brain Implementation

1. **Use the official SDK** - Don't build custom agent loops from scratch
2. **MCP is the tool integration standard** - Both in-process and external servers supported
3. **Subagents are built-in** - Parallel execution with isolated context windows
4. **Extended thinking available** - Claude 3.7+ with up to 128K thinking tokens
5. **Multi-agent patterns documented** - Orchestrator-worker is the recommended architecture

---

## 1. Claude Agent SDK Overview

### What It Is

The **Claude Agent SDK** (formerly Claude Code SDK) is Anthropic's official framework for building production-ready AI agents. Released alongside Claude Sonnet 4.5 in late 2025, it provides:

- **Agent loop infrastructure** with feedback cycles
- **Built-in tool execution** (file system, bash, code generation)
- **Subagent spawning** for parallel task execution
- **Context management** (compaction, semantic search)
- **MCP integration** (Model Context Protocol for tools)
- **Hooks system** for deterministic control

### Official Repositories

- **Python SDK:** https://github.com/anthropics/claude-agent-sdk-python
- **TypeScript SDK:** https://github.com/anthropics/claude-agent-sdk-typescript
- **NPM Package:** `@anthropic-ai/claude-agent-sdk`
- **PyPI Package:** `claude-agent-sdk`

### Installation

```bash
# Python (requires Python 3.10+)
pip install claude-agent-sdk

# TypeScript/Node
npm install @anthropic-ai/claude-agent-sdk
```

**Note:** The Claude Code CLI is automatically bundled with the SDK - no separate installation required.

---

## 2. Core Architecture Components

### 2.1 Agent Loop Framework

The SDK implements a structured feedback cycle:

```
Gather Context → Take Action → Verify Work → Repeat
```

This enables agents to:
- Autonomously manage information retrieval
- Self-correct based on verification results
- Iterate until task completion or failure

### 2.2 Context Management Features

#### Dynamic Context Loading
Agents use bash commands (`grep`, `tail`) to load information on-demand rather than relying on static context windows. The folder structure itself becomes "a form of context engineering."

#### Subagents (Built-in)
- Parallel task execution with isolated context windows
- Prevents information bloat in main agent context
- Results passed back to orchestrator for synthesis

#### Compaction
- Automatic message summarization to prevent context exhaustion
- Preserves essential information while managing token limits

#### Semantic Search (Optional)
- Vector embeddings for faster information retrieval
- Trade-off: speed vs accuracy

### 2.3 Tool Execution System

**Built-in Tools:**
- `Bash` - Execute shell commands
- `Read` - Read file contents
- `Write` - Write/edit files
- Custom tools via MCP servers

**Model Context Protocol (MCP):**
- Standardized third-party integrations
- Automatic authentication handling
- Both in-process (SDK MCP servers) and external servers supported

### 2.4 Verification Systems

- **Rule-based feedback:** Code linting, formal validation
- **Visual feedback:** Screenshots for UI/design verification
- **LLM-as-judge:** Secondary model evaluation (higher latency)

---

## 3. Python SDK API Reference

### 3.1 Simple Queries with `query()`

```python
import anyio
from claude_agent_sdk import query, ClaudeAgentOptions

async def main():
    # Basic query
    async for message in query(prompt="What is 2 + 2?"):
        print(message)

    # With options
    options = ClaudeAgentOptions(
        system_prompt="You are a helpful assistant",
        max_turns=1,
        allowed_tools=["Read", "Write", "Bash"],
        permission_mode='acceptEdits',  # auto-accept file edits
        cwd="/path/to/project"
    )

    async for message in query(prompt="Create a hello.py file", options=options):
        pass

anyio.run(main)
```

### 3.2 Interactive Conversations with `ClaudeSDKClient`

For bidirectional communication and advanced features:

```python
from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions

options = ClaudeAgentOptions(
    allowed_tools=["Bash"],
    permission_mode='acceptEdits'
)

async with ClaudeSDKClient(options=options) as client:
    await client.query("List files in current directory")
    async for msg in client.receive_response():
        print(msg)
```

### 3.3 Custom Tools (In-Process MCP Servers)

Define Python functions as tools without external processes:

```python
from claude_agent_sdk import tool, create_sdk_mcp_server, ClaudeAgentOptions, ClaudeSDKClient

# Define tool with decorator
@tool("greet", "Greet a user", {"name": str})
async def greet_user(args):
    return {
        "content": [
            {"type": "text", "text": f"Hello, {args['name']}!"}
        ]
    }

# Create SDK MCP server
server = create_sdk_mcp_server(
    name="my-tools",
    version="1.0.0",
    tools=[greet_user]
)

# Use with Claude
options = ClaudeAgentOptions(
    mcp_servers={"tools": server},
    allowed_tools=["mcp__tools__greet"]
)

async with ClaudeSDKClient(options=options) as client:
    await client.query("Greet Alice")
    async for msg in client.receive_response():
        print(msg)
```

**Benefits:**
- No subprocess management
- Better performance (no IPC overhead)
- Simpler deployment (single Python process)
- Easier debugging
- Type safety with Python type hints

### 3.4 Hooks System

Hooks are deterministic functions invoked at specific points in the agent loop:

```python
from claude_agent_sdk import ClaudeAgentOptions, ClaudeSDKClient, HookMatcher

async def check_bash_command(input_data, tool_use_id, context):
    tool_name = input_data["tool_name"]
    tool_input = input_data["tool_input"]

    if tool_name != "Bash":
        return {}

    command = tool_input.get("command", "")

    # Block dangerous commands
    block_patterns = ["rm -rf", "sudo"]
    for pattern in block_patterns:
        if pattern in command:
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": f"Blocked: {pattern}",
                }
            }
    return {}

options = ClaudeAgentOptions(
    allowed_tools=["Bash"],
    hooks={
        "PreToolUse": [
            HookMatcher(matcher="Bash", hooks=[check_bash_command]),
        ],
    }
)
```

---

## 4. Multi-Agent Patterns

### 4.1 Anthropic's Recommended Architecture: Orchestrator-Worker

Anthropic's multi-agent research system uses a hierarchical design:

**Lead Agent (Orchestrator) Responsibilities:**
- Analyze incoming queries and develop strategies
- Spawn multiple subagents for parallel exploration
- Synthesize findings from subagents
- Determine if additional research is needed
- Save plans to persistent memory (handles 200K+ token limits)

**Subagent (Worker) Responsibilities:**
- Execute independent searches and tool calls in parallel
- Use interleaved thinking after retrieving results
- Evaluate information quality and identify gaps
- Return filtered findings to lead agent

### 4.2 Performance Results

Multi-agent system with:
- **Lead:** Claude Opus 4
- **Workers:** Claude Sonnet 4 subagents

**Outperformed single-agent Claude Opus 4 by 90.2%** on Anthropic's internal research eval.

### 4.3 Parallelization Strategy

Two types of parallelization:
1. **Agent-level:** Lead spawns 3-5 subagents simultaneously (not sequentially)
2. **Tool-level:** Individual subagents use 3+ tools in parallel

**Result:** Reduces research time by up to 90% for complex queries.

### 4.4 Token Costs

Multi-agent systems are expensive:
- **Chat interactions:** Baseline
- **Single agent:** ~4× more tokens than chat
- **Multi-agent:** ~15× more tokens than chat

**Recommendation:** Use multi-agent only for tasks with sufficient value to justify costs.

### 4.5 Context Management in Multi-Agent Systems

**Challenges:**
- Lead agent context fills up quickly with subagent outputs
- Need to bridge information across sessions

**Solutions:**
1. **Summarization:** Agents summarize completed work phases
2. **External storage:** Store essential information outside context
3. **Fresh spawns:** Create new subagents with clean contexts when approaching limits
4. **Lightweight references:** Pass references between agents, not full outputs

---

## 5. Extended Thinking (Claude 3.7+ and Claude 4)

### 5.1 What It Is

Extended thinking gives Claude enhanced reasoning capabilities for complex tasks while providing transparency into its step-by-step thought process.

### 5.2 Key Features

**Claude 3.7 Sonnet:**
- Dual mode: Normal LLM + reasoning model in one
- Controllable thinking budget up to 128K tokens (15× previous limit of 8K)
- Visible thinking process in responses

**Claude 4 Models:**
- **Interleaved thinking:** Think between tool calls, reason after receiving tool results
- **Summarized thinking:** Full intelligence benefits with condensed output
- **Billing:** Charged for full thinking tokens, not summary tokens

### 5.3 API Usage

```python
# Enable extended thinking (Claude 3.7+)
response = client.messages.create(
    model="claude-3-7-sonnet-20250219",
    max_tokens=4096,
    thinking={
        "type": "enabled",
        "budget_tokens": 10000  # Up to 128K for Claude 3.7
    },
    messages=[{"role": "user", "content": "Complex reasoning task..."}]
)
```

**Interleaved Thinking (Claude 4):**
```python
# Requires beta header
client = anthropic.Anthropic(
    default_headers={"anthropic-beta": "interleaved-thinking-2025-05-14"}
)
```

### 5.4 Use Cases

Best for:
- Complex reasoning tasks
- Multi-step problem solving
- Tasks requiring careful analysis before action
- Debugging and verification steps in agent workflows

---

## 6. Computer Use API

### 6.1 Overview

Claude's computer use ability allows it to:
- See user's computer screen (pixel input)
- Take actions (mouse clicks, keyboard input, navigation)
- Play games continuously beyond context limits
- Sustain gameplay through tens of thousands of interactions

### 6.2 Safety Measures

Anthropic has enhanced safety measures for computer use:
- Permission controls
- Action logging
- Sandboxing recommendations

### 6.3 Integration with Agent SDK

Computer use can be combined with:
- Extended thinking for reasoning about screen contents
- Tool use for coordinated actions
- Multi-agent patterns for complex UI automation

---

## 7. Model Context Protocol (MCP)

### 7.1 What It Is

MCP is an **open standard** (introduced November 2024) for connecting AI systems to external tools, systems, and data sources.

**Key Facts:**
- Initially developed by Anthropic
- Donated to the Agentic AI Foundation (Linux Foundation) in December 2025
- Adopted by OpenAI, Google, Microsoft, AWS, and others

### 7.2 Technical Specifications

- **Transport:** JSON-RPC 2.0 over stdio or HTTP (with optional SSE)
- **Design inspiration:** Language Server Protocol (LSP)
- **SDKs available:** Python, TypeScript, C#, Java

### 7.3 Latest Specification (November 25, 2025)

New features in the first anniversary release:
- **Asynchronous operations**
- **Statelessness**
- **Server identity**
- **Official extensions**
- **Tasks abstraction** (track work performed by MCP server)

### 7.4 Industry Adoption

- **OpenAI:** ChatGPT desktop app, Agents SDK, Responses API
- **Google:** Integration across products
- **Microsoft:** Azure AI Foundry support
- **AWS:** Amazon Bedrock AgentCore Runtime

### 7.5 Using MCP with Claude Agent SDK

**In-Process MCP Servers (Recommended for Python):**
```python
# Define tools as Python functions
@tool("search_docs", "Search documentation", {"query": str})
async def search_docs(args):
    results = perform_search(args["query"])
    return {"content": [{"type": "text", "text": results}]}

server = create_sdk_mcp_server(
    name="doc-tools",
    version="1.0.0",
    tools=[search_docs]
)

options = ClaudeAgentOptions(
    mcp_servers={"docs": server},
    allowed_tools=["mcp__docs__search_docs"]
)
```

**External MCP Servers:**
- Run as separate processes
- Communicate via stdio or HTTP
- Useful for third-party integrations (databases, APIs, etc.)

---

## 8. Agent-to-Agent (A2A) Protocol

### 8.1 What It Is

A2A is an open protocol for **agent-to-agent communication**, initially introduced by Google in April 2025, now under Linux Foundation governance.

### 8.2 Key Features

- **Capability discovery:** Agents advertise capabilities via "Agent Card" (JSON)
- **Task management:** Task-oriented communication between client and remote agents
- **Collaboration:** Agents exchange messages, context, artifacts, instructions
- **Modality agnostic:** Supports audio, video streaming, etc.

### 8.3 A2A vs MCP

**MCP:** AI applications ↔ external services (tools, data sources)
**A2A:** AI agents ↔ AI agents (collaboration, delegation)

**Recommendation:** Use both together.
- **MCP for tools**
- **A2A for agents**

### 8.4 Industry Support

Over 50 technology partners:
- Atlassian, Box, Cohere, Intuit, Langchain, MongoDB, PayPal, Salesforce, SAP, ServiceNow
- Service providers: Accenture, BCG, Deloitte, KPMG, McKinsey, PwC, etc.

### 8.5 Current Status

- **Microsoft:** Coming to Azure AI Foundry and Copilot Studio
- **AWS:** Amazon Bedrock AgentCore Runtime supports both MCP and A2A
- **Cross-framework compatibility:** Agents built with different SDKs can communicate

### 8.6 Claude's Approach to Multi-Agent

Anthropic (via Claude Code) uses a simplified design:
- **Subagents:** Perform information exploration tasks
- **Main agent:** Handles decision-making and writing work
- **Context optimization:** Move subagent history out of main context to preserve token space

**Note:** As of late 2025, Claude Agent SDK doesn't explicitly implement A2A protocol. Multi-agent communication happens through the SDK's built-in subagent spawning mechanism.

---

## 9. Best Practices for Autonomous Agents (Anthropic Recommendations)

### 9.1 Agentic Coding Patterns

**Planning First:**
- Ask Claude to make a plan before coding
- Explicitly tell it not to code until plan is confirmed
- Course-correct at any time, but front-load explanations

**Test-Driven Development:**
- Write tests based on expected input/output pairs
- Be explicit about TDD to avoid mock implementations
- Leverage agent's ability to iterate on failing tests

**Active Collaboration:**
- Auto-accept mode enables autonomy, but active guidance yields better results
- Balance automation with human oversight
- Interrupt and redirect when needed

### 9.2 Permission & Tool Management

**Principle:** Permission sprawl is the fastest path to unsafe autonomy.

**Best Practices:**
- Start from deny-all, allowlist only what's needed
- Don't give agents tools they don't need (increases confusion)
- Use clear, specific tool names (avoid "handler" or "processor")
- Validate inputs and provide context in error messages
- Make side effects explicit in tool descriptions

### 9.3 Multi-Agent Organization

**Orchestrator Pattern:**
- Give each subagent **one job**
- Orchestrator handles global planning, delegation, state
- Keep orchestrator permissions narrow ("read and route")

**Subagent Design:**
- Clear inputs/outputs
- Single goal per subagent
- Minimal tool access (only what's needed for their specific job)

**Coordination Patterns:**

1. **Sequential Pipeline** (deterministic workflows):
   ```
   Analyst → Architect → Implementer → Tester → Security Audit
   ```

2. **Parallel Specialization** (low dependencies):
   ```
   UI Agent + API Agent + DB Agent (running simultaneously)
   ```

### 9.4 Long-Running Agent Patterns

**Challenge:** Context windows are limited; complex projects span multiple sessions.

**Anthropic's Solution:**

1. **Initializer Agent:**
   - Sets up environment on first run
   - Creates initial structure and artifacts

2. **Coding Agent:**
   - Makes incremental progress in each session
   - Leaves clear artifacts for next session
   - Summarizes completed work

**Failure Modes to Avoid:**
- Marking features complete without end-to-end testing
- Not verifying implementation actually works
- Missing integration issues

**Solution:**
- Explicitly prompt Claude to use browser automation for testing
- Test as a human user would
- Verify features work end-to-end before marking complete

### 9.5 Model Selection Strategy (2025)

**Claude Haiku 4.5** (released October 2025):
- 90% of Sonnet 4.5's agentic coding performance
- 2× the speed
- 3× cost savings ($1/$5 vs $3/$15)
- **Recommendation:** Use for subagents to optimize cost/performance

**Token Budget Considerations:**
- Heavy custom agents (25K+ tokens): Create bottlenecks in multi-agent workflows
- Lightweight custom agents (<3K tokens): Enable fluid orchestration

### 9.6 Advanced Tool Use Features

**Tool Search Tool:**
- Allows Claude to discover and use thousands of tools
- Doesn't consume context window with all tool definitions
- Load tools on-demand

**Programmatic Tool Calling:**
- Invoke tools in code execution environment
- Reduces context window impact

**Tool Use Examples:**
- Provide examples of correct tool usage
- More effective than schema definitions alone

### 9.7 Observability & Safety

**Principle:** Autonomy without visibility is risk.

**Requirements:**
- OpenTelemetry traces for prompts, tool invocations, token usage, orchestration
- Correlation IDs across subagents
- Rollback mechanisms
- Cost monitoring
- Error handling
- Human oversight for critical operations

**Testing Strategy:**
- Start simple
- Test thoroughly
- Gradually expand capabilities
- Monitor costs continuously

---

## 10. Anthropic's 6 Composable Agentic Patterns

### 1. Prompt Chaining
Break complex tasks into sequential prompts, where each output feeds into the next.

### 2. Routing
Classify input and route to specialized prompts or models.

### 3. Parallelization
Run multiple prompts simultaneously for independent subtasks.

### 4. Orchestrator-Workers
Central orchestrator coordinates multiple worker agents.

### 5. Evaluator-Optimizer
One agent evaluates outputs, another optimizes based on feedback.

### 6. Multi-Agent Research
Lead agent spawns subagents for parallel exploration and synthesis.

---

## 11. Implementation Recommendations for Second Brain

### 11.1 What to Use from Anthropic's Official SDK

✅ **Use the Claude Agent SDK directly:**
- Don't build custom agent loops from scratch
- Leverage built-in subagent spawning
- Use in-process MCP servers for tools (simpler than external)
- Implement hooks for safety controls

✅ **Tool Integration:**
- Wrap Phase 1-6 APIs as MCP tools using `@tool` decorator
- Create SDK MCP server with all tools
- Let Claude discover and use tools dynamically

✅ **Multi-Agent Patterns:**
- **Quick Chat:** Direct LLM calls (no SDK needed, just Anthropic client)
- **Tool-Enabled Chat:** Single agent with tool access via SDK
- **Agent Mode:** Orchestrator-worker pattern with subagents

### 11.2 What to Build Custom

⚠️ **Custom implementations needed:**

1. **Provider Abstraction:**
   - SDK is Claude-specific
   - For OpenAI support, build separate integration
   - Shared interface for different providers

2. **Session Management:**
   - SDK doesn't handle multi-session persistence
   - Build database layer for chat history
   - Manage session state across conversations

3. **Artifact System:**
   - SDK doesn't define artifact storage/retrieval
   - Build artifact registry
   - Track agent-produced outputs

4. **Agent Run Tracking:**
   - SDK doesn't provide run history database
   - Build agent_runs table
   - Store metrics, outputs, traces

### 11.3 Proposed Architecture for Phase 7

```
┌─────────────────────────────────────────────────────────────┐
│                     Frontend (Next.js)                       │
│  - ChatContainer, MessageList, ToolCallCard                 │
│  - ModeSelector (Quick/Tools/Agent)                         │
│  - ProviderSelector (Claude/GPT + model)                    │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ HTTP + SSE
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                FastAPI Backend (Brain Runtime)               │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Chat API (/chat)                        │  │
│  │  - Handles all 3 modes                               │  │
│  │  - SSE streaming                                     │  │
│  └──────────────────────────────────────────────────────┘  │
│                              │                              │
│              ┌───────────────┼───────────────┐              │
│              ▼               ▼               ▼              │
│  ┌────────────────┐ ┌──────────────┐ ┌──────────────────┐  │
│  │  Quick Chat    │ │ Tool-Enabled │ │   Agent Mode     │  │
│  │                │ │              │ │                  │  │
│  │  Direct call   │ │  Use Claude  │ │  Use Claude      │  │
│  │  to Anthropic  │ │  Agent SDK   │ │  Agent SDK with  │  │
│  │  or OpenAI     │ │  with tools  │ │  subagents       │  │
│  │  client        │ │              │ │                  │  │
│  └────────────────┘ └──────────────┘ └──────────────────┘  │
│                              │                              │
│                              ▼                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │     SDK MCP Server (In-Process Tools)                │  │
│  │  - @tool decorators wrapping Phase 1-6 APIs         │  │
│  │  - get_today_events, query_tasks, semantic_search   │  │
│  │  - read_vault_file, list_vault_directory, etc.      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │     Session Manager (Custom)                         │  │
│  │  - PostgreSQL: chat_sessions, chat_messages          │  │
│  │  - CRUD operations for sessions                      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │     Agent Run Manager (Custom)                       │  │
│  │  - PostgreSQL: agent_runs, agent_artifacts           │  │
│  │  - Track orchestrator + subagent execution           │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 11.4 Implementation Steps

**Step 1: Install SDK**
```bash
cd services/brain_runtime
uv add claude-agent-sdk anthropic
```

**Step 2: Create SDK MCP Tools**
```python
# services/brain_runtime/core/agent_tools.py

from claude_agent_sdk import tool, create_sdk_mcp_server
import httpx

@tool("get_today_events", "Get today's calendar events", {})
async def get_today_events(args):
    # Call existing /calendar/today endpoint
    async with httpx.AsyncClient() as client:
        response = await client.get("http://localhost:8000/calendar/today")
        data = response.json()
    return {"content": [{"type": "text", "text": str(data)}]}

@tool("query_tasks", "Query tasks with filters", {"filter": str})
async def query_tasks(args):
    # Call existing /tasks/query endpoint
    async with httpx.AsyncClient() as client:
        response = await client.get(
            "http://localhost:8000/tasks/query",
            params={"filter": args.get("filter", "all")}
        )
        data = response.json()
    return {"content": [{"type": "text", "text": str(data)}]}

# Add more tools for all Phase 1-6 capabilities...

# Create SDK MCP server
brain_tools_server = create_sdk_mcp_server(
    name="brain-tools",
    version="1.0.0",
    tools=[
        get_today_events,
        query_tasks,
        # ... all other tools
    ]
)
```

**Step 3: Implement Chat Modes**

```python
# services/brain_runtime/api/chat.py

from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions
from anthropic import Anthropic
import asyncio

async def handle_quick_chat(prompt: str, provider: str, model: str):
    """Quick chat - direct LLM call, no tools"""
    if provider == "anthropic":
        client = Anthropic()
        with client.messages.stream(
            model=model,
            max_tokens=4096,
            messages=[{"role": "user", "content": prompt}]
        ) as stream:
            for text in stream.text_stream:
                yield {"type": "assistant", "data": text}
    elif provider == "openai":
        # OpenAI implementation
        pass

async def handle_tool_enabled_chat(prompt: str, model: str):
    """Tool-enabled chat - Claude Agent SDK with tools"""
    from .core.agent_tools import brain_tools_server

    options = ClaudeAgentOptions(
        model=model,
        mcp_servers={"brain": brain_tools_server},
        allowed_tools=["mcp__brain__*"],  # All brain tools
        permission_mode="acceptEdits",
        max_turns=10
    )

    async with ClaudeSDKClient(options=options) as client:
        await client.query(prompt)
        async for msg in client.receive_response():
            # Convert SDK message to SSE format
            yield convert_message_to_sse(msg)

async def handle_agent_mode(task: str, model: str):
    """Agent mode - orchestrator + subagents"""
    from .core.agent_tools import brain_tools_server

    # Orchestrator options
    orchestrator_options = ClaudeAgentOptions(
        model=model,
        system_prompt="""You are an orchestrator agent. Break down complex
        tasks and spawn subagents to explore different aspects in parallel.""",
        mcp_servers={"brain": brain_tools_server},
        allowed_tools=["mcp__brain__*"],
        permission_mode="acceptEdits",
        max_turns=20
    )

    async with ClaudeSDKClient(options=orchestrator_options) as orchestrator:
        await orchestrator.query(task)

        # Orchestrator will spawn subagents automatically
        # SDK handles parallel execution and result synthesis

        async for msg in orchestrator.receive_response():
            # Track in agent_runs table
            # Save artifacts to agent_artifacts table
            yield convert_message_to_sse(msg)

@router.post("/chat")
async def chat(request: ChatRequest):
    """SSE endpoint for all chat modes"""
    async def event_generator():
        if request.mode == "quick":
            async for event in handle_quick_chat(
                request.prompt, request.provider, request.model
            ):
                yield f"data: {json.dumps(event)}\n\n"

        elif request.mode == "tools":
            async for event in handle_tool_enabled_chat(
                request.prompt, request.model
            ):
                yield f"data: {json.dumps(event)}\n\n"

        elif request.mode == "agent":
            async for event in handle_agent_mode(
                request.prompt, request.model
            ):
                yield f"data: {json.dumps(event)}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")
```

**Step 4: Add Safety Hooks**

```python
# services/brain_runtime/core/safety_hooks.py

from claude_agent_sdk import HookMatcher

async def validate_file_access(input_data, tool_use_id, context):
    """Ensure file operations are within vault bounds"""
    tool_name = input_data["tool_name"]
    tool_input = input_data["tool_input"]

    if tool_name in ["Read", "Write"]:
        file_path = tool_input.get("file_path", "")
        vault_root = os.getenv("OBSIDIAN_VAULT_PATH")

        # Path sandboxing check
        if not is_safe_path(file_path, vault_root):
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": "Path outside vault",
                }
            }

    return {}

async def log_bash_commands(input_data, tool_use_id, context):
    """Log all bash commands for audit"""
    tool_name = input_data["tool_name"]
    tool_input = input_data["tool_input"]

    if tool_name == "Bash":
        command = tool_input.get("command", "")
        logger.info(f"Agent executing bash: {command}")

    return {}

# Add to options:
# hooks={
#     "PreToolUse": [
#         HookMatcher(matcher="Read", hooks=[validate_file_access]),
#         HookMatcher(matcher="Write", hooks=[validate_file_access]),
#         HookMatcher(matcher="Bash", hooks=[log_bash_commands]),
#     ],
# }
```

### 11.5 Database Schema (No Changes Needed)

The proposed schema in Phase 7 doc is already correct:
- `chat_sessions` - Store sessions with metadata
- `chat_messages` - Store messages with role, content, tool calls
- `agent_runs` - Track agent mode executions
- `agent_artifacts` - Store agent-produced outputs

SDK doesn't provide persistence - we build this custom layer.

### 11.6 What NOT to Build

❌ **Don't reinvent:**
- Agent loop logic (use SDK)
- Tool execution framework (use MCP)
- Subagent spawning (use SDK's built-in)
- Context compaction (SDK handles automatically)
- Thinking/reasoning loops (use extended thinking API)

---

## 12. Latest Model Capabilities (Late 2025)

### Available Models

**Claude 3.7 Sonnet:**
- Extended thinking up to 128K tokens
- Dual mode: normal + reasoning
- Released: February 2025

**Claude 4 Family:**
- Opus 4, Opus 4.5, Sonnet 4, Sonnet 4.5, Haiku 4.5
- Interleaved thinking (think between tool calls)
- Summarized thinking
- Effort parameter (Opus 4.5): low/medium/high
- Computer use capabilities

**Claude Haiku 4.5:**
- Best cost/performance for agentic tasks
- 90% of Sonnet 4.5 performance
- 2× speed, 3× cost savings
- **Recommendation:** Use for subagents

### Pricing (Approximate)

| Model | Input ($/MTok) | Output ($/MTok) |
|-------|----------------|-----------------|
| Claude Haiku 4.5 | $1 | $5 |
| Claude Sonnet 4.5 | $3 | $15 |
| Claude Opus 4.5 | Higher | Higher |

### Extended Thinking Costs

**Important:** You're charged for full thinking tokens, not summary tokens. With 128K thinking budget, costs can be significant.

**Use when:**
- Complex reasoning required
- Accuracy more important than speed/cost
- Multi-step planning needed

**Avoid when:**
- Simple queries
- Budget constraints
- Speed is priority

---

## 13. Key Differences: Custom Implementation vs SDK

| Feature | Custom (Phase 7 Original Plan) | Official SDK |
|---------|-------------------------------|--------------|
| Agent loop | Build from scratch | Built-in ✅ |
| Tool execution | Custom registry + executor | MCP standard ✅ |
| Subagents | Custom spawning logic | Built-in parallel execution ✅ |
| Context management | Manual chunking | Automatic compaction ✅ |
| Hooks/safety | Custom middleware | Built-in hook system ✅ |
| Multi-provider | Build abstraction layer | Claude-only (need custom for OpenAI) ⚠️ |
| Session persistence | Build custom | Not included (need custom) ⚠️ |
| Artifact tracking | Build custom | Not included (need custom) ⚠️ |

**Recommendation:** Use SDK for agent mechanics, build custom for persistence and multi-provider support.

---

## 14. Migration Path from Phase 7 Original Plan

### Changes Required

1. **Replace custom agent loop with SDK:**
   - Remove `core/agent_runtime.py` custom loop
   - Use `ClaudeSDKClient` instead

2. **Replace custom tool registry with MCP:**
   - Keep tool definitions (they map to Phase 1-6 APIs)
   - Wrap with `@tool` decorator
   - Use `create_sdk_mcp_server` instead of custom registry

3. **Keep session management:**
   - SDK doesn't handle persistence
   - Keep `chat_sessions` and `chat_messages` tables
   - Integrate SDK responses into database

4. **Keep provider abstraction for OpenAI:**
   - SDK is Claude-only
   - Keep separate OpenAI integration for Quick Chat mode

5. **Simplify agent mode:**
   - No need for custom orchestrator logic
   - SDK handles subagent spawning and synthesis
   - Just configure options and let SDK run

### What Stays the Same

✅ Database schema (chat_sessions, chat_messages, agent_runs, agent_artifacts)
✅ Frontend components (ChatContainer, MessageList, etc.)
✅ API endpoints (/chat, /agent/run, etc.)
✅ SSE streaming (convert SDK messages to SSE format)
✅ Phase 1-6 APIs (tools wrap these endpoints)

---

## 15. Open Questions & Future Research

### Questions to Investigate

1. **A2A Integration:**
   - Does SDK support A2A protocol natively?
   - If not, when is support planned?
   - Can we integrate A2A manually for cross-agent communication?

2. **Extended Thinking in Agent Mode:**
   - Does SDK automatically use extended thinking for subagents?
   - Can we configure thinking budget per subagent?
   - How to optimize thinking costs in multi-agent workflows?

3. **Computer Use in SDK:**
   - Is computer use available as a built-in tool?
   - How to enable screen capture and UI automation?
   - Safety considerations for autonomous screen control?

4. **Long-Running Sessions:**
   - Does SDK handle session resumption automatically?
   - How to implement "initializer + coding agent" pattern?
   - Best practices for artifact handoff between sessions?

### Future Enhancements

- **A2A support** for inter-agent delegation
- **External MCP servers** for third-party integrations (databases, APIs)
- **Computer use** for UI testing and automation
- **Custom subagent specializations** (CalendarAnalyst, TaskAnalyst, etc.)
- **Observability dashboards** with OpenTelemetry traces

---

## Sources

### Official Anthropic Resources
- [Building agents with the Claude Agent SDK](https://www.anthropic.com/engineering/building-agents-with-the-claude-agent-sdk)
- [Claude Agent SDK Python Repository](https://github.com/anthropics/claude-agent-sdk-python)
- [Claude Agent SDK TypeScript Repository](https://github.com/anthropics/claude-agent-sdk-typescript)
- [How we built our multi-agent research system](https://www.anthropic.com/engineering/multi-agent-research-system)
- [Effective harnesses for long-running agents](https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents)
- [Claude Code: Best practices for agentic coding](https://www.anthropic.com/engineering/claude-code-best-practices)
- [Advanced tool use on Claude Developer Platform](https://www.anthropic.com/engineering/advanced-tool-use)

### Extended Thinking & API
- [Building with extended thinking - Claude Docs](https://docs.claude.com/en/docs/build-with-claude/extended-thinking)
- [Claude's extended thinking announcement](https://www.anthropic.com/news/visible-extended-thinking)
- [Extended thinking - Amazon Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/claude-messages-extended-thinking.html)

### Model Context Protocol (MCP)
- [Introducing the Model Context Protocol](https://www.anthropic.com/news/model-context-protocol)
- [MCP Specification (November 25, 2025)](https://modelcontextprotocol.io/specification/2025-11-25)
- [One Year of MCP: November 2025 Spec Release](http://blog.modelcontextprotocol.io/posts/2025-11-25-first-mcp-anniversary/)
- [Donating MCP to Agentic AI Foundation](https://www.anthropic.com/news/donating-the-model-context-protocol-and-establishing-of-the-agentic-ai-foundation)
- [Model Context Protocol - Wikipedia](https://en.wikipedia.org/wiki/Model_Context_Protocol)

### Agent-to-Agent (A2A) Protocol
- [Announcing the Agent2Agent Protocol (A2A) - Google](https://developers.googleblog.com/en/a2a-a-new-era-of-agent-interoperability/)
- [A2A Protocol Official Site](https://a2a-protocol.org/latest/)
- [What Is Agent2Agent (A2A) Protocol? | IBM](https://www.ibm.com/think/topics/agent2agent-protocol)
- [Microsoft: Empowering multi-agent apps with A2A](https://www.microsoft.com/en-us/microsoft-cloud/blog/2025/05/07/empowering-multi-agent-apps-with-the-open-agent2agent-a2a-protocol/)

### Best Practices & Patterns
- [Claude Agent SDK Best Practices (2025)](https://skywork.ai/blog/claude-agent-sdk-best-practices-ai-agents-2025/)
- [Building AI Agents with Anthropic's 6 Composable Patterns](https://research.aimultiple.com/building-ai-agents/)
- [Claude and Autonomous Agents: Practical Implementation Guide](https://collabnix.com/claude-and-autonomous-agents-practical-implementation-guide/)
- [Agentic Coding Recommendations - Armin Ronacher](https://lucumr.pocoo.org/2025/6/12/agentic-coding/)

### Community & Analysis
- [Anthropic's multi-agent research system raises the bar](https://centific.com/news-and-press/anthropic-s-multi-agent-research-system-raises-the-bar-for-open-ended-ai-reasoning)
- [Reverse Engineering Anthropic's Agent Blueprint](https://agentissue.medium.com/reverse-engineering-anthropics-agent-blueprint-to-outperform-claude-opus-4-by-90-564f20a0e0a3)
- [Simon Willison: Anthropic's multi-agent research system](https://simonwillison.net/2025/Jun/14/multi-agent-research-system/)
