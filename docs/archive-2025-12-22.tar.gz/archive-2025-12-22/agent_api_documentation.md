# Agent API Documentation

## Overview

The Agent API provides endpoints for running autonomous AI agent tasks with Server-Sent Events (SSE) streaming. Agents can execute multi-turn conversations, use tools to gather information, and produce artifacts.

## Base URL

```
http://localhost:8000/agent
```

## Endpoints

### POST /agent/run

Start an autonomous agent task with SSE streaming.

**Request Body:**
```json
{
  "task": "Analyze my calendar for next week and identify potential conflicts",
  "context": "Focus on work meetings, ignore personal events",
  "tools": null,
  "max_turns": 10,
  "attached_skills": ["calendar-assistant", "task-analyzer"]
}
```

**Request Parameters:**
- `task` (string, required): Task description for the agent
- `context` (string, optional): Additional context to guide the agent
- `tools` (array[string], optional): List of tool names to make available (null = all tools)
- `max_turns` (integer, optional): Maximum conversation turns (default: 10)
- `attached_skills` (array[string], optional): Skills to include in system prompt

**Response:**
Server-Sent Events stream with the following event types:

#### Event: status
Emitted when run status changes.
```json
{
  "type": "status",
  "data": {
    "run_id": "123e4567-e89b-12d3-a456-426614174000",
    "status": "running",
    "turns": 1
  },
  "timestamp": "2025-12-20T10:30:00Z"
}
```

#### Event: text
Emitted for streaming text content from the agent.
```json
{
  "type": "text",
  "data": "I'll analyze your calendar for next week...",
  "timestamp": "2025-12-20T10:30:01Z"
}
```

#### Event: tool_call
Emitted when the agent invokes a tool.
```json
{
  "type": "tool_call",
  "data": {
    "id": "tool_call_abc123",
    "tool": "get_week_events",
    "arguments": {
      "start_date": "2025-12-23",
      "end_date": "2025-12-30"
    },
    "status": "pending"
  },
  "timestamp": "2025-12-20T10:30:02Z"
}
```

#### Event: tool_result
Emitted with the result of a tool execution.
```json
{
  "type": "tool_result",
  "data": {
    "tool_call_id": "tool_call_abc123",
    "result": {
      "events": [
        {"title": "Team standup", "start": "2025-12-23T10:00:00"}
      ]
    },
    "error": null
  },
  "timestamp": "2025-12-20T10:30:03Z"
}
```

#### Event: usage
Emitted with token usage and cost information.
```json
{
  "type": "usage",
  "data": {
    "input_tokens": 1500,
    "output_tokens": 300,
    "total_tokens": 1800,
    "estimated_cost_usd": 0.0234
  },
  "timestamp": "2025-12-20T10:30:10Z"
}
```

#### Event: error
Emitted when an error occurs.
```json
{
  "type": "error",
  "data": {
    "error": "Error message here"
  },
  "timestamp": "2025-12-20T10:30:15Z"
}
```

#### Event: done
Emitted when the agent completes successfully.
```json
{
  "type": "done",
  "data": {
    "run_id": "123e4567-e89b-12d3-a456-426614174000",
    "turns": 3,
    "tool_calls": 5
  },
  "timestamp": "2025-12-20T10:30:20Z"
}
```

**Response Headers:**
- `X-Run-ID`: The unique identifier for this agent run

**Example cURL:**
```bash
curl -N -X POST http://localhost:8000/agent/run \
  -H "Content-Type: application/json" \
  -d '{
    "task": "Analyze my tasks and calendar for tomorrow",
    "max_turns": 10
  }'
```

---

### GET /agent/runs

List recent agent runs.

**Query Parameters:**
- `limit` (integer, optional): Maximum number of runs to return (default: 50)

**Response:**
```json
[
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "task": "Analyze my calendar for next week",
    "status": "completed",
    "started_at": "2025-12-20T10:30:00Z",
    "ended_at": "2025-12-20T10:30:25Z",
    "turns": 3,
    "tool_calls": 5,
    "artifacts": [],
    "usage": {
      "input_tokens": 1500,
      "output_tokens": 300,
      "total_tokens": 1800,
      "estimated_cost_usd": 0.0234
    }
  }
]
```

**Example cURL:**
```bash
curl http://localhost:8000/agent/runs?limit=10
```

---

### GET /agent/runs/{run_id}

Get details of a specific agent run.

**Path Parameters:**
- `run_id` (string, required): Agent run ID

**Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "task": "Analyze my calendar for next week and identify conflicts",
  "status": "completed",
  "started_at": "2025-12-20T10:30:00Z",
  "ended_at": "2025-12-20T10:30:25Z",
  "turns": 3,
  "tool_calls": 5,
  "artifacts": [
    {
      "id": "artifact_xyz",
      "name": "calendar_analysis.md",
      "type": "analysis",
      "mime_type": "text/markdown",
      "size_bytes": 4096,
      "download_url": "/api/agent/runs/123e4567-e89b-12d3-a456-426614174000/artifacts/artifact_xyz",
      "created_at": "2025-12-20T10:30:20Z"
    }
  ],
  "usage": {
    "input_tokens": 1500,
    "output_tokens": 300,
    "total_tokens": 1800,
    "estimated_cost_usd": 0.0234
  }
}
```

**Errors:**
- `404 Not Found`: Agent run not found

**Example cURL:**
```bash
curl http://localhost:8000/agent/runs/123e4567-e89b-12d3-a456-426614174000
```

---

### GET /agent/runs/{run_id}/artifacts

List all artifacts produced by an agent run.

**Path Parameters:**
- `run_id` (string, required): Agent run ID

**Response:**
```json
[
  {
    "id": "artifact_xyz",
    "name": "calendar_analysis.md",
    "type": "analysis",
    "mime_type": "text/markdown",
    "size_bytes": 4096,
    "download_url": "/api/agent/runs/123e4567-e89b-12d3-a456-426614174000/artifacts/artifact_xyz",
    "created_at": "2025-12-20T10:30:20Z"
  }
]
```

**Errors:**
- `404 Not Found`: Agent run not found

**Example cURL:**
```bash
curl http://localhost:8000/agent/runs/123e4567-e89b-12d3-a456-426614174000/artifacts
```

---

### GET /agent/runs/{run_id}/artifacts/{artifact_id}

Download an artifact file.

**Path Parameters:**
- `run_id` (string, required): Agent run ID
- `artifact_id` (string, required): Artifact ID

**Response:**
File download with appropriate MIME type and filename headers.

**Errors:**
- `404 Not Found`: Artifact not found or file missing

**Example cURL:**
```bash
curl -O -J http://localhost:8000/agent/runs/123e4567-e89b-12d3-a456-426614174000/artifacts/artifact_xyz
```

---

### POST /agent/runs/{run_id}/cancel

Cancel a running agent.

**Path Parameters:**
- `run_id` (string, required): Agent run ID

**Response:**
```json
{
  "message": "Agent run 123e4567-e89b-12d3-a456-426614174000 cancelled",
  "run_id": "123e4567-e89b-12d3-a456-426614174000"
}
```

**Errors:**
- `404 Not Found`: Agent run not found
- `400 Bad Request`: Run is not in 'running' status

**Example cURL:**
```bash
curl -X POST http://localhost:8000/agent/runs/123e4567-e89b-12d3-a456-426614174000/cancel
```

---

## Database Schema

### agent_runs table
```sql
CREATE TABLE agent_runs (
  id UUID PRIMARY KEY,
  task TEXT NOT NULL,
  status VARCHAR(20) NOT NULL,  -- 'running', 'completed', 'failed', 'cancelled'
  attached_skills JSON,
  turns INTEGER DEFAULT 0,
  tool_calls INTEGER DEFAULT 0,
  input_tokens INTEGER DEFAULT 0,
  output_tokens INTEGER DEFAULT 0,
  started_at TIMESTAMP WITH TIME ZONE,
  ended_at TIMESTAMP WITH TIME ZONE
);
```

### agent_artifacts table
```sql
CREATE TABLE agent_artifacts (
  id UUID PRIMARY KEY,
  run_id UUID NOT NULL,  -- Foreign key to agent_runs
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL,  -- 'report', 'analysis', 'export', 'code', 'other'
  mime_type VARCHAR(100) NOT NULL,
  size_bytes INTEGER NOT NULL,
  storage_path TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE
);
```

---

## Implementation Details

### Agent Runtime

The `AgentRuntime` class manages autonomous agent execution:

1. **System Prompt Construction**: Builds a prompt with task description, context, and attached skills
2. **Agent Loop**: Iterates up to `max_turns`, making LLM calls and executing tools
3. **Tool Execution**: Calls tools based on LLM responses (currently stubbed, pending tool registry integration)
4. **Token Tracking**: Accumulates input/output tokens and calculates cost
5. **Event Streaming**: Emits SSE events for all significant actions

### Artifact Manager

The `ArtifactManager` class handles artifact storage:

- Stores artifacts in `exports/artifacts/{run_id}/` directory
- Provides methods to save and retrieve artifact files
- Generates download URLs for artifacts

### Cost Estimation

Token costs are estimated based on Claude Sonnet 4 pricing:
- **Input tokens**: $3 per million tokens
- **Output tokens**: $15 per million tokens

### TODO Items

1. **Tool Registry Integration**: Replace stub tool execution with actual tool registry
2. **Task Cancellation**: Implement actual task cancellation (currently just marks as cancelled)
3. **Artifact Creation**: Add logic for agents to create and save artifacts
4. **Skills Loading**: Integrate skills content into system prompt
5. **Error Recovery**: Add retry logic and error recovery strategies

---

## Example Usage

### JavaScript/TypeScript Client

```typescript
async function runAgent(task: string) {
  const response = await fetch('http://localhost:8000/agent/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      task,
      max_turns: 10,
      attached_skills: ['calendar-assistant']
    })
  });

  const runId = response.headers.get('X-Run-ID');
  console.log('Run ID:', runId);

  const reader = response.body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value);
    const lines = chunk.split('\n\n');

    for (const line of lines) {
      if (!line.trim()) continue;

      const [eventLine, dataLine] = line.split('\n');
      const eventType = eventLine.replace('event: ', '');
      const eventData = JSON.parse(dataLine.replace('data: ', ''));

      console.log(`[${eventType}]`, eventData);

      if (eventType === 'text') {
        process.stdout.write(eventData.data);
      }
    }
  }
}

// Usage
runAgent('Analyze my calendar for tomorrow and list all meetings');
```

### Python Client

```python
import requests
import json

def run_agent(task: str):
    response = requests.post(
        'http://localhost:8000/agent/run',
        json={
            'task': task,
            'max_turns': 10,
            'attached_skills': ['calendar-assistant']
        },
        stream=True
    )

    run_id = response.headers.get('X-Run-ID')
    print(f'Run ID: {run_id}')

    for line in response.iter_lines():
        if not line:
            continue

        line = line.decode('utf-8')

        if line.startswith('event:'):
            event_type = line.split(':', 1)[1].strip()
        elif line.startswith('data:'):
            event_data = json.loads(line.split(':', 1)[1].strip())

            print(f'[{event_type}]', event_data)

            if event_type == 'text':
                print(event_data['data'], end='', flush=True)

# Usage
run_agent('What tasks are due this week?')
```

---

## Testing

### Manual Testing

1. Start the server:
```bash
cd services/brain_runtime
uv run uvicorn main:app --reload
```

2. Send a test request:
```bash
curl -N -X POST http://localhost:8000/agent/run \
  -H "Content-Type: application/json" \
  -d '{
    "task": "List my tasks for today",
    "max_turns": 5
  }'
```

3. Check run status:
```bash
curl http://localhost:8000/agent/runs
```

### Integration Testing

TODO: Add Playwright/pytest tests for:
- Agent run creation and streaming
- Tool call execution
- Artifact creation and download
- Run cancellation
- Error handling

---

## Security Considerations

1. **API Key Protection**: Anthropic API key is loaded from environment variables
2. **Path Validation**: Artifact paths are validated to prevent directory traversal
3. **Rate Limiting**: TODO - Add rate limiting to prevent abuse
4. **Authentication**: TODO - Add authentication for agent endpoints
5. **Input Validation**: All inputs are validated using Pydantic models

---

## Performance Considerations

1. **Streaming**: All responses use SSE streaming to provide real-time feedback
2. **Database Connections**: Uses async SQLAlchemy with connection pooling
3. **File I/O**: Artifact files are stored on disk for efficient retrieval
4. **Token Limits**: Max tokens per request is capped at 4096 (configurable)

---

## Future Enhancements

1. **Multi-provider Support**: Add OpenAI GPT and other providers
2. **Conversation History**: Store full conversation in database
3. **Artifact Types**: Support more artifact types (images, data exports, etc.)
4. **Agent Templates**: Pre-configured agent templates for common tasks
5. **Collaborative Agents**: Multiple agents working together on complex tasks
6. **Human-in-the-Loop**: Approval workflows for sensitive operations
7. **Metrics Dashboard**: Visualize agent performance and costs
