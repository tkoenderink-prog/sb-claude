# Phase 9A: Fix Everything - Comprehensive Remediation Plan

**Status:** READY FOR IMPLEMENTATION
**Created:** 2025-12-22
**Depends on:** Phase 7B (Complete), Phase 8-9 (Partial)
**Complexity:** High
**Estimated Effort:** 3-4 focused days

---

## Executive Summary

This phase exists because **documentation drifted from reality**. Phases 8-9 were marked as "spec ready" but substantial work was done without updating status. Worse, critical integrations were left broken - backend APIs exist but frontend doesn't consume them.

**Phase 9A is a remediation phase** with three goals:
1. **Fix broken integrations** - Wire existing backend to frontend
2. **Complete half-built features** - Finish what was started
3. **Remove dead code** - Delete stubs and TODOs that mislead

### Current State (Honest Assessment)

| Phase | Documentation Says | Backend Reality | Frontend Reality | E2E Working? |
|-------|-------------------|-----------------|------------------|--------------|
| **8** | "Spec Ready" | 90% built | 70% built | **40% working** |
| **9** | "Spec Ready" | 60% built | 40% built | **20% working** |

### What This Plan Does NOT Do

- No new features beyond what Phase 8-9 specified
- No architectural rewrites
- No "nice to haves"

---

## Part A: Critical Broken Integrations (Must Fix)

### A1. ProposalCard SSE Integration - PRIORITY 1

**Problem:** Backend emits `proposal` SSE events. Frontend ignores them completely.
**Impact:** Core Phase 8 write mode is completely non-functional.

**Root Cause Analysis:**
1. `ChatContainer.tsx` has SSE handler but no case for `proposal` event type
2. `ProposalCard.tsx` exists but is never imported/rendered
3. `chat-api.ts` defines `ChatProposalEvent` type but nothing uses it

**Structural Fix:**

**File: `apps/web/src/lib/chat-api.ts`**
```typescript
// Verify ChatProposalEvent is defined (it is)
export interface ChatProposalEvent {
  type: 'proposal'
  data: {
    proposal_id: string
    description: string
    files: Array<{
      path: string
      operation: 'create' | 'modify' | 'delete'
      diff_preview?: string
      lines_added: number
      lines_removed: number
    }>
    status: 'pending' | 'approved' | 'rejected' | 'applied'
    auto_applied: boolean
    requires_approval: boolean
  }
}

// Add to ChatEvent union if missing
export type ChatEvent =
  | ChatTextEvent
  | ChatToolCallEvent
  | ChatToolResultEvent
  // ... existing types
  | ChatProposalEvent  // <-- Must be present
```

**File: `apps/web/src/components/chat/ChatContainer.tsx`**
```typescript
// Add import
import { ProposalCard } from '@/components/proposal/ProposalCard'

// Add state for proposals
const [proposals, setProposals] = useState<Map<string, Proposal>>(new Map())

// Add case in SSE handler switch statement
case 'proposal':
  const proposalData = parsed.data
  setProposals(prev => new Map(prev).set(proposalData.proposal_id, proposalData))
  break

// Add ProposalCard render in message list (after tool results)
{Array.from(proposals.values())
  .filter(p => p.status === 'pending')
  .map(proposal => (
    <ProposalCard
      key={proposal.proposal_id}
      proposal={proposal}
      onApprove={handleApproveProposal}
      onReject={handleRejectProposal}
    />
  ))}
```

**File: `apps/web/src/components/proposal/ProposalCard.tsx`**
- Verify component handles approve/reject API calls
- Verify it shows auto-applied state correctly
- Add loading states for API calls

**Testing Checklist:**
- [ ] Send message asking to modify a vault file
- [ ] Proposal SSE event received and parsed
- [ ] ProposalCard renders inline in chat
- [ ] "View Diff" opens DiffViewer modal
- [ ] "Approve" calls API and updates state
- [ ] "Reject" calls API and updates state
- [ ] Auto-applied proposals show green confirmation

---

### A2. Missing react-diff-viewer-continued Dependency - PRIORITY 1

**Problem:** DiffViewer imports a package that doesn't exist in package.json.
**Impact:** Any attempt to view a diff will crash the app.

**Structural Fix:**

```bash
cd apps/web
pnpm add react-diff-viewer-continued
```

**Verify in `apps/web/src/components/proposal/DiffViewer.tsx`:**
```typescript
import ReactDiffViewer from 'react-diff-viewer-continued'

// Ensure it renders correctly
<ReactDiffViewer
  oldValue={original}
  newValue={proposed}
  splitView={true}
  useDarkTheme={false}
/>
```

**Testing Checklist:**
- [ ] Package installed without errors
- [ ] DiffViewer renders without crashing
- [ ] Side-by-side diff displays correctly
- [ ] Syntax highlighting works for markdown

---

### A3. Title Generation Endpoint - PRIORITY 2

**Problem:** Spec says titles generated via Haiku 4.5. No endpoint exists.
**Impact:** Sessions show truncated message previews instead of titles.

**Root Cause:** Implementation was never started despite being in Phase 8 spec.

**Structural Fix:**

**File: `services/brain_runtime/api/chat.py`**
Add new endpoint:
```python
@router.post("/chat/sessions/{session_id}/title")
async def generate_title(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
):
    """Generate a 3-4 word title for a session using Haiku 4.5."""
    # Get first user message and assistant response
    messages = await db.execute(
        select(ChatMessageDB)
        .where(ChatMessageDB.session_id == session_id)
        .order_by(ChatMessageDB.created_at)
        .limit(2)
    )
    msgs = messages.scalars().all()

    if len(msgs) < 2:
        raise HTTPException(400, "Need at least one exchange to generate title")

    user_msg = next((m for m in msgs if m.role == "user"), None)
    assistant_msg = next((m for m in msgs if m.role == "assistant"), None)

    if not user_msg or not assistant_msg:
        raise HTTPException(400, "Need both user and assistant messages")

    # Call Haiku to generate title
    client = Anthropic()
    response = await client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=20,
        messages=[{
            "role": "user",
            "content": f"""Generate a 3-4 word title summarizing this conversation.
User: {user_msg.content[:500]}
Assistant: {assistant_msg.content[:500]}

Respond with ONLY the title, no quotes or punctuation."""
        }]
    )

    title = response.content[0].text.strip()[:100]

    # Update session
    await db.execute(
        update(ChatSessionDB)
        .where(ChatSessionDB.id == session_id)
        .values(title=title)
    )
    await db.commit()

    return {"title": title}
```

**File: `apps/web/src/hooks/useChat.ts`**
Add title generation trigger:
```typescript
// After first assistant message completes
useEffect(() => {
  if (
    sessionId &&
    messages.length >= 2 &&
    !sessionTitle &&
    !isGeneratingTitle
  ) {
    generateTitle(sessionId)
  }
}, [messages.length, sessionId, sessionTitle])

const generateTitle = async (id: string) => {
  setIsGeneratingTitle(true)
  try {
    const res = await fetch(`/api/chat/sessions/${id}/title`, { method: 'POST' })
    const { title } = await res.json()
    setSessionTitle(title)
  } catch (e) {
    console.error('Title generation failed:', e)
  } finally {
    setIsGeneratingTitle(false)
  }
}
```

**File: `apps/web/src/components/chat/SessionSidebar.tsx`**
Display title instead of preview:
```typescript
// Show title if exists, otherwise truncated first message
<span className="truncate">
  {session.title || truncateMessage(session.preview)}
</span>
```

**Testing Checklist:**
- [ ] Title endpoint returns 3-4 word title
- [ ] Title saved to database
- [ ] Frontend triggers after first exchange
- [ ] Title shows in sidebar
- [ ] Title shows in chat header
- [ ] Graceful handling if generation fails

---

### A4. YOLO Mode End-to-End Flow - PRIORITY 2

**Problem:** YOLO toggle exists and saves to DB, but auto-apply doesn't work.
**Impact:** Users toggle YOLO but proposals still require manual approval.

**Root Cause Analysis:**
1. `UserSettingsDB.yolo_mode` exists and is toggled correctly
2. `ProposalService.apply_proposal()` exists
3. **Missing link:** Proposal tools don't check YOLO mode before requiring approval

**Structural Fix:**

**File: `services/brain_runtime/core/tools/proposal_tools.py`**
```python
from core.proposal_service import ProposalService
from api.settings import get_or_create_settings

async def _handle_proposal_with_yolo(
    proposal_id: str,
    operation: str,
    db: AsyncSession,
) -> dict:
    """Handle proposal creation with YOLO mode logic."""
    settings = await get_or_create_settings(db)
    proposal_service = ProposalService(db)

    # SAFETY: Deletes NEVER auto-apply
    if operation == "delete":
        return {
            "proposal_id": proposal_id,
            "status": "pending",
            "auto_applied": False,
            "requires_approval": True,
            "message": "Delete operations always require approval",
        }

    # YOLO mode: auto-apply creates and modifies
    if settings.yolo_mode:
        await proposal_service.apply_proposal(proposal_id)
        return {
            "proposal_id": proposal_id,
            "status": "applied",
            "auto_applied": True,
            "requires_approval": False,
        }

    # Normal mode: require approval
    return {
        "proposal_id": proposal_id,
        "status": "pending",
        "auto_applied": False,
        "requires_approval": True,
    }

# Update each tool to call this after creating proposal
@tool(name="propose_file_change", ...)
async def propose_file_change(file_path: str, new_content: str, description: str):
    # ... create proposal ...
    return await _handle_proposal_with_yolo(proposal.id, "modify", db)
```

**File: `apps/web/src/components/proposal/ProposalCard.tsx`**
Handle auto-applied state:
```typescript
if (proposal.auto_applied) {
  return (
    <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-2">
      <CheckCircleIcon className="w-5 h-5 text-green-600" />
      <span className="text-green-800">Applied automatically: {proposal.description}</span>
    </div>
  )
}
```

**Testing Checklist:**
- [ ] YOLO OFF: All proposals require approval
- [ ] YOLO ON + create: Auto-applies, shows green banner
- [ ] YOLO ON + modify: Auto-applies, shows green banner
- [ ] YOLO ON + delete: Still requires approval (safety)
- [ ] Toggle persists across page refresh

---

## Part B: Half-Built Features (Complete Them)

### B1. Sync Status - Replace TODO Stub - PRIORITY 3

**Problem:** `sync.py:148` has `TODO: Implement actual RAG sync logic`.
**Impact:** Sync status always shows "idle" even after jobs run.

**Structural Fix:**

**File: `services/brain_runtime/api/sync.py`**
Replace stub with actual integration:
```python
from core.job_manager import JobManager

@router.post("/sync/trigger/{sync_type}")
async def trigger_sync(
    sync_type: Literal["rag", "calendar", "tasks"],
    db: AsyncSession = Depends(get_db),
):
    """Trigger a sync job and track status."""
    # Map sync_type to processor
    processor_map = {
        "rag": "rag_processor",
        "calendar": "calendar_processor",
        "tasks": "tasks_processor",
    }

    processor = processor_map.get(sync_type)
    if not processor:
        raise HTTPException(400, f"Unknown sync type: {sync_type}")

    # Update status to running
    await db.execute(
        update(SyncStatusDB)
        .where(SyncStatusDB.sync_type == sync_type)
        .values(
            status="running",
            last_sync_start=datetime.utcnow(),
            error_message=None,
        )
    )
    await db.commit()

    # Trigger job
    job_manager = JobManager.get_instance()
    job_id = await job_manager.run_processor(processor)

    return {"job_id": job_id, "status": "running"}


@router.get("/sync/status")
async def get_all_sync_status(db: AsyncSession = Depends(get_db)):
    """Get status for all sync types."""
    result = await db.execute(select(SyncStatusDB))
    statuses = result.scalars().all()

    return {
        "statuses": [s.to_dict() for s in statuses]
    }
```

**Add job completion hook to update sync status:**
```python
# In JobManager or processor completion callback
async def on_job_complete(job_id: str, sync_type: str, result: dict):
    async with get_db_session() as db:
        await db.execute(
            update(SyncStatusDB)
            .where(SyncStatusDB.sync_type == sync_type)
            .values(
                status="idle" if result.success else "failed",
                last_sync_end=datetime.utcnow(),
                files_processed=result.files_processed,
                chunks_created=result.chunks_created,
                error_message=result.error if not result.success else None,
            )
        )
        await db.commit()
```

**Testing Checklist:**
- [ ] `/sync/status` returns actual data (not placeholders)
- [ ] `/sync/trigger/rag` starts a job
- [ ] Status updates to "running" when job starts
- [ ] Status updates to "idle" when job completes
- [ ] Status updates to "failed" if job errors
- [ ] Error message captured on failure

---

### B2. Mode Selection in New Chat - PRIORITY 3

**Problem:** Modes CRUD API works, but no UI to select mode when starting chat.
**Impact:** Modes are invisible and unusable.

**Structural Fix:**

**File: `apps/web/src/components/modes/ModeChips.tsx`** (new)
```typescript
interface ModeChipsProps {
  modes: Mode[]
  selectedId: string | null
  onSelect: (mode: Mode) => void
}

export function ModeChips({ modes, selectedId, onSelect }: ModeChipsProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {modes.map(mode => (
        <button
          key={mode.id}
          onClick={() => onSelect(mode)}
          className={cn(
            "px-3 py-1.5 rounded-full text-sm flex items-center gap-1.5 transition-colors",
            selectedId === mode.id
              ? "bg-blue-100 text-blue-800 ring-2 ring-blue-500"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          )}
        >
          <span>{mode.icon}</span>
          <span>{mode.name}</span>
        </button>
      ))}
    </div>
  )
}
```

**File: `apps/web/src/components/chat/ChatContainer.tsx`**
Add mode selection above input for new chats:
```typescript
const { data: modes } = useModes()
const [selectedMode, setSelectedMode] = useState<Mode | null>(null)

// Show mode selector only for new conversations
{!sessionId && messages.length === 0 && (
  <div className="px-4 py-3 border-b">
    <p className="text-sm text-gray-500 mb-2">Select a mode:</p>
    <ModeChips
      modes={modes || []}
      selectedId={selectedMode?.id || null}
      onSelect={setSelectedMode}
    />
  </div>
)}

// Pass mode to chat creation
const handleSendMessage = async (content: string) => {
  await sendMessage(content, {
    mode_id: selectedMode?.id,
    model: selectedMode?.default_model || defaultModel,
  })
}
```

**File: `services/brain_runtime/api/chat.py`**
Use mode's system prompt addition:
```python
async def build_full_system_prompt(
    mode_id: Optional[UUID],
    db: AsyncSession,
) -> str:
    """Build system prompt with mode additions."""
    settings = await get_or_create_settings(db)
    base_prompt = settings.system_prompt or BASE_SYSTEM_PROMPT

    if mode_id:
        mode = await db.get(ModeDB, mode_id)
        if mode and mode.system_prompt_addition:
            base_prompt += f"\n\n{mode.system_prompt_addition}"

    return base_prompt
```

**Testing Checklist:**
- [ ] Mode chips display above input for new chat
- [ ] Clicking mode selects it (visual feedback)
- [ ] Selected mode's prompt addition included in system prompt
- [ ] Mode's default model used if set
- [ ] Mode ID saved to session record

---

### B3. Conversation Search Frontend Integration - PRIORITY 3

**Problem:** Search API works, `ConversationSearch.tsx` exists, but not wired to sidebar.
**Impact:** Search box appears but results don't display.

**Structural Fix:**

**File: `apps/web/src/hooks/useConversationSearch.ts`**
```typescript
export function useConversationSearch(query: string) {
  return useQuery({
    queryKey: ['conversation-search', query],
    queryFn: async () => {
      if (!query || query.length < 2) return []
      const res = await fetch(`/api/search/conversations?query=${encodeURIComponent(query)}`)
      return res.json()
    },
    enabled: query.length >= 2,
    staleTime: 30000,
  })
}
```

**File: `apps/web/src/components/chat/SessionSidebar.tsx`**
Wire search to results:
```typescript
const [searchQuery, setSearchQuery] = useState('')
const [isSearchMode, setIsSearchMode] = useState(false)
const { data: searchResults, isLoading: isSearching } = useConversationSearch(searchQuery)

return (
  <div className="flex flex-col h-full">
    <ConversationSearch
      value={searchQuery}
      onChange={setSearchQuery}
      onFocus={() => setIsSearchMode(true)}
      onClear={() => {
        setSearchQuery('')
        setIsSearchMode(false)
      }}
    />

    {isSearchMode && searchQuery.length >= 2 ? (
      <SearchResults
        results={searchResults || []}
        loading={isSearching}
        onSelectSession={handleSelectSession}
      />
    ) : (
      <GroupedSessionList ... />
    )}
  </div>
)
```

**File: `apps/web/src/components/chat/SearchResults.tsx`** (new or update)
```typescript
interface SearchResultsProps {
  results: ConversationSearchResult[]
  loading: boolean
  onSelectSession: (sessionId: string) => void
}

export function SearchResults({ results, loading, onSelectSession }: SearchResultsProps) {
  if (loading) {
    return <div className="p-4 text-gray-500">Searching...</div>
  }

  if (results.length === 0) {
    return <div className="p-4 text-gray-500">No conversations found</div>
  }

  return (
    <div className="divide-y">
      {results.map(result => (
        <button
          key={result.session_id}
          onClick={() => onSelectSession(result.session_id)}
          className="w-full p-3 text-left hover:bg-gray-50"
        >
          <div className="font-medium">{result.title || 'Untitled'}</div>
          <div
            className="text-sm text-gray-500 mt-1"
            dangerouslySetInnerHTML={{ __html: result.snippet }}
          />
          <div className="text-xs text-gray-400 mt-1">
            {formatDate(result.created_at)}
          </div>
        </button>
      ))}
    </div>
  )
}
```

**Testing Checklist:**
- [ ] Typing in search triggers API call (debounced)
- [ ] Results display with highlighted snippets
- [ ] Clicking result opens that conversation
- [ ] Clearing search returns to session list
- [ ] Empty state shows "No conversations found"

---

### B4. Context Files Integration - PRIORITY 4

**Problem:** `ContextFileSelector.tsx` exists, API endpoints exist, but not wired together.
**Impact:** Can't add vault files to conversation context.

**Structural Fix:**

**File: `apps/web/src/hooks/useContextFiles.ts`**
```typescript
export function useContextFiles(sessionId: string | null) {
  const queryClient = useQueryClient()

  const { data: files, isLoading } = useQuery({
    queryKey: ['context-files', sessionId],
    queryFn: () => sessionId ? fetchContextFiles(sessionId) : [],
    enabled: !!sessionId,
  })

  const addFile = useMutation({
    mutationFn: (filePath: string) =>
      fetch(`/api/vault/context`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionId, file_path: filePath }),
      }),
    onSuccess: () => queryClient.invalidateQueries(['context-files', sessionId]),
  })

  const removeFile = useMutation({
    mutationFn: (fileId: string) =>
      fetch(`/api/vault/context/${fileId}`, { method: 'DELETE' }),
    onSuccess: () => queryClient.invalidateQueries(['context-files', sessionId]),
  })

  return { files, isLoading, addFile, removeFile }
}
```

**File: `apps/web/src/components/chat/ChatContainer.tsx`**
Add context file selector above input:
```typescript
const { files: contextFiles, addFile, removeFile } = useContextFiles(sessionId)
const [showFilePicker, setShowFilePicker] = useState(false)

// Above MessageInput
<div className="border-t">
  {contextFiles && contextFiles.length > 0 && (
    <div className="px-4 py-2 flex flex-wrap gap-2">
      {contextFiles.map(file => (
        <FileChip
          key={file.id}
          path={file.file_path}
          tokens={file.token_count}
          onRemove={() => removeFile.mutate(file.id)}
        />
      ))}
    </div>
  )}

  <button
    onClick={() => setShowFilePicker(true)}
    className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
  >
    + Add context file
  </button>
</div>

{showFilePicker && (
  <ContextFileSelector
    onSelect={(path) => {
      addFile.mutate(path)
      setShowFilePicker(false)
    }}
    onClose={() => setShowFilePicker(false)}
  />
)}
```

**Testing Checklist:**
- [ ] "Add context file" button opens picker
- [ ] Picker shows vault structure
- [ ] Selecting file adds it to context
- [ ] File chip shows path and token count
- [ ] Removing file updates list
- [ ] Context files included in API call

---

## Part C: Remove Dead Code / Fix Misleading State

### C1. Delete or Fix TODOs

**Audit all TODOs and either implement or remove:**

```bash
# Find all TODOs
grep -rn "TODO\|FIXME\|HACK\|XXX" services/brain_runtime/ --include="*.py"
grep -rn "TODO\|FIXME" apps/web/src/ --include="*.tsx" --include="*.ts"
```

**For each TODO:**
1. If it's a real missing feature → Add to this plan or future phase
2. If it's a reminder that's now done → Delete it
3. If it's aspirational → Delete it (add to roadmap doc instead)

### C2. Seed Default Data

**Problem:** Tables exist but may not have default data.

**File: Create `services/brain_runtime/migrations/005_seed_defaults.sql`**
```sql
-- Ensure default modes exist
INSERT INTO modes (name, description, icon, is_system, is_default)
VALUES
    ('General', 'General-purpose assistant', '💬', TRUE, TRUE),
    ('Research', 'Deep research and analysis', '🔍', TRUE, FALSE),
    ('Writing', 'Writing assistance and editing', '✍️', TRUE, FALSE)
ON CONFLICT DO NOTHING;

-- Ensure default commands exist
INSERT INTO standard_commands (mode_id, name, description, prompt)
VALUES
    (NULL, 'Summarize', 'Create a brief summary', 'Please summarize the above in 2-3 bullet points.'),
    (NULL, 'Explain', 'Explain in simpler terms', 'Please explain this in simpler terms.'),
    (NULL, 'Action Items', 'Extract action items', 'Please extract all action items as a checklist.')
ON CONFLICT DO NOTHING;

-- Ensure sync_status rows exist
INSERT INTO sync_status (sync_type, status)
VALUES
    ('rag', 'idle'),
    ('calendar', 'idle'),
    ('tasks', 'idle')
ON CONFLICT DO NOTHING;

-- Ensure user_settings row exists
INSERT INTO user_settings (yolo_mode, default_model)
VALUES (FALSE, 'claude-sonnet-4-5-20250929')
ON CONFLICT DO NOTHING;
```

---

## Part D: Deferred to Future Phases

These items were in Phase 8-9 specs but are explicitly deferred:

### Deferred from Phase 8
- **Creating-Skills Skill** - Move to Phase 10 (nice-to-have)

### Deferred from Phase 9
- **System Prompt Editor with Monaco** - Move to Phase 10 (works without Monaco)
- **File Upload/Conversion** - Move to Phase 10 (PDF, DOCX)
- **PWA/Mobile** - Move to Phase 10 (service worker, swipe gestures)
- **Drag & Drop** - Move to Phase 10 (vision, file attachments)
- **API Key Encryption** - Move to Phase 10 (currently uses .env)

---

## Implementation Order

### Day 1: Critical Integrations (4-6 hours)
1. **A2**: Install react-diff-viewer-continued
2. **A1**: Wire ProposalCard to ChatContainer SSE
3. Test proposal workflow end-to-end

### Day 2: YOLO + Title (4-6 hours)
4. **A4**: Complete YOLO auto-apply flow
5. **A3**: Implement title generation endpoint
6. Wire title to frontend

### Day 3: Search + Modes (4-6 hours)
7. **B3**: Wire conversation search frontend
8. **B2**: Add mode selection to new chat
9. **C2**: Run seed migrations

### Day 4: Sync + Context + Cleanup (4-6 hours)
10. **B1**: Implement real sync status tracking
11. **B4**: Wire context file selector
12. **C1**: Audit and fix/remove all TODOs

---

## New/Modified Files Summary

### Must Create
- `apps/web/src/components/modes/ModeChips.tsx`
- `apps/web/src/components/chat/SearchResults.tsx` (if missing)
- `services/brain_runtime/migrations/005_seed_defaults.sql`

### Must Modify
- `apps/web/src/lib/chat-api.ts` - Verify ChatProposalEvent
- `apps/web/src/components/chat/ChatContainer.tsx` - Proposal SSE, modes, context
- `apps/web/src/components/chat/SessionSidebar.tsx` - Search integration
- `apps/web/src/components/proposal/ProposalCard.tsx` - Auto-applied state
- `services/brain_runtime/api/chat.py` - Title endpoint, mode prompt
- `services/brain_runtime/api/sync.py` - Replace TODO stub
- `services/brain_runtime/core/tools/proposal_tools.py` - YOLO flow
- `apps/web/package.json` - Add react-diff-viewer-continued

### Must Verify Exist (already built)
- `apps/web/src/components/chat/ContextFileSelector.tsx`
- `apps/web/src/components/chat/ConversationSearch.tsx`
- `apps/web/src/components/proposal/DiffViewer.tsx`
- `apps/web/src/hooks/useContextFiles.ts`
- `apps/web/src/hooks/useConversationSearch.ts`
- `apps/web/src/hooks/useModes.ts`

---

## Testing Checklist (Complete Phase)

### Proposal Workflow
- [ ] Ask Claude to modify a vault file
- [ ] Proposal appears inline in chat (not in console)
- [ ] "View Diff" shows side-by-side comparison
- [ ] "Approve" applies changes
- [ ] File is actually modified on disk
- [ ] "Reject" marks proposal rejected
- [ ] YOLO mode auto-applies (except deletes)

### Title Generation
- [ ] New conversation gets title after first exchange
- [ ] Title shows in sidebar
- [ ] Title shows in chat header
- [ ] Old sessions without titles still work

### Search
- [ ] Typing in search shows results
- [ ] Results have highlighted matches
- [ ] Clicking result opens conversation

### Modes
- [ ] Mode chips show for new conversations
- [ ] Selecting mode changes system prompt
- [ ] Mode's default model is used

### Context Files
- [ ] Can add vault files to context
- [ ] Files show as chips with token count
- [ ] Can remove files
- [ ] Files included in conversation

### Sync Status
- [ ] Shows last sync time (not placeholder)
- [ ] "Resync" button triggers job
- [ ] Status updates during sync

---

## Success Criteria

Phase 9A is complete when:

1. **Proposals work end-to-end** - Create, view diff, approve/reject, YOLO mode
2. **Titles generate** - Auto-generated after first exchange
3. **Search works** - Frontend displays results, clicking opens session
4. **Modes work** - Can select mode for new chat
5. **Context files work** - Can add/remove vault files
6. **Sync status accurate** - Reflects actual job state
7. **No broken TODOs** - All stubs either implemented or removed
8. **Documentation accurate** - CLAUDE.md reflects reality

---

## Post-Phase 9A State

After completing this phase, the honest status will be:

| Phase | Status | Notes |
|-------|--------|-------|
| 1-7B | 100% Complete | All original features working |
| 8 | 95% Complete | Write mode working, deferred creating-skills |
| 9 | 60% Complete | Core features done, mobile/upload deferred |

Ready to proceed with Phase 10 (mobile, file upload, polish).
