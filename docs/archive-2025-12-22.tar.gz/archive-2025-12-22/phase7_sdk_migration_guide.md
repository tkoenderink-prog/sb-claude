# Phase 7 Migration Guide: Using Claude Agent SDK

**Date:** 2025-12-21
**Summary:** Migration from custom agent implementation to official Claude Agent SDK

---

## TL;DR - Key Changes

### ✅ Use Official SDK For:
- Agent loop mechanics
- Tool execution (via in-process MCP servers)
- Subagent spawning and orchestration
- Context management and compaction
- Safety hooks

### ⚠️ Build Custom For:
- Session persistence (database)
- Multi-provider support (OpenAI)
- Artifact storage and retrieval
- Agent run tracking and metrics

---

## Installation

```bash
cd services/brain_runtime
uv add claude-agent-sdk anthropic
```

---

## Implementation Pattern

### 1. Create SDK MCP Tools

**File:** `services/brain_runtime/core/agent_tools.py`

```python
from claude_agent_sdk import tool, create_sdk_mcp_server
import httpx

# Wrap each Phase 1-6 API endpoint as a tool
@tool("get_today_events", "Get today's calendar events", {})
async def get_today_events(args):
    async with httpx.AsyncClient() as client:
        response = await client.get("http://localhost:8000/calendar/today")
        data = response.json()
    return {"content": [{"type": "text", "text": str(data)}]}

@tool("query_tasks", "Query tasks with filters", {"filter": str})
async def query_tasks(args):
    filter_value = args.get("filter", "all")
    async with httpx.AsyncClient() as client:
        response = await client.get(
            "http://localhost:8000/tasks/query",
            params={"filter": filter_value}
        )
        data = response.json()
    return {"content": [{"type": "text", "text": str(data)}]}

@tool("semantic_search", "Search vault using semantic similarity", {"query": str, "limit": int})
async def semantic_search(args):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://localhost:8000/search/semantic",
            json={"query": args["query"], "limit": args.get("limit", 10)}
        )
        data = response.json()
    return {"content": [{"type": "text", "text": str(data)}]}

@tool("read_vault_file", "Read a file from vault", {"path": str})
async def read_vault_file(args):
    async with httpx.AsyncClient() as client:
        response = await client.get(
            "http://localhost:8000/vault/read",
            params={"path": args["path"]}
        )
        data = response.json()
    return {"content": [{"type": "text", "text": data["content"]}]}

# Add tools for:
# - get_week_events
# - search_events
# - get_overdue_tasks
# - get_today_tasks
# - get_tasks_by_project
# - text_search
# - list_vault_directory
# - list_skills
# - get_skill
# - search_skills
# - list_processors
# - run_processor

# Create SDK MCP server
brain_tools_server = create_sdk_mcp_server(
    name="brain-tools",
    version="1.0.0",
    tools=[
        get_today_events,
        query_tasks,
        semantic_search,
        read_vault_file,
        # ... all other tools
    ]
)
```

**Benefits:**
- No subprocess management (in-process)
- Better performance than external MCP servers
- Type-safe with Python type hints
- Simpler debugging (all in one process)

---

### 2. Implement Chat Modes

**File:** `services/brain_runtime/api/chat.py`

```python
from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions, query
from anthropic import Anthropic
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
import json

router = APIRouter()

async def handle_quick_chat(prompt: str, provider: str, model: str):
    """Mode 1: Quick chat - direct LLM, no tools"""
    if provider == "anthropic":
        client = Anthropic()
        with client.messages.stream(
            model=model,
            max_tokens=4096,
            messages=[{"role": "user", "content": prompt}]
        ) as stream:
            for text in stream.text_stream:
                yield {"type": "assistant", "data": text}

    elif provider == "openai":
        # Keep existing OpenAI implementation
        from openai import OpenAI
        client = OpenAI()
        stream = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            stream=True
        )
        for chunk in stream:
            if chunk.choices[0].delta.content:
                yield {"type": "assistant", "data": chunk.choices[0].delta.content}

async def handle_tool_enabled_chat(prompt: str, model: str, session_id: str):
    """Mode 2: Tool-enabled chat - Claude Agent SDK with tools"""
    from core.agent_tools import brain_tools_server

    options = ClaudeAgentOptions(
        model=model,
        mcp_servers={"brain": brain_tools_server},
        allowed_tools=["mcp__brain__*"],  # Allow all brain tools
        permission_mode="acceptEdits",    # Auto-approve tool use
        max_turns=10,                     # Limit iteration
        system_prompt=get_session_system_prompt(session_id)  # Include skills
    )

    async with ClaudeSDKClient(options=options) as client:
        await client.query(prompt)

        async for msg in client.receive_response():
            # Convert SDK message to SSE format
            if hasattr(msg, 'content'):
                for block in msg.content:
                    if hasattr(block, 'text'):
                        yield {"type": "assistant", "data": block.text}
                    elif hasattr(block, 'tool_use'):
                        yield {
                            "type": "tool_call",
                            "data": {
                                "id": block.tool_use.id,
                                "name": block.tool_use.name,
                                "input": block.tool_use.input
                            }
                        }
            elif hasattr(msg, 'tool_result'):
                yield {
                    "type": "tool_result",
                    "data": {
                        "tool_call_id": msg.tool_result.tool_use_id,
                        "output": msg.tool_result.content
                    }
                }

            # Save message to database
            save_message_to_db(session_id, msg)

async def handle_agent_mode(task: str, model: str, run_id: str):
    """Mode 3: Agent mode - orchestrator + subagents"""
    from core.agent_tools import brain_tools_server

    # Orchestrator system prompt
    orchestrator_prompt = """You are an orchestrator agent for a personal second brain system.

    Your role:
    - Break down complex analytical tasks into subtasks
    - Spawn subagents to explore different aspects in parallel
    - Synthesize findings from subagents into coherent insights
    - Produce downloadable artifacts (markdown reports, visualizations)

    Available tools:
    - Calendar tools: get_today_events, get_week_events, search_events
    - Task tools: query_tasks, get_overdue_tasks, get_tasks_by_project
    - Vault tools: semantic_search, text_search, read_vault_file
    - Skills tools: list_skills, get_skill
    - Processor tools: run_processor

    When given a complex task:
    1. Analyze the task and identify key aspects to explore
    2. For each aspect, clearly describe what needs to be investigated
    3. Spawn subagents with specific, detailed instructions
    4. Synthesize results into a final artifact

    Always produce a markdown artifact as your final output.
    """

    options = ClaudeAgentOptions(
        model=model,
        system_prompt=orchestrator_prompt,
        mcp_servers={"brain": brain_tools_server},
        allowed_tools=["mcp__brain__*"],
        permission_mode="acceptEdits",
        max_turns=20  # More iterations for complex tasks
    )

    async with ClaudeSDKClient(options=options) as orchestrator:
        # Start task
        yield {"type": "status", "data": "started"}

        await orchestrator.query(task)

        # SDK automatically spawns subagents as needed
        # We just receive messages as they come
        async for msg in orchestrator.receive_response():
            # Stream updates
            if hasattr(msg, 'content'):
                for block in msg.content:
                    if hasattr(block, 'text'):
                        yield {"type": "assistant", "data": block.text}
                    elif hasattr(block, 'tool_use'):
                        yield {"type": "tool_call", "data": {...}}

            # Track in agent_runs table
            update_agent_run(run_id, msg)

            # Detect artifacts (look for markdown code blocks in final response)
            if is_final_message(msg) and contains_artifact(msg):
                artifact_id = save_artifact_to_db(run_id, extract_artifact(msg))
                yield {"type": "artifact", "data": {"artifact_id": artifact_id}}

        yield {"type": "status", "data": "completed"}

@router.post("/chat")
async def chat(request: ChatRequest):
    """SSE endpoint for all chat modes"""

    # Create session if needed
    if not request.session_id:
        session_id = create_session(request.provider, request.model, request.mode)
    else:
        session_id = request.session_id

    async def event_generator():
        try:
            if request.mode == "quick":
                async for event in handle_quick_chat(
                    request.prompt, request.provider, request.model
                ):
                    yield f"data: {json.dumps(event)}\n\n"

            elif request.mode == "tools":
                async for event in handle_tool_enabled_chat(
                    request.prompt, request.model, session_id
                ):
                    yield f"data: {json.dumps(event)}\n\n"

            elif request.mode == "agent":
                run_id = create_agent_run(session_id, request.prompt)
                async for event in handle_agent_mode(
                    request.prompt, request.model, run_id
                ):
                    yield f"data: {json.dumps(event)}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'data': str(e)})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no"
        }
    )
```

---

### 3. Add Safety Hooks

**File:** `services/brain_runtime/core/safety_hooks.py`

```python
from claude_agent_sdk import HookMatcher
import os
import logging

logger = logging.getLogger(__name__)

async def validate_file_access(input_data, tool_use_id, context):
    """Ensure file operations stay within vault bounds"""
    tool_name = input_data["tool_name"]
    tool_input = input_data["tool_input"]

    if tool_name in ["Read", "Write"]:
        file_path = tool_input.get("file_path", "")
        vault_root = os.getenv("OBSIDIAN_VAULT_PATH")

        # Resolve and validate path
        abs_path = os.path.abspath(file_path)
        abs_vault = os.path.abspath(vault_root)

        if not abs_path.startswith(abs_vault):
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": f"Path {file_path} is outside vault root",
                }
            }

    return {}

async def log_bash_commands(input_data, tool_use_id, context):
    """Log all bash commands for audit trail"""
    tool_name = input_data["tool_name"]
    tool_input = input_data["tool_input"]

    if tool_name == "Bash":
        command = tool_input.get("command", "")
        logger.info(f"Agent executing bash command: {command}")

    return {}

async def block_dangerous_commands(input_data, tool_use_id, context):
    """Block potentially dangerous bash commands"""
    tool_name = input_data["tool_name"]
    tool_input = input_data["tool_input"]

    if tool_name == "Bash":
        command = tool_input.get("command", "")

        # Block patterns
        dangerous_patterns = [
            "rm -rf /",
            "sudo",
            "chmod -R",
            "> /dev/",
            "dd if="
        ]

        for pattern in dangerous_patterns:
            if pattern in command:
                return {
                    "hookSpecificOutput": {
                        "hookEventName": "PreToolUse",
                        "permissionDecision": "deny",
                        "permissionDecisionReason": f"Blocked dangerous pattern: {pattern}",
                    }
                }

    return {}

# Export hooks configuration
SAFETY_HOOKS = {
    "PreToolUse": [
        HookMatcher(matcher="Read", hooks=[validate_file_access]),
        HookMatcher(matcher="Write", hooks=[validate_file_access]),
        HookMatcher(matcher="Bash", hooks=[log_bash_commands, block_dangerous_commands]),
    ],
}
```

**Usage in options:**
```python
from core.safety_hooks import SAFETY_HOOKS

options = ClaudeAgentOptions(
    # ... other options
    hooks=SAFETY_HOOKS
)
```

---

### 4. Session Management (Keep Custom)

SDK doesn't handle persistence. Keep existing database layer:

**Tables:**
- `chat_sessions` - Session metadata
- `chat_messages` - Message history
- `agent_runs` - Agent execution tracking
- `agent_artifacts` - Agent-produced outputs

**Helper Functions:**
```python
def create_session(provider: str, model: str, mode: str) -> str:
    """Create new chat session"""
    # Insert into chat_sessions table
    # Return session_id

def save_message_to_db(session_id: str, message):
    """Save message to chat_messages"""
    # Parse SDK message format
    # Insert into chat_messages table

def get_session_history(session_id: str) -> List[dict]:
    """Retrieve session history"""
    # Query chat_messages table
    # Return messages in chronological order

def create_agent_run(session_id: str, task: str) -> str:
    """Create new agent run"""
    # Insert into agent_runs table
    # Return run_id

def update_agent_run(run_id: str, message):
    """Update agent run with progress"""
    # Update agent_runs table with metrics

def save_artifact_to_db(run_id: str, content: str) -> str:
    """Save agent artifact"""
    # Insert into agent_artifacts table
    # Return artifact_id
```

---

## File Structure

```
services/brain_runtime/
├── api/
│   ├── chat.py              # POST /chat endpoint (use SDK here)
│   ├── agent.py             # GET /agent/runs, /artifacts (custom DB)
│   └── sessions.py          # GET/DELETE /chat/sessions (custom DB)
├── core/
│   ├── agent_tools.py       # SDK MCP tools wrapping Phase 1-6 APIs
│   ├── safety_hooks.py      # SDK hooks for validation/logging
│   └── session_manager.py   # Custom session persistence
├── models/
│   ├── chat.py              # Pydantic models for requests/responses
│   └── agent.py             # Agent run and artifact models
└── main.py
```

---

## What Gets Removed

### ❌ Delete (SDK Replaces):
- Custom agent loop implementation
- Custom tool execution framework
- Custom context management logic
- Custom subagent spawning code

### ✅ Keep (SDK Doesn't Provide):
- Database models and schema
- Session CRUD operations
- Provider abstraction (for OpenAI support)
- Artifact storage and retrieval
- Frontend components (just update to consume SDK responses)

---

## Testing Strategy

### Unit Tests
```python
# Test tool wrapping
async def test_get_today_events_tool():
    result = await get_today_events({})
    assert "content" in result
    assert len(result["content"]) > 0

# Test safety hooks
async def test_block_dangerous_command():
    input_data = {
        "tool_name": "Bash",
        "tool_input": {"command": "rm -rf /"}
    }
    result = await block_dangerous_commands(input_data, "test_id", {})
    assert result["hookSpecificOutput"]["permissionDecision"] == "deny"
```

### Integration Tests
```python
# Test tool-enabled chat mode
async def test_tool_enabled_chat():
    events = []
    async for event in handle_tool_enabled_chat(
        "What's on my calendar today?",
        "claude-sonnet-4",
        "test_session"
    ):
        events.append(event)

    # Should see tool calls and results
    assert any(e["type"] == "tool_call" for e in events)
    assert any(e["type"] == "tool_result" for e in events)
```

### E2E Tests (Playwright)
```typescript
test('agent mode produces artifact', async ({ page }) => {
  await page.goto('http://localhost:3000/chat');

  // Select agent mode
  await page.click('[data-testid="mode-agent"]');

  // Submit complex task
  await page.fill('[data-testid="chat-input"]',
    'Analyze my calendar and tasks for next week, identify conflicts');
  await page.click('[data-testid="send-button"]');

  // Wait for completion
  await page.waitForSelector('[data-testid="artifact-card"]');

  // Verify artifact downloadable
  const downloadButton = page.locator('[data-testid="download-artifact"]');
  await expect(downloadButton).toBeVisible();
});
```

---

## Cost Optimization

### Model Selection
- **Orchestrator:** Claude Sonnet 4 or Sonnet 4.5
- **Subagents:** Claude Haiku 4.5 (90% performance, 3× cheaper)

### Configuration
```python
# For orchestrator
orchestrator_options = ClaudeAgentOptions(
    model="claude-sonnet-4",
    # ... options
)

# For subagents (if manually spawning)
subagent_options = ClaudeAgentOptions(
    model="claude-haiku-4-5",
    max_turns=5,  # Limit iterations
    # ... options
)
```

### Token Budget
- Set `max_turns` to prevent runaway loops
- Use extended thinking sparingly (costs add up)
- Monitor token usage via SDK response metadata

---

## Migration Checklist

- [ ] Install `claude-agent-sdk` package
- [ ] Create `core/agent_tools.py` with all Phase 1-6 tools wrapped
- [ ] Implement `handle_quick_chat()` (keep existing OpenAI support)
- [ ] Implement `handle_tool_enabled_chat()` using SDK
- [ ] Implement `handle_agent_mode()` using SDK with orchestrator prompt
- [ ] Create `core/safety_hooks.py` for validation
- [ ] Update `api/chat.py` to use new handlers
- [ ] Keep `core/session_manager.py` for database persistence
- [ ] Update frontend to parse SDK message format in SSE stream
- [ ] Write unit tests for tools and hooks
- [ ] Write integration tests for each chat mode
- [ ] Write E2E tests for agent artifact production
- [ ] Update documentation with SDK usage examples
- [ ] Remove old custom agent loop code
- [ ] Monitor costs in production (token usage tracking)

---

## Expected Benefits

### Development Velocity
- **Less code to maintain:** SDK handles agent mechanics
- **Faster iteration:** No need to debug custom agent loops
- **Better reliability:** Production-tested SDK vs custom implementation

### Performance
- **Parallel subagents:** Automatic by SDK (no manual orchestration)
- **Context management:** Automatic compaction prevents bloat
- **Faster tool execution:** In-process MCP servers (no IPC)

### Safety
- **Built-in hooks:** Deterministic validation before tool execution
- **Permission modes:** Fine-grained control (acceptEdits, askUser, etc.)
- **Audit trail:** Easy to log all tool calls via hooks

### Cost Optimization
- **Model selection:** Easy to configure different models for orchestrator vs subagents
- **Token limits:** Built-in `max_turns` prevents runaway costs
- **Visibility:** SDK provides token usage in responses

---

## Common Pitfalls to Avoid

### ❌ Don't Do This:
1. **Mix custom loop with SDK** - Pick one, don't combine
2. **Skip safety hooks** - Always validate file paths and bash commands
3. **Use Opus 4.5 everywhere** - Too expensive; use Haiku 4.5 for subagents
4. **Forget to persist sessions** - SDK is stateless; save to database
5. **Ignore token costs** - Multi-agent can be 15× more expensive

### ✅ Do This:
1. **Use SDK for all Claude interactions** - Consistent, reliable
2. **Implement hooks early** - Prevent security issues
3. **Monitor costs** - Track token usage per session
4. **Test incrementally** - Start with tool-enabled, then add agent mode
5. **Keep provider abstraction** - Support OpenAI for quick chat

---

## Next Steps

1. **Read full research doc:** `docs/claude_agent_sdk_research_2025.md`
2. **Install SDK:** `uv add claude-agent-sdk`
3. **Create tools:** Wrap Phase 1-6 APIs as MCP tools
4. **Implement modes:** Quick, tool-enabled, agent
5. **Add safety:** Hooks for validation
6. **Test thoroughly:** Unit, integration, E2E
7. **Deploy:** Monitor costs and performance

---

## Resources

- **Python SDK Docs:** https://docs.anthropic.com/en/docs/claude-code/sdk/sdk-python
- **Python SDK GitHub:** https://github.com/anthropics/claude-agent-sdk-python
- **TypeScript SDK GitHub:** https://github.com/anthropics/claude-agent-sdk-typescript
- **Best Practices:** https://www.anthropic.com/engineering/claude-code-best-practices
- **Multi-Agent Patterns:** https://www.anthropic.com/engineering/multi-agent-research-system
