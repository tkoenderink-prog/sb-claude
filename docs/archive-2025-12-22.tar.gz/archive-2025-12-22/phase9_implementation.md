# Phase 9 Implementation Plan: Conversation Intelligence & Mobile Experience

**Status:** SPEC DRAFT
**Created:** 2025-12-21
**Depends on:** Phase 8 (Write Mode)
**Complexity:** Very High

---

## Executive Summary

Phase 9 transforms the Second Brain app into a fully-featured, mobile-ready AI assistant with conversation search, customizable modes, and seamless file integration. This phase focuses on three pillars:

1. **Conversation Intelligence**: Token counting, conversation search, RAG status visibility
2. **Customization Layer**: Modes with custom system prompts, standard commands, API key management
3. **Mobile & UX**: Responsive design, drag-and-drop, file context selection, file upload/conversion

| Feature | Current State | Phase 9 Target |
|---------|---------------|----------------|
| Token Visibility | None | Real-time counter + cost estimation |
| Conversation Search | None | Full-text + date filtering |
| System Prompt | Hardcoded | User-editable global prompt |
| Modes | Tools/Agent only | Custom modes with prompts + models |
| Mobile | Desktop-focused | Touch-optimized responsive PWA |
| Context Files | None | Select vault files to include |
| File Upload | None | Upload → convert → vault placement |
| RAG Status | Hidden | Dashboard with sync controls |

---

## Part A: Conversation Intelligence

### A1. Token Counter

**Purpose:** Provide real-time visibility into token usage and costs during conversations.

#### A1.1 Display Requirements

**Location:** Bottom-right of chat input area (non-intrusive)

**Display modes:**
1. **Collapsed (default):** Single line showing session total: `2.4K tokens · $0.08`
2. **Expanded (click to toggle):** Detailed breakdown panel

**Expanded panel content:**
```
┌─────────────────────────────────────┐
│ Session Usage                       │
├─────────────────────────────────────┤
│ Input:    1,847 tokens   ($0.0055)  │
│ Output:     592 tokens   ($0.0296)  │
│ Total:    2,439 tokens   ($0.0351)  │
├─────────────────────────────────────┤
│ Current message: ~127 tokens        │
│ Context window:  4.2K / 200K (2%)   │
└─────────────────────────────────────┘
```

**Real-time updates:**
- Update "current message" count as user types (debounced 300ms)
- Use tiktoken/cl100k_base approximation (client-side)
- Update session totals after each message exchange

#### A1.2 Data Model

**Backend tracking (already exists in SSE):**
```python
# Extend existing usage event
class UsageEventData(BaseModel):
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    model: str
    cost_usd: float  # NEW: calculated cost
```

**Cost calculation (with cache pricing):**
```python
# Pricing per million tokens
MODEL_PRICING = {
    "claude-opus-4-5-20251101": {
        "input": 5.0,
        "output": 25.0,
        "cache_write": 6.25,   # 1.25x input price
        "cache_read": 0.5,     # 10% of input price
    },
    "claude-sonnet-4-5-20250929": {
        "input": 3.0,
        "output": 15.0,
        "cache_write": 3.75,
        "cache_read": 0.3,
    },
    "claude-haiku-4-5-20251001": {
        "input": 1.0,
        "output": 5.0,
        "cache_write": 1.25,
        "cache_read": 0.1,
    },
    "claude-3-5-haiku-20241022": {
        "input": 0.8,
        "output": 4.0,
        "cache_write": 1.0,
        "cache_read": 0.08,
    },
}

# Context window sizes per model
MODEL_CONTEXT_WINDOWS = {
    "claude-opus-4-5-20251101": 200_000,
    "claude-sonnet-4-5-20250929": 200_000,
    "claude-haiku-4-5-20251001": 200_000,
    "claude-3-5-haiku-20241022": 200_000,
}

def calculate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_creation_tokens: int = 0,
    cache_read_tokens: int = 0,
) -> float:
    """Calculate cost in USD for a message exchange."""
    pricing = MODEL_PRICING.get(model, MODEL_PRICING["claude-sonnet-4-5-20250929"])

    # Input tokens = regular input + cache writes (at higher rate)
    # Cache reads are charged at reduced rate
    input_cost = (input_tokens - cache_creation_tokens) * pricing["input"]
    cache_write_cost = cache_creation_tokens * pricing["cache_write"]
    cache_read_cost = cache_read_tokens * pricing["cache_read"]
    output_cost = output_tokens * pricing["output"]

    total = (input_cost + cache_write_cost + cache_read_cost + output_cost) / 1_000_000
    return round(total, 6)
```

**Update session totals after each message:**
```python
# In chat.py, after receiving usage event from SSE:
async def update_session_usage(
    session_id: str,
    usage: UsageEventData,
    db: AsyncSession
):
    """Increment session token counters and cost."""
    await db.execute(
        update(ChatSessionDB)
        .where(ChatSessionDB.id == session_id)
        .values(
            total_input_tokens=ChatSessionDB.total_input_tokens + usage.input_tokens,
            total_output_tokens=ChatSessionDB.total_output_tokens + usage.output_tokens,
            total_cost_usd=ChatSessionDB.total_cost_usd + usage.cost_usd,
        )
    )
    await db.commit()
```

**Session aggregation:**
```sql
-- Add to chat_sessions table
ALTER TABLE chat_sessions ADD COLUMN total_input_tokens INTEGER DEFAULT 0;
ALTER TABLE chat_sessions ADD COLUMN total_output_tokens INTEGER DEFAULT 0;
ALTER TABLE chat_sessions ADD COLUMN total_cost_usd DECIMAL(10,6) DEFAULT 0;
```

#### A1.3 Frontend Components

**New files:**
- `/apps/web/src/components/chat/TokenCounter.tsx`
- `/apps/web/src/hooks/useTokenCount.ts`

**TokenCounter component:**
```tsx
interface TokenCounterProps {
  sessionTokens: { input: number; output: number; cost: number }
  currentDraft: string
  model: string
  contextWindowSize: number
}

function TokenCounter({ sessionTokens, currentDraft, model, contextWindowSize }: TokenCounterProps) {
  const [expanded, setExpanded] = useState(false)
  const draftTokens = useEstimateTokens(currentDraft) // debounced

  const totalTokens = sessionTokens.input + sessionTokens.output
  const contextUsed = totalTokens + draftTokens
  const contextPercent = (contextUsed / contextWindowSize) * 100

  return (
    <div className="absolute bottom-2 right-2 text-xs text-gray-500">
      <button onClick={() => setExpanded(!expanded)}>
        {formatTokens(totalTokens)} · ${sessionTokens.cost.toFixed(2)}
      </button>
      {expanded && <TokenDetailPanel ... />}
    </div>
  )
}
```

**Client-side token estimation:**
```typescript
// Use js-tiktoken for browser-compatible estimation
import { getEncoding } from 'js-tiktoken'

const encoder = getEncoding('cl100k_base')

export function estimateTokens(text: string): number {
  return encoder.encode(text).length
}
```

#### A1.4 Integration Points

**Files to modify:**
- `/apps/web/src/components/chat/MessageInput.tsx` - Add TokenCounter
- `/apps/web/src/hooks/useChat.ts` - Track session totals from SSE
- `/services/brain_runtime/api/chat.py` - Add cost to usage event

---

### A2. Conversation Search

**Purpose:** Enable finding past conversations by keyword, date, or semantic similarity.

#### A2.1 Search Interface

**Location:** Top of SessionSidebar, above session list

**UI components:**
```
┌─────────────────────────────────────┐
│ 🔍 Search conversations...          │
├─────────────────────────────────────┤
│ Filters: [Date ▼] [Has files ▼]     │
└─────────────────────────────────────┘
```

**Search modes:**
1. **Keyword search:** Full-text search across message content
2. **Date range:** Filter by created_at (today, this week, this month, custom)
3. **Semantic search:** (Future) Vector similarity using existing embeddings

#### A2.2 Database Implementation

**PostgreSQL full-text search:**
```sql
-- Add tsvector column for fast searching
ALTER TABLE chat_messages ADD COLUMN search_vector tsvector;

-- Create trigger to auto-update on insert/update
CREATE OR REPLACE FUNCTION update_message_search_vector()
RETURNS trigger AS $$
BEGIN
  NEW.search_vector := to_tsvector('english', COALESCE(NEW.content, ''));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER message_search_vector_update
  BEFORE INSERT OR UPDATE ON chat_messages
  FOR EACH ROW EXECUTE FUNCTION update_message_search_vector();

-- Backfill existing messages
UPDATE chat_messages SET search_vector = to_tsvector('english', COALESCE(content, ''));

-- Create GIN index for fast searching
CREATE INDEX idx_messages_search ON chat_messages USING GIN(search_vector);
```

**Search query:**
```python
async def search_conversations(
    query: str,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    limit: int = 20,
    db: AsyncSession = None,
) -> List[ConversationSearchResult]:
    """Search conversations using full-text search.

    NOTE: plainto_tsquery() sanitizes input, preventing SQL injection.
    Uses subquery pattern to correctly apply DISTINCT ON before LIMIT.
    """

    # Subquery to get best match per session, then sort and limit
    sql = """
    SELECT * FROM (
        SELECT DISTINCT ON (s.id)
            s.id,
            s.title,
            s.created_at,
            ts_headline('english', m.content, plainto_tsquery('english', :query),
                'MaxWords=30, MinWords=15, StartSel=<mark>, StopSel=</mark>') as snippet,
            ts_rank(m.search_vector, plainto_tsquery('english', :query)) as rank,
            (SELECT COUNT(*) FROM chat_messages WHERE session_id = s.id) as message_count
        FROM chat_sessions s
        JOIN chat_messages m ON m.session_id = s.id
        WHERE m.search_vector @@ plainto_tsquery('english', :query)
          AND s.deleted_at IS NULL
          AND (:start_date IS NULL OR s.created_at >= :start_date)
          AND (:end_date IS NULL OR s.created_at <= :end_date)
        ORDER BY s.id, rank DESC, m.created_at DESC
    ) AS unique_sessions
    ORDER BY rank DESC, created_at DESC
    LIMIT :limit
    """

    result = await db.execute(text(sql), {
        "query": query,
        "start_date": start_date,
        "end_date": end_date,
        "limit": limit,
    })

    return [
        ConversationSearchResult(
            session_id=str(row.id),
            title=row.title,
            created_at=row.created_at,
            snippet=row.snippet,
            message_count=row.message_count,
        )
        for row in result.fetchall()
    ]
```

#### A2.3 API Endpoints

**New file:** `/services/brain_runtime/api/search.py`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/search/conversations` | GET | Search conversations with filters |
| `/search/messages` | GET | Search individual messages |

**Request/Response:**
```python
class ConversationSearchRequest(BaseModel):
    query: str
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    limit: int = 20

class ConversationSearchResult(BaseModel):
    session_id: str
    title: Optional[str]
    created_at: datetime
    snippet: str  # Highlighted match
    message_count: int
```

#### A2.4 Frontend Components

**New files:**
- `/apps/web/src/components/chat/ConversationSearch.tsx`
- `/apps/web/src/components/chat/SearchResults.tsx`
- `/apps/web/src/hooks/useConversationSearch.ts`

**Integration in SessionSidebar:**
```tsx
function SessionSidebar() {
  const [searchQuery, setSearchQuery] = useState('')
  const [searchMode, setSearchMode] = useState(false)
  const { results, isSearching } = useConversationSearch(searchQuery)

  return (
    <div>
      <ConversationSearch
        value={searchQuery}
        onChange={setSearchQuery}
        onFocus={() => setSearchMode(true)}
        onClear={() => { setSearchQuery(''); setSearchMode(false) }}
      />

      {searchMode ? (
        <SearchResults results={results} loading={isSearching} />
      ) : (
        <GroupedSessions ... />
      )}
    </div>
  )
}
```

---

### A3. RAG Sync Status Dashboard

**Purpose:** Show RAG/embedding sync status with manual resync capability.

#### A3.1 Status Display

**Location:** Settings menu (expanded section) + dedicated settings page

**Status card:**
```
┌─────────────────────────────────────────────────┐
│ 📚 Knowledge Base                               │
├─────────────────────────────────────────────────┤
│ Last sync: 2 hours ago (Dec 21, 2:30 PM)        │
│ Files indexed: 1,247                            │
│ Total chunks: 8,512                             │
│ Embedding model: E5-multilingual                │
├─────────────────────────────────────────────────┤
│ [🔄 Resync Now]  [View Details]                 │
└─────────────────────────────────────────────────┘
```

**Sync states:**
- **Idle:** Normal state, shows last sync time
- **Running:** Progress bar with chunks processed
- **Failed:** Error message with retry option

#### A3.2 Database Model

```sql
CREATE TABLE sync_status (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sync_type VARCHAR(50) NOT NULL,  -- 'rag', 'calendar', 'tasks'
    status VARCHAR(20) NOT NULL DEFAULT 'idle',  -- 'idle', 'running', 'failed'
    last_sync_start TIMESTAMPTZ,
    last_sync_end TIMESTAMPTZ,
    files_processed INTEGER DEFAULT 0,
    chunks_created INTEGER DEFAULT 0,
    error_message TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Single row per sync_type
CREATE UNIQUE INDEX idx_sync_status_type ON sync_status(sync_type);
```

#### A3.3 API Endpoints

**New endpoints in** `/services/brain_runtime/api/sync.py`:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/sync/status` | GET | Get all sync statuses |
| `/sync/status/{type}` | GET | Get specific sync status |
| `/sync/trigger/{type}` | POST | Trigger manual resync |

**SSE for sync progress:**
```python
@router.get("/sync/progress/{job_id}")
async def stream_sync_progress(job_id: str):
    """Stream sync progress via SSE."""
    # Yields: { "type": "progress", "data": { "files": 120, "chunks": 450, "percent": 45 }}
```

#### A3.4 Frontend Components

**New files:**
- `/apps/web/src/components/settings/SyncStatusCard.tsx`
- `/apps/web/src/hooks/useSyncStatus.ts`

---

## Part B: Customization Layer

### B1. System Prompt Editor

**Purpose:** Allow users to customize the base system prompt that's prepended to all conversations.

#### B1.1 Editor Interface

**Location:** Settings page (new route: `/settings`)

**Editor features:**
- Monaco editor with markdown syntax highlighting
- Token count display (real-time)
- Variable placeholders support: `{{date}}`, `{{vault_stats}}`, `{{user_name}}`
- Preview mode (rendered markdown)
- Reset to default button
- Version history (last 5 saves)

**UI layout:**
```
┌─────────────────────────────────────────────────────────────┐
│ System Prompt Editor                    [Preview] [Save]    │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ You are a helpful AI assistant for my Second Brain.    │ │
│ │                                                         │ │
│ │ Today's date: {{date}}                                  │ │
│ │ My vault contains {{vault_stats}} notes.                │ │
│ │                                                         │ │
│ │ Always be concise and actionable.                       │ │
│ │ ...                                                     │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ 847 tokens · Variables: date, vault_stats                   │
│ [Reset to Default]                  [View History]          │
└─────────────────────────────────────────────────────────────┘
```

**Monaco Editor Component:**
```tsx
// apps/web/src/components/settings/SystemPromptEditor.tsx
'use client'

import Editor from '@monaco-editor/react'
import { useState, useCallback } from 'react'
import { estimateTokens } from '@/lib/token-utils'

interface SystemPromptEditorProps {
  value: string
  onChange: (value: string) => void
  onSave: () => void
  isSaving: boolean
}

export function SystemPromptEditor({ value, onChange, onSave, isSaving }: SystemPromptEditorProps) {
  const [tokenCount, setTokenCount] = useState(0)

  const handleEditorChange = useCallback((newValue: string | undefined) => {
    const content = newValue || ''
    onChange(content)
    // Debounced token estimation handled by useEffect in parent
    setTokenCount(estimateTokens(content))
  }, [onChange])

  return (
    <div className="space-y-4">
      <div className="border rounded-lg overflow-hidden">
        <Editor
          height="400px"
          defaultLanguage="markdown"
          value={value}
          onChange={handleEditorChange}
          theme="vs-light"
          options={{
            minimap: { enabled: false },
            wordWrap: 'on',
            lineNumbers: 'on',
            fontSize: 14,
            scrollBeyondLastLine: false,
            automaticLayout: true,
            tabSize: 2,
          }}
        />
      </div>

      <div className="flex items-center justify-between text-sm text-gray-600">
        <span>{tokenCount.toLocaleString()} tokens</span>
        <div className="space-x-2">
          <button
            onClick={onSave}
            disabled={isSaving}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg disabled:opacity-50"
          >
            {isSaving ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  )
}
```

**Variable resolution timing:** Variables are resolved **dynamically when each conversation starts**, not when the prompt is saved. This means `{{date}}` reflects the conversation creation date, not the prompt save date.

**History management:**
```python
def save_system_prompt(new_prompt: str, current_history: list) -> list:
    """Save prompt and maintain last 5 versions in history."""
    entry = {"content": new_prompt, "saved_at": datetime.now().isoformat()}
    history = [entry] + current_history
    return history[:5]  # Keep only last 5
```

#### B1.2 Database Model

```sql
ALTER TABLE user_settings ADD COLUMN system_prompt TEXT;
ALTER TABLE user_settings ADD COLUMN system_prompt_history JSONB DEFAULT '[]'::jsonb;
-- History format: [{"content": "...", "saved_at": "2025-12-21T..."}, ...]
```

#### B1.3 Variable Resolution

```python
SYSTEM_PROMPT_VARIABLES = {
    "date": lambda: datetime.now().strftime("%Y-%m-%d"),
    "datetime": lambda: datetime.now().strftime("%Y-%m-%d %H:%M"),
    "day_of_week": lambda: datetime.now().strftime("%A"),
    "vault_stats": lambda: get_vault_stats(),  # "1,247 notes, 8,512 chunks"
    "user_name": lambda: get_user_setting("display_name", "User"),
}

def resolve_system_prompt(template: str) -> str:
    """Replace {{variable}} placeholders with actual values."""
    result = template
    for var_name, resolver in SYSTEM_PROMPT_VARIABLES.items():
        placeholder = f"{{{{{var_name}}}}}"
        if placeholder in result:
            result = result.replace(placeholder, str(resolver()))
    return result
```

#### B1.4 Integration

**Modify** `/services/brain_runtime/api/chat.py`:
```python
async def build_system_prompt(mode: str, db: AsyncSession) -> str:
    """Build complete system prompt with user customization."""
    settings = await get_or_create_settings(db)

    # Start with user's custom prompt or default
    base_prompt = settings.system_prompt or DEFAULT_SYSTEM_PROMPT
    resolved = resolve_system_prompt(base_prompt)

    # Append mode-specific instructions
    if mode == "agent":
        resolved += "\n\n" + AGENT_MODE_ADDITIONS

    return resolved
```

---

### B2. API Key Management

**Purpose:** Securely manage API keys through the UI instead of .env files.

#### B2.1 Security Architecture

**Storage:** Encrypted in database using Fernet symmetric encryption

**First-time setup - generate encryption key:**
```bash
# Generate key (run once during initial setup)
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

# Add to .env file
echo "API_KEY_ENCRYPTION_KEY=<generated-key>" >> .env
```

**Add to `.env.example`:**
```bash
# Encryption key for API keys stored in database
# Generate with: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
API_KEY_ENCRYPTION_KEY=
```

**Encryption module:**
```python
# services/brain_runtime/core/encryption.py
import os
from pathlib import Path
from cryptography.fernet import Fernet

def get_encryption_key() -> bytes:
    """Get or generate encryption key for API key storage.

    Priority:
    1. Environment variable API_KEY_ENCRYPTION_KEY
    2. Local file data/secrets/encryption.key (auto-generated if missing)
    """
    env_key = os.getenv("API_KEY_ENCRYPTION_KEY")
    if env_key:
        return env_key.encode()

    # Fallback to local file (for development)
    key_path = Path("data/secrets/encryption.key")
    if key_path.exists():
        return key_path.read_bytes()

    # Generate new key (first run)
    key_path.parent.mkdir(parents=True, exist_ok=True)
    key = Fernet.generate_key()
    key_path.write_bytes(key)
    print(f"⚠️  Generated new encryption key at {key_path}")
    print("   Back up this file! Loss means losing access to stored API keys.")
    return key


# Initialize once at module load
_fernet = Fernet(get_encryption_key())


def encrypt_api_key(key: str) -> str:
    """Encrypt an API key for database storage."""
    return _fernet.encrypt(key.encode()).decode()


def decrypt_api_key(encrypted: str) -> str:
    """Decrypt an API key from database storage."""
    return _fernet.decrypt(encrypted.encode()).decode()


def get_key_suffix(key: str) -> str:
    """Get last 4 characters for display (e.g., '...7x2Q')."""
    return key[-4:] if len(key) >= 4 else key
```

**Database model:**
```sql
CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider VARCHAR(50) NOT NULL,  -- 'anthropic', 'openai', 'google'
    encrypted_key TEXT NOT NULL,
    key_suffix VARCHAR(8),  -- Last 4-8 chars for display: "...sk-abc123"
    is_valid BOOLEAN DEFAULT TRUE,
    last_validated TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_api_keys_provider ON api_keys(provider);
```

#### B2.2 UI Components

**Location:** Settings page → API Keys section

**Display:**
```
┌─────────────────────────────────────────────────────────────┐
│ API Keys                                                    │
├─────────────────────────────────────────────────────────────┤
│ Anthropic    sk-ant-...7x2Q    ✅ Valid    [Edit] [Test]    │
│ OpenAI       sk-proj-...9kLm   ✅ Valid    [Edit] [Test]    │
│ Google AI    (not set)          [Add Key]                   │
└─────────────────────────────────────────────────────────────┘
```

**Key entry flow:**
1. Click "Edit" or "Add Key"
2. Modal opens with password-style input
3. On save: encrypt and store
4. Automatic validation test
5. Show success/failure

#### B2.3 API Endpoints

**New file:** `/services/brain_runtime/api/api_keys.py`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/settings/api-keys` | GET | List keys (suffixes only, never full key) |
| `/settings/api-keys/{provider}` | PUT | Update key for provider |
| `/settings/api-keys/{provider}` | DELETE | Remove key |
| `/settings/api-keys/{provider}/test` | POST | Validate key works |

**Validation:**
```python
async def validate_anthropic_key(key: str) -> bool:
    """Test Anthropic API key with minimal request."""
    try:
        client = Anthropic(api_key=key)
        # Minimal request to validate
        await client.messages.create(
            model="claude-3-5-haiku-20241022",
            max_tokens=1,
            messages=[{"role": "user", "content": "hi"}]
        )
        return True
    except AuthenticationError:
        return False
```

#### B2.4 Priority Resolution

Keys are loaded with this priority:
1. Database (user-configured)
2. Environment variables (fallback)
3. Error if neither exists

```python
def get_api_key(provider: str) -> str:
    """Get API key with priority: DB > env > error."""
    # Try database first
    db_key = await get_db_api_key(provider)
    if db_key:
        return decrypt_api_key(db_key.encrypted_key)

    # Fallback to environment
    env_var = f"{provider.upper()}_API_KEY"
    env_key = os.getenv(env_var)
    if env_key:
        return env_key

    raise ConfigurationError(f"No API key configured for {provider}")
```

---

### B3. Modes System

**Purpose:** Custom conversation modes with their own system prompts, model preferences, and quick commands.

#### B3.1 Mode Definition

**A Mode contains:**
- Name (user-defined, e.g., "Research Mode", "Writing Assistant")
- Description (short summary)
- Icon (emoji or icon name)
- Color (for visual distinction)
- System prompt addition (appended to base prompt)
- Default model override
- Associated standard commands
- Visibility (active/archived)

**System prompt composition (in order):**
```
1. User's custom base system prompt (from B1)
   └─ OR default BASE_SYSTEM_PROMPT if none set

2. Mode's system_prompt_addition (if mode selected)
   └─ APPENDED to base, not replaced

3. Agent mode additions (if agent mode)
   └─ APPENDED for agentic capabilities
```

**Example:**
```
# User's base prompt (B1):
"You are a helpful AI assistant for my Second Brain.
Today's date: {{date}}"

# Mode prompt (Research mode):
"Focus on thorough research. Cite sources when possible.
Prefer depth over breadth."

# Final prompt for Research mode conversation:
"You are a helpful AI assistant for my Second Brain.
Today's date: 2025-12-21

Focus on thorough research. Cite sources when possible.
Prefer depth over breadth."
```

#### B3.2 Database Model

```sql
CREATE TABLE modes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT '💬',
    color VARCHAR(7) DEFAULT '#3B82F6',  -- Tailwind blue-500
    system_prompt_addition TEXT,
    default_model VARCHAR(100),
    sort_order INTEGER DEFAULT 0,
    is_default BOOLEAN DEFAULT FALSE,
    is_system BOOLEAN DEFAULT FALSE,  -- Built-in modes (Tools, Agent)
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ  -- Soft delete
);

-- Ensure only one default mode
CREATE UNIQUE INDEX idx_modes_default ON modes(is_default) WHERE is_default = TRUE AND deleted_at IS NULL;

-- Insert default modes
INSERT INTO modes (name, description, icon, is_system, is_default) VALUES
    ('General', 'General-purpose assistant', '💬', TRUE, TRUE),
    ('Research', 'Deep research and analysis', '🔍', TRUE, FALSE),
    ('Writing', 'Writing assistance and editing', '✍️', TRUE, FALSE);
```

#### B3.3 Standard Commands

**A Standard Command contains:**
- Name (short label for chip, e.g., "Summarize")
- Description (tooltip text)
- Full prompt (injected when clicked)
- Mode association (optional, can be global)

```sql
CREATE TABLE standard_commands (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mode_id UUID REFERENCES modes(id) ON DELETE CASCADE,  -- NULL = global
    name VARCHAR(50) NOT NULL,
    description VARCHAR(200),
    prompt TEXT NOT NULL,
    icon VARCHAR(50),
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Example commands
INSERT INTO standard_commands (mode_id, name, description, prompt) VALUES
    (NULL, 'Summarize', 'Create a brief summary', 'Please summarize the above in 2-3 bullet points.'),
    (NULL, 'Explain', 'Explain in simpler terms', 'Please explain this in simpler terms, as if to someone unfamiliar with the topic.'),
    (NULL, 'Action Items', 'Extract action items', 'Please extract all action items and tasks from the above, formatted as a checklist.');
```

#### B3.4 New Chat Interface with Mode Selection

**"New Chat" modal or inline:**
```
┌─────────────────────────────────────────────────────────────┐
│ New Conversation                                            │
├─────────────────────────────────────────────────────────────┤
│ Select a mode:                                              │
│                                                             │
│ [💬 General]  [🔍 Research]  [✍️ Writing]  [➕ Custom]      │
│                                                             │
│ Model: [Sonnet 4.5 ▼]                                       │
│                                                             │
│ Quick commands:                                             │
│ [Summarize] [Explain] [Action Items] [+ Add]                │
│                                                             │
│                                           [Start Chat]      │
└─────────────────────────────────────────────────────────────┘
```

**Mode selection behavior:**
1. Click mode chip → selects mode
2. Selected mode's system prompt addition is shown (collapsible)
3. Mode's default model pre-selected (can override)
4. Mode's commands shown as chips

#### B3.5 CRUD API

**New file:** `/services/brain_runtime/api/modes.py`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/modes` | GET | List all modes (with commands) |
| `/modes` | POST | Create custom mode |
| `/modes/{id}` | GET | Get mode details |
| `/modes/{id}` | PATCH | Update mode |
| `/modes/{id}` | DELETE | Soft delete mode |
| `/modes/{id}/commands` | GET | List mode's commands |
| `/modes/{id}/commands` | POST | Add command to mode |
| `/commands` | GET | List all commands (global + mode-specific) |
| `/commands/{id}` | PATCH | Update command |
| `/commands/{id}` | DELETE | Delete command |

#### B3.6 Frontend Components

**New files:**
- `/apps/web/src/components/modes/ModeSelector.tsx` - Chip-based selection
- `/apps/web/src/components/modes/ModeEditor.tsx` - Create/edit mode
- `/apps/web/src/components/modes/CommandChips.tsx` - Quick command buttons
- `/apps/web/src/components/modes/CommandEditor.tsx` - Create/edit command
- `/apps/web/src/components/modes/NewChatModal.tsx` - Mode + command selection
- `/apps/web/src/hooks/useModes.ts`
- `/apps/web/src/hooks/useCommands.ts`

**CommandChips in chat:**
```tsx
function CommandChips({ commands, onSelect }: Props) {
  return (
    <div className="flex flex-wrap gap-2 mb-2">
      {commands.map(cmd => (
        <button
          key={cmd.id}
          onClick={() => onSelect(cmd.prompt)}
          className="px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-full"
          title={cmd.description}
        >
          {cmd.icon} {cmd.name}
        </button>
      ))}
    </div>
  )
}
```

---

## Part C: Mobile & File Experience

### C1. Mobile-Ready Design

**Purpose:** Optimize the entire app for comfortable iPhone usage.

#### C1.1 Responsive Breakpoints

```css
/* Tailwind breakpoints */
/* sm: 640px - Large phones landscape */
/* md: 768px - Tablets */
/* lg: 1024px - Laptops */
/* xl: 1280px - Desktops */

/* Mobile-first approach */
.chat-container {
  @apply flex flex-col h-screen;
}

/* Sidebar hidden on mobile, overlay on tablet+ */
.sidebar {
  @apply fixed inset-y-0 left-0 z-40 w-72 transform -translate-x-full
         transition-transform duration-200 ease-in-out
         md:relative md:translate-x-0;
}

.sidebar.open {
  @apply translate-x-full;
}
```

#### C1.2 Touch Optimizations

**Minimum touch targets:** 44x44px (Apple HIG recommendation)

**Swipe gestures:**
- Swipe right from left edge → Open sidebar
- Swipe left on sidebar → Close sidebar
- Swipe down on chat → Refresh/scroll to top
- Long press on message → Context menu (copy, delete, etc.)

**Implementation:**
```tsx
import { useSwipeable } from 'react-swipeable'

function ChatLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const swipeHandlers = useSwipeable({
    onSwipedRight: () => setSidebarOpen(true),
    onSwipedLeft: () => setSidebarOpen(false),
    trackMouse: false,
    delta: 50,
  })

  return (
    <div {...swipeHandlers} className="h-screen overflow-hidden">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <ChatArea onMenuClick={() => setSidebarOpen(true)} />
    </div>
  )
}
```

#### C1.3 Mobile Navigation

**Bottom navigation bar (mobile only):**
```
┌─────────────────────────────────────────────────┐
│ [💬 Chat]  [📚 Vault]  [⚙️ Settings]  [➕ New]  │
└─────────────────────────────────────────────────┘
```

```tsx
function MobileNavBar() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 md:hidden
                    bg-white border-t flex justify-around py-2 safe-area-pb">
      <NavButton icon={ChatIcon} label="Chat" href="/" />
      <NavButton icon={FolderIcon} label="Vault" href="/vault" />
      <NavButton icon={SettingsIcon} label="Settings" href="/settings" />
      <NavButton icon={PlusIcon} label="New" onClick={openNewChat} />
    </nav>
  )
}
```

#### C1.4 Input Optimizations

**Mobile keyboard handling:**
```tsx
function MessageInput() {
  const inputRef = useRef<HTMLTextAreaElement>(null)

  // Adjust viewport when keyboard opens (iOS)
  useEffect(() => {
    if ('visualViewport' in window) {
      const handleResize = () => {
        const viewport = window.visualViewport!
        document.documentElement.style.setProperty(
          '--keyboard-height',
          `${window.innerHeight - viewport.height}px`
        )
      }

      window.visualViewport!.addEventListener('resize', handleResize)
      return () => window.visualViewport!.removeEventListener('resize', handleResize)
    }
  }, [])

  return (
    <div className="pb-[var(--keyboard-height,0px)]">
      <textarea
        ref={inputRef}
        className="w-full resize-none"
        enterKeyHint="send"
        inputMode="text"
      />
    </div>
  )
}
```

#### C1.5 PWA Configuration

**`apps/web/public/manifest.json`:**
```json
{
  "name": "Second Brain",
  "short_name": "Brain",
  "description": "AI-powered knowledge management",
  "start_url": "/",
  "display": "standalone",
  "orientation": "portrait",
  "background_color": "#ffffff",
  "theme_color": "#3B82F6",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```

**iOS-specific meta tags:**
```html
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Second Brain">
<link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
```

**Service Worker (required for PWA installation):**

Create `/apps/web/public/sw.js`:
```javascript
// Minimal service worker for PWA installation
// Enables "Add to Home Screen" on iOS/Android

const CACHE_NAME = 'second-brain-v1'

self.addEventListener('install', (event) => {
  // Skip waiting to activate immediately
  event.waitUntil(self.skipWaiting())
})

self.addEventListener('activate', (event) => {
  // Take control of all clients
  event.waitUntil(self.clients.claim())
})

// Network-first strategy - always fetch fresh content
self.addEventListener('fetch', (event) => {
  // Don't cache API calls or SSE streams
  if (event.request.url.includes('/api/') ||
      event.request.url.includes('/chat') ||
      event.request.headers.get('accept')?.includes('text/event-stream')) {
    return
  }

  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  )
})
```

Register in `/apps/web/src/app/layout.tsx`:
```tsx
// Add to layout.tsx after imports
useEffect(() => {
  if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
    navigator.serviceWorker.register('/sw.js')
  }
}, [])
```

**Tailwind safe-area utilities:**

Add to `apps/web/tailwind.config.js`:
```javascript
module.exports = {
  theme: {
    extend: {
      padding: {
        'safe-t': 'env(safe-area-inset-top)',
        'safe-b': 'env(safe-area-inset-bottom)',
        'safe-l': 'env(safe-area-inset-left)',
        'safe-r': 'env(safe-area-inset-right)',
      },
    },
  },
}
```

---

### C2. Context File Selection

**Purpose:** Allow users to select specific vault files to include in conversation context.

#### C2.1 File Picker Interface

**Location:** Above message input (expandable panel)

**UI:**
```
┌─────────────────────────────────────────────────────────────┐
│ 📎 Add context from vault                                   │
├─────────────────────────────────────────────────────────────┤
│ 🔍 Search files...                                          │
│ ─────────────────────────────────────────────────────────── │
│ Recent:                                                     │
│   📄 Daily/2025-12-21.md                          [+ Add]   │
│   📄 Projects/second-brain/README.md              [+ Add]   │
│ ─────────────────────────────────────────────────────────── │
│ Browse:                                                     │
│   📁 Notes/                                                 │
│   📁 Projects/                                              │
│   📁 Areas/                                                 │
└─────────────────────────────────────────────────────────────┘

Selected (2 files, ~1,240 tokens):
  [📄 Daily/2025-12-21.md ✕] [📄 Projects/README.md ✕]
```

#### C2.2 Data Model

```sql
CREATE TABLE chat_context_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    file_path VARCHAR(1000) NOT NULL,
    content_hash VARCHAR(64),  -- For cache invalidation
    token_count INTEGER,
    added_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(session_id, file_path)
);
```

#### C2.3 Context Injection

**Limits (prevent context window exhaustion):**
```python
MAX_CONTEXT_FILES = 10
MAX_CONTEXT_TOKENS = 50_000  # Leave room for conversation
```

**Backend integration:**
```python
async def get_session_context_files(
    session_id: str,
    db: AsyncSession
) -> List[ChatContextFile]:
    """Get context files, validating content hasn't changed."""
    result = await db.execute(
        select(ChatContextFileDB)
        .where(ChatContextFileDB.session_id == session_id)
        .order_by(ChatContextFileDB.added_at)
    )
    files = result.scalars().all()

    # Validate and update stale entries
    for f in files:
        current_hash = await hash_vault_file(f.file_path)
        if current_hash != f.content_hash:
            # File changed since added - update token count
            content = await read_vault_file(f.file_path)
            f.token_count = estimate_tokens(content)
            f.content_hash = current_hash
            await db.commit()

    return files


async def build_context_messages(
    session_id: str,
    db: AsyncSession
) -> List[dict]:
    """Build context messages from attached files with safety limits."""
    files = await get_session_context_files(session_id, db)

    if not files:
        return []

    # Enforce limits
    if len(files) > MAX_CONTEXT_FILES:
        raise ValueError(f"Too many context files ({len(files)}). Maximum: {MAX_CONTEXT_FILES}")

    total_tokens = sum(f.token_count or 0 for f in files)
    if total_tokens > MAX_CONTEXT_TOKENS:
        raise ValueError(
            f"Context too large ({total_tokens:,} tokens). "
            f"Maximum: {MAX_CONTEXT_TOKENS:,}. Remove some files."
        )

    # Build context with clear separators
    context_parts = []
    for f in files:
        content = await read_vault_file(f.file_path)
        context_parts.append(f"## {f.file_path}\n\n{content}")

    separator = "\n\n---\n\n"
    return [{
        "role": "user",
        "content": f"Here are files from my vault for context:\n\n{separator.join(context_parts)}"
    }]
```

#### C2.4 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/chat/sessions/{id}/context` | GET | List context files for session |
| `/chat/sessions/{id}/context` | POST | Add file to context |
| `/chat/sessions/{id}/context/{file_id}` | DELETE | Remove file from context |
| `/vault/browse` | GET | Browse vault directory structure |
| `/vault/search` | GET | Search vault files by name |

#### C2.5 Frontend Components

**New files:**
- `/apps/web/src/components/chat/ContextFilePicker.tsx`
- `/apps/web/src/components/chat/ContextFileList.tsx`
- `/apps/web/src/components/vault/VaultBrowser.tsx`
- `/apps/web/src/hooks/useContextFiles.ts`
- `/apps/web/src/hooks/useVaultBrowser.ts`

---

### C3. Drag and Drop Content

**Purpose:** Allow dropping files, images, and text onto the chat input.

#### C3.1 Supported Content Types

| Type | Handling |
|------|----------|
| Text files (.txt, .md) | Extract content, add to input |
| Images (.png, .jpg, .webp) | Process with vision, show preview |
| PDFs (.pdf) | Extract text, summarize if large |
| Code files (.py, .js, etc.) | Extract content, syntax highlight |
| Other | Show error, suggest alternatives |

#### C3.2 Drop Zone Implementation

```tsx
function MessageInput() {
  const [isDragging, setIsDragging] = useState(false)
  const [attachments, setAttachments] = useState<Attachment[]>([])

  const handleDrop = async (e: DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const items = Array.from(e.dataTransfer?.items || [])

    for (const item of items) {
      if (item.kind === 'file') {
        const file = item.getAsFile()
        if (file) {
          const attachment = await processDroppedFile(file)
          setAttachments(prev => [...prev, attachment])
        }
      } else if (item.kind === 'string') {
        item.getAsString(text => {
          // Append dropped text to input
          setInput(prev => prev + text)
        })
      }
    }
  }

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      className={cn(
        "relative border-2 rounded-lg transition-colors",
        isDragging ? "border-blue-500 bg-blue-50" : "border-gray-200"
      )}
    >
      {isDragging && (
        <div className="absolute inset-0 flex items-center justify-center bg-blue-50/90 z-10">
          <span className="text-blue-600 font-medium">Drop files here</span>
        </div>
      )}

      {attachments.length > 0 && (
        <AttachmentPreview attachments={attachments} onRemove={removeAttachment} />
      )}

      <textarea ... />
    </div>
  )
}
```

#### C3.3 Image Processing

**Flow:**
1. Image dropped → Create preview thumbnail
2. Image uploaded to temp storage (or base64 encoded)
3. On send → Include as vision content in message

```python
# Backend: Accept image content
class MessageContent(BaseModel):
    type: Literal["text", "image"]
    text: Optional[str] = None
    image_url: Optional[str] = None  # base64 data URL or URL

# Convert to Anthropic format
def to_anthropic_content(content: MessageContent) -> dict:
    if content.type == "text":
        return {"type": "text", "text": content.text}
    elif content.type == "image":
        return {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": "image/png",  # or detected type
                "data": content.image_url.split(",")[1]  # Remove data:image/png;base64,
            }
        }
```

#### C3.4 Attachment Preview Component

```tsx
function AttachmentPreview({ attachments, onRemove }: Props) {
  return (
    <div className="flex flex-wrap gap-2 p-2 border-b">
      {attachments.map((att, i) => (
        <div key={i} className="relative group">
          {att.type === 'image' ? (
            <img src={att.preview} className="w-16 h-16 object-cover rounded" />
          ) : (
            <div className="w-16 h-16 flex items-center justify-center bg-gray-100 rounded">
              <FileIcon className="w-8 h-8 text-gray-400" />
            </div>
          )}
          <button
            onClick={() => onRemove(i)}
            className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full
                       opacity-0 group-hover:opacity-100 transition-opacity"
          >
            ✕
          </button>
          <span className="text-xs truncate max-w-[64px] block text-center mt-1">
            {att.name}
          </span>
        </div>
      ))}
    </div>
  )
}
```

---

### C4. File Upload to Vault

**Purpose:** Upload external files, convert to markdown, and place in vault with proper organization.

#### C4.1 Upload Flow

```
┌─────────────────────────────────────────────────────────────┐
│ Upload to Vault                                             │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────┐ │
│ │                                                         │ │
│ │       📁 Drop file here or click to browse              │ │
│ │                                                         │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ File: research_paper.pdf (2.4 MB)                           │
│ Type: PDF Document                                          │
├─────────────────────────────────────────────────────────────┤
│ Destination folder:                                         │
│ [📁 Resources/Papers ▼]                                     │
│                                                             │
│ Output filename:                                            │
│ [research_paper.md                            ]             │
│                                                             │
│ Options:                                                    │
│ ☑️ Convert to Markdown                                      │
│ ☑️ Add frontmatter with source info                         │
│ ☐ Keep original file alongside                              │
├─────────────────────────────────────────────────────────────┤
│ Preview:                                                    │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ ---                                                     │ │
│ │ source: research_paper.pdf                              │ │
│ │ imported: 2025-12-21                                    │ │
│ │ ---                                                     │ │
│ │                                                         │ │
│ │ # Research Paper Title                                  │ │
│ │                                                         │ │
│ │ ## Abstract                                             │ │
│ │ Lorem ipsum dolor sit amet...                           │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│                            [Cancel]  [Upload & Convert]     │
└─────────────────────────────────────────────────────────────┘
```

#### C4.2 Supported Conversions

| Input Format | Conversion Method |
|--------------|-------------------|
| PDF | PyMuPDF (text extraction) + optional OCR |
| DOCX | python-docx → markdown |
| HTML | BeautifulSoup → markdownify |
| TXT | Direct copy with frontmatter |
| Images | Store in attachments folder, create note with embed |
| EPUB | ebooklib → markdown |

#### C4.3 Backend Implementation

**New file:** `/services/brain_runtime/core/file_converter.py`

```python
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import asyncio
import pymupdf  # PyMuPDF (note: import name changed from 'fitz' in v1.26+)
from docx import Document
from markdownify import markdownify

# Thread pool for blocking I/O operations
_executor = ThreadPoolExecutor(max_workers=2)

class UnsupportedFormatError(Exception):
    """File format not supported for conversion."""
    pass

class FileConverter:
    """Convert various file formats to markdown."""

    SUPPORTED_FORMATS = {
        '.pdf': '_convert_pdf_sync',
        '.docx': '_convert_docx_sync',
        '.doc': '_convert_docx_sync',
        '.html': '_convert_html_sync',
        '.htm': '_convert_html_sync',
        '.txt': '_convert_text_sync',
        '.epub': '_convert_epub_sync',
    }

    # MIME type mapping for upload validation
    MIME_TO_EXTENSION = {
        'application/pdf': '.pdf',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
        'application/msword': '.doc',
        'text/html': '.html',
        'text/plain': '.txt',
        'application/epub+zip': '.epub',
    }

    async def convert(
        self,
        file_path: Path,
        add_frontmatter: bool = True,
    ) -> str:
        """Convert file to markdown. Runs blocking I/O in thread pool."""
        suffix = file_path.suffix.lower()

        if suffix not in self.SUPPORTED_FORMATS:
            raise UnsupportedFormatError(f"Cannot convert {suffix} files")

        # Run blocking conversion in thread pool
        method_name = self.SUPPORTED_FORMATS[suffix]
        method = getattr(self, method_name)
        loop = asyncio.get_event_loop()
        content = await loop.run_in_executor(_executor, method, file_path)

        if add_frontmatter:
            frontmatter = self._generate_frontmatter(file_path)
            content = f"{frontmatter}\n\n{content}"

        return content

    def _generate_frontmatter(self, file_path: Path) -> str:
        return f"""---
source: {file_path.name}
imported: {datetime.now().strftime('%Y-%m-%d')}
type: imported
---"""

    def _convert_pdf_sync(self, file_path: Path) -> str:
        """Extract text from PDF (blocking, runs in thread pool)."""
        doc = pymupdf.open(file_path)
        text_parts = []

        for page in doc:
            text_parts.append(page.get_text())

        doc.close()
        return "\n\n".join(text_parts)

    def _convert_docx_sync(self, file_path: Path) -> str:
        """Convert DOCX to markdown (blocking, runs in thread pool)."""
        doc = Document(file_path)
        md_parts = []

        for para in doc.paragraphs:
            if para.style.name.startswith('Heading'):
                level = int(para.style.name[-1]) if para.style.name[-1].isdigit() else 1
                md_parts.append(f"{'#' * level} {para.text}")
            else:
                md_parts.append(para.text)

        return "\n\n".join(md_parts)

    def _convert_html_sync(self, file_path: Path) -> str:
        """Convert HTML to markdown (blocking, runs in thread pool)."""
        with open(file_path, 'r', encoding='utf-8') as f:
            html = f.read()
        return markdownify(html, heading_style='ATX')

    def _convert_text_sync(self, file_path: Path) -> str:
        """Read plain text file."""
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()

    def _convert_epub_sync(self, file_path: Path) -> str:
        """Convert EPUB to markdown (requires ebooklib)."""
        import ebooklib
        from ebooklib import epub

        book = epub.read_epub(file_path)
        text_parts = []

        for item in book.get_items_of_type(ebooklib.ITEM_DOCUMENT):
            html_content = item.get_content().decode('utf-8')
            text_parts.append(markdownify(html_content, heading_style='ATX'))

        return "\n\n".join(text_parts)
```

#### C4.4 API Endpoints

**New file:** `/services/brain_runtime/api/upload.py`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/upload/preview` | POST | Upload file, return conversion preview |
| `/upload/commit` | POST | Commit converted file to vault |
| `/upload/formats` | GET | List supported formats |

```python
@router.post("/upload/preview")
async def preview_upload(
    file: UploadFile,
    destination_folder: str = Form(...),
    convert_to_markdown: bool = Form(True),
):
    """Preview file conversion before committing."""
    # Save temp file
    temp_path = await save_temp_file(file)

    # Convert
    converter = FileConverter()
    preview_content = await converter.convert(temp_path)

    # Estimate tokens
    token_count = estimate_tokens(preview_content)

    return {
        "original_name": file.filename,
        "original_size": file.size,
        "converted_content": preview_content[:5000],  # Preview truncated
        "full_length": len(preview_content),
        "token_count": token_count,
        "suggested_filename": Path(file.filename).stem + ".md",
        "temp_id": temp_path.name,  # For commit
    }

@router.post("/upload/commit")
async def commit_upload(
    temp_id: str = Form(...),
    destination_folder: str = Form(...),
    filename: str = Form(...),
    add_frontmatter: bool = Form(True),
):
    """Commit converted file to vault."""
    # Validate destination is within vault
    vault_path = validate_vault_path(f"{destination_folder}/{filename}")

    # Get converted content
    converter = FileConverter()
    content = await converter.convert(get_temp_path(temp_id), add_frontmatter)

    # Write to vault
    vault_path.parent.mkdir(parents=True, exist_ok=True)
    vault_path.write_text(content, encoding='utf-8')

    # Cleanup temp file
    cleanup_temp(temp_id)

    return {
        "success": True,
        "path": str(vault_path.relative_to(VAULT_ROOT)),
    }
```

**Temp file management:**
```python
# services/brain_runtime/core/temp_manager.py
import time
import asyncio
from pathlib import Path
from uuid import uuid4

TEMP_DIR = Path("data/temp/uploads")
TEMP_TTL_SECONDS = 3600  # 1 hour

async def save_temp_file(file: UploadFile) -> Path:
    """Save uploaded file to temp storage with timestamp for cleanup."""
    TEMP_DIR.mkdir(parents=True, exist_ok=True)

    # Include timestamp in filename for age-based cleanup
    timestamp = int(time.time())
    temp_path = TEMP_DIR / f"{uuid4()}_{timestamp}{Path(file.filename).suffix}"

    content = await file.read()
    temp_path.write_bytes(content)

    return temp_path


def get_temp_path(temp_id: str) -> Path:
    """Get temp file path from ID."""
    matches = list(TEMP_DIR.glob(f"{temp_id}*"))
    if not matches:
        raise FileNotFoundError(f"Temp file not found: {temp_id}")
    return matches[0]


def cleanup_temp(temp_id: str) -> None:
    """Delete temp file after commit."""
    try:
        path = get_temp_path(temp_id)
        path.unlink()
    except FileNotFoundError:
        pass  # Already cleaned up


async def cleanup_old_temps() -> int:
    """Remove temp files older than TTL. Run periodically."""
    if not TEMP_DIR.exists():
        return 0

    now = time.time()
    deleted = 0

    for temp_file in TEMP_DIR.iterdir():
        if not temp_file.is_file():
            continue

        # Extract timestamp from filename (uuid_timestamp.ext)
        try:
            name_parts = temp_file.stem.rsplit("_", 1)
            if len(name_parts) == 2:
                timestamp = int(name_parts[1])
                if now - timestamp > TEMP_TTL_SECONDS:
                    temp_file.unlink()
                    deleted += 1
        except (ValueError, IndexError):
            # Can't parse timestamp, delete if file is old by mtime
            if now - temp_file.stat().st_mtime > TEMP_TTL_SECONDS:
                temp_file.unlink()
                deleted += 1

    return deleted


# Register cleanup task on startup
async def start_temp_cleanup_task():
    """Background task to clean up old temp files every 10 minutes."""
    while True:
        await asyncio.sleep(600)  # 10 minutes
        deleted = await cleanup_old_temps()
        if deleted > 0:
            logger.info(f"Cleaned up {deleted} old temp files")
```

**Path validation (security):**
```python
def validate_vault_path(relative_path: str) -> Path:
    """Validate path is within vault root. Prevents directory traversal."""
    vault_root = Path(os.getenv("OBSIDIAN_VAULT_PATH"))

    # Normalize and resolve path
    full_path = (vault_root / relative_path).resolve()

    # Security check: must be within vault
    try:
        full_path.relative_to(vault_root.resolve())
    except ValueError:
        raise ValueError(f"Path outside vault: {relative_path}")

    return full_path
```

#### C4.5 Frontend Components

**New files:**
- `/apps/web/src/components/upload/FileUploadModal.tsx`
- `/apps/web/src/components/upload/ConversionPreview.tsx`
- `/apps/web/src/components/upload/FolderSelector.tsx`
- `/apps/web/src/hooks/useFileUpload.ts`

---

## Part D: Settings Page

**Purpose:** Centralized settings management.

### D1. Settings Page Layout

**Route:** `/settings`

```
┌─────────────────────────────────────────────────────────────┐
│ Settings                                                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ ┌─ General ──────────────────────────────────────────────┐  │
│ │ Display name: [Tijl                            ]       │  │
│ │ Theme:        [System ▼]                               │  │
│ │ YOLO Mode:    [Toggle]                                 │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                             │
│ ┌─ System Prompt ────────────────────────────────────────┐  │
│ │ [Edit System Prompt →]                                 │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                             │
│ ┌─ API Keys ─────────────────────────────────────────────┐  │
│ │ Anthropic: ••••••7x2Q  ✅  [Edit]                      │  │
│ │ OpenAI:    ••••••9kLm  ✅  [Edit]                      │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                             │
│ ┌─ Modes ────────────────────────────────────────────────┐  │
│ │ [Manage Modes →]                                       │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                             │
│ ┌─ Knowledge Base ───────────────────────────────────────┐  │
│ │ Last sync: 2 hours ago                                 │  │
│ │ Files: 1,247  Chunks: 8,512                            │  │
│ │ [🔄 Resync Now]                                        │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                             │
│ ┌─ Data ─────────────────────────────────────────────────┐  │
│ │ [Export Conversations]                                 │  │
│ │ [Clear Chat History]                                   │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Database Migration Summary

```sql
-- Phase 9 Migrations

-- A1: Token tracking
ALTER TABLE chat_sessions ADD COLUMN total_input_tokens INTEGER DEFAULT 0;
ALTER TABLE chat_sessions ADD COLUMN total_output_tokens INTEGER DEFAULT 0;
ALTER TABLE chat_sessions ADD COLUMN total_cost_usd DECIMAL(10,6) DEFAULT 0;

-- A2: Conversation search
ALTER TABLE chat_messages ADD COLUMN search_vector tsvector;
CREATE INDEX idx_messages_search ON chat_messages USING GIN(search_vector);
-- Plus trigger for auto-update (see A2.2)

-- A3: Sync status
CREATE TABLE sync_status (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sync_type VARCHAR(50) NOT NULL UNIQUE,
    status VARCHAR(20) NOT NULL DEFAULT 'idle',
    last_sync_start TIMESTAMPTZ,
    last_sync_end TIMESTAMPTZ,
    files_processed INTEGER DEFAULT 0,
    chunks_created INTEGER DEFAULT 0,
    error_message TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- B1: System prompt
ALTER TABLE user_settings ADD COLUMN system_prompt TEXT;
ALTER TABLE user_settings ADD COLUMN system_prompt_history JSONB DEFAULT '[]'::jsonb;

-- B2: API keys
CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider VARCHAR(50) NOT NULL UNIQUE,
    encrypted_key TEXT NOT NULL,
    key_suffix VARCHAR(8),
    is_valid BOOLEAN DEFAULT TRUE,
    last_validated TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- B3: Modes
CREATE TABLE modes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT '💬',
    color VARCHAR(7) DEFAULT '#3B82F6',
    system_prompt_addition TEXT,
    default_model VARCHAR(100),
    sort_order INTEGER DEFAULT 0,
    is_default BOOLEAN DEFAULT FALSE,
    is_system BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

CREATE TABLE standard_commands (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mode_id UUID REFERENCES modes(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(200),
    prompt TEXT NOT NULL,
    icon VARCHAR(50),
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Link sessions to modes
ALTER TABLE chat_sessions ADD COLUMN mode_id UUID REFERENCES modes(id);

-- C2: Context files
CREATE TABLE chat_context_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    file_path VARCHAR(1000) NOT NULL,
    content_hash VARCHAR(64),
    token_count INTEGER,
    added_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(session_id, file_path)
);

-- Seed default modes
INSERT INTO modes (name, description, icon, is_system, is_default) VALUES
    ('General', 'General-purpose assistant', '💬', TRUE, TRUE),
    ('Research', 'Deep research and analysis', '🔍', TRUE, FALSE),
    ('Writing', 'Writing assistance and editing', '✍️', TRUE, FALSE);

-- Seed default commands
INSERT INTO standard_commands (mode_id, name, description, prompt) VALUES
    (NULL, 'Summarize', 'Create a brief summary', 'Please summarize the above in 2-3 bullet points.'),
    (NULL, 'Explain', 'Explain in simpler terms', 'Please explain this in simpler terms, as if to someone unfamiliar with the topic.'),
    (NULL, 'Action Items', 'Extract action items', 'Please extract all action items and tasks from the above, formatted as a checklist.'),
    (NULL, 'Translate', 'Translate to another language', 'Please translate the above to [specify language].'),
    (NULL, 'Fix Grammar', 'Correct grammar and spelling', 'Please correct any grammar, spelling, or punctuation errors in the above text.');
```

---

## New Files Summary

### Backend
```
services/brain_runtime/
├── api/
│   ├── search.py          # Conversation search
│   ├── sync.py            # RAG sync status
│   ├── api_keys.py        # API key management
│   ├── modes.py           # Modes CRUD
│   └── upload.py          # File upload/conversion
├── core/
│   ├── file_converter.py  # PDF/DOCX/HTML → Markdown
│   └── token_counter.py   # Token estimation utilities
└── models/
    ├── search.py          # Search models
    ├── mode.py            # Mode/Command models
    └── upload.py          # Upload models
```

### Frontend
```
apps/web/src/
├── app/
│   ├── settings/
│   │   └── page.tsx           # Settings page
│   └── vault/
│       └── page.tsx           # Vault browser (mobile nav)
├── components/
│   ├── chat/
│   │   ├── TokenCounter.tsx
│   │   ├── ConversationSearch.tsx
│   │   ├── SearchResults.tsx
│   │   ├── ContextFilePicker.tsx
│   │   ├── ContextFileList.tsx
│   │   ├── AttachmentPreview.tsx
│   │   └── MobileNavBar.tsx
│   ├── modes/
│   │   ├── ModeSelector.tsx
│   │   ├── ModeEditor.tsx
│   │   ├── CommandChips.tsx
│   │   ├── CommandEditor.tsx
│   │   └── NewChatModal.tsx
│   ├── settings/
│   │   ├── GeneralSettings.tsx
│   │   ├── SystemPromptEditor.tsx
│   │   ├── ApiKeyManager.tsx
│   │   ├── SyncStatusCard.tsx
│   │   └── ModeManager.tsx
│   ├── upload/
│   │   ├── FileUploadModal.tsx
│   │   ├── ConversionPreview.tsx
│   │   └── FolderSelector.tsx
│   └── vault/
│       └── VaultBrowser.tsx
├── hooks/
│   ├── useTokenCount.ts
│   ├── useConversationSearch.ts
│   ├── useSyncStatus.ts
│   ├── useModes.ts
│   ├── useCommands.ts
│   ├── useContextFiles.ts
│   ├── useVaultBrowser.ts
│   └── useFileUpload.ts
└── lib/
    ├── search-api.ts
    ├── modes-api.ts
    ├── upload-api.ts
    └── token-utils.ts
```

---

## Implementation Order

### Sprint 1: Foundation
1. Database migrations
2. Settings page layout
3. Mobile responsive framework (breakpoints, nav)

### Sprint 2: Token & Search
4. Token counter (backend + frontend)
5. Conversation search (full-text)
6. RAG sync status dashboard

### Sprint 3: Customization
7. System prompt editor
8. API key management
9. Modes CRUD (database + API)
10. Standard commands CRUD

### Sprint 4: Modes UI
11. Mode selector chips
12. New chat modal with mode selection
13. Command chips in chat
14. Mode/command editors

### Sprint 5: Files & Upload
15. Context file picker
16. Drag and drop handling
17. File upload modal
18. File conversion engine (PDF, DOCX, HTML)

### Sprint 6: Mobile Polish
19. Touch gesture handlers
20. Mobile navigation bar
21. PWA manifest + icons
22. Keyboard/viewport handling
23. Safe area insets

---

## Additional Recommendations

### Considered but Deferred

1. **Conversation Branching**
   - Fork conversations at any point
   - Complexity: High (tree structure, UI challenges)
   - Defer to Phase 10

2. **Keyboard Shortcuts**
   - CMD+K command palette
   - Already have Claude Code patterns
   - Consider after mobile complete

3. **Voice Input**
   - Web Speech API on mobile
   - iOS Safari has limitations
   - Consider as mobile enhancement

4. **Offline Support**
   - Service workers for PWA
   - Complex with real-time chat
   - Consider if users request

5. **Semantic Search**
   - Use existing ChromaDB embeddings for conversation search
   - Requires embedding conversation content
   - Consider as search enhancement

### Strongly Recommended Additions

1. **Export Conversations**
   - Markdown, JSON, PDF export
   - Simple to implement, high utility
   - Add to Settings page

2. **Conversation Archiving**
   - Archive old sessions (hidden but not deleted)
   - Helps manage session list
   - Add archive button + filter

3. **Cost Tracking Dashboard**
   - Historical usage graphs
   - Daily/weekly/monthly costs
   - Budget alerts

4. **Theme Support**
   - Light/dark mode toggle
   - System preference detection
   - Essential for mobile

---

## Testing Checklist

### Token Counter
- [ ] Shows session totals (input + output + cost)
- [ ] Updates in real-time as user types
- [ ] Expands to show detailed breakdown
- [ ] Context window percentage accurate
- [ ] Cost calculation matches model pricing

### Conversation Search
- [ ] Keyword search finds matches
- [ ] Results show highlighted snippets
- [ ] Date filter works (today, week, month, custom)
- [ ] Click result opens conversation
- [ ] Search clears properly

### System Prompt Editor
- [ ] Editor loads current prompt
- [ ] Syntax highlighting works
- [ ] Token count updates live
- [ ] Variables resolve correctly ({{date}}, etc.)
- [ ] Save persists to database
- [ ] Reset to default works
- [ ] History shows previous versions

### API Keys
- [ ] List shows masked keys (suffix only)
- [ ] Edit modal accepts new key
- [ ] Validation test succeeds/fails appropriately
- [ ] Keys encrypted in database
- [ ] Keys work for API calls
- [ ] Delete removes key

### Modes
- [ ] Default modes seeded
- [ ] Create custom mode works
- [ ] Mode chips display in new chat
- [ ] Selecting mode applies system prompt
- [ ] Model override works
- [ ] Edit/delete mode works
- [ ] Sort order respected

### Standard Commands
- [ ] Default commands seeded
- [ ] Command chips display in chat
- [ ] Clicking command injects prompt
- [ ] Create/edit/delete works
- [ ] Mode-specific vs global works

### Mobile
- [ ] Responsive at all breakpoints
- [ ] Sidebar swipe gestures work
- [ ] Bottom nav appears on mobile
- [ ] Touch targets 44px minimum
- [ ] Keyboard doesn't break layout
- [ ] PWA installs correctly

### Context Files
- [ ] File picker shows vault structure
- [ ] Search finds files
- [ ] Selected files show in list
- [ ] Token estimate accurate
- [ ] Files injected into context
- [ ] Remove file works

### Drag & Drop
- [ ] Drop zone highlights on drag
- [ ] Text files extract content
- [ ] Images show preview
- [ ] Images sent with vision
- [ ] Unsupported types show error
- [ ] Multiple files work

### File Upload
- [ ] PDF conversion works
- [ ] DOCX conversion works
- [ ] HTML conversion works
- [ ] Folder selector shows vault structure
- [ ] Preview shows converted content
- [ ] Frontmatter added correctly
- [ ] File placed in correct location

### RAG Sync
- [ ] Status shows last sync time
- [ ] File/chunk counts accurate
- [ ] Resync button triggers job
- [ ] Progress shows during sync
- [ ] Errors display clearly

---

## Success Criteria

Phase 9 is complete when:

1. **Token Counter**: Real-time visibility into token usage and costs
2. **Conversation Search**: Full-text search with date filtering works
3. **System Prompt Editor**: User can customize global system prompt
4. **API Key Management**: Secure UI for managing API keys
5. **Modes**: Custom modes with system prompts and model selection
6. **Standard Commands**: Quick action chips in chat
7. **Mobile Design**: Comfortable use on iPhone
8. **Context Files**: Select vault files to include in conversation
9. **Drag & Drop**: Files and images can be dropped onto chat
10. **RAG Status**: Visible sync status with manual resync
11. **File Upload**: Upload external files, convert to markdown, place in vault
12. **Settings Page**: Centralized settings management

---

## Open Questions

1. **Semantic Search**: Should conversation search use ChromaDB embeddings?
   - Tradeoff: More accurate vs. additional complexity
   - Recommendation: Start with full-text, add semantic later

2. **Image Storage**: Where to store dropped images?
   - Option A: Base64 in message content (simpler, larger payloads)
   - Option B: Temp file storage + URLs (complex, cleaner)
   - Recommendation: Base64 for now, optimize later

3. **File Conversion Quality**: What's acceptable for PDF extraction?
   - Complex layouts may not convert well
   - Should we offer OCR for scanned PDFs?
   - Recommendation: Text extraction only, note limitations

4. **Mode Sharing**: Should modes be exportable/importable?
   - Useful for sharing configurations
   - Add to Phase 10 if requested

---

## Dependencies

### Python (services/brain_runtime/pyproject.toml)

Add to dependencies:
```toml
[project]
dependencies = [
    # ... existing dependencies ...

    # Phase 9 additions:
    "cryptography>=46.0.0",       # API key encryption (Fernet)
    "pymupdf>=1.26.0",            # PDF text extraction
    "python-docx>=1.2.0",         # DOCX conversion
    "markdownify>=1.2.0",         # HTML to markdown
    "ebooklib>=0.18",             # EPUB conversion
]
```

### JavaScript (apps/web/package.json)

Add to dependencies:
```json
{
  "dependencies": {
    "@monaco-editor/react": "^4.6.0",
    "gpt-tokenizer": "^2.8.0",
    "react-swipeable": "^7.0.2"
  }
}
```

### Environment Variables

Add to `.env.example`:
```bash
# Phase 9 additions:

# Encryption key for API keys stored in database
# Generate with: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
API_KEY_ENCRYPTION_KEY=
```

### File Size Limits

Configure in upload handler:
```python
MAX_FILE_SIZES = {
    'application/pdf': 20 * 1024 * 1024,        # 20 MB
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 10 * 1024 * 1024,  # 10 MB
    'text/html': 5 * 1024 * 1024,               # 5 MB
    'text/plain': 5 * 1024 * 1024,              # 5 MB
    'image/*': 5 * 1024 * 1024,                 # 5 MB (for vision)
    'default': 10 * 1024 * 1024,                # 10 MB fallback
}
```
