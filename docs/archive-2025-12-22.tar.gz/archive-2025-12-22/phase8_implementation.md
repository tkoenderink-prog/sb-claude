# Phase 8 Implementation Plan: Write Mode & UI/UX Improvements

**Status:** PENDING
**Created:** 2025-12-21
**Depends on:** Phase 7B (Complete)
**Complexity:** High

---

## Executive Summary

Phase 8 transforms the Second Brain app with two major components:
1. **UI/UX Improvements**: Make Chat the homepage, simplify modes, add title generation, settings menu
2. **Write Mode Core**: Proposal creation, diff viewer, approve/apply workflow, YOLO mode

| Feature | Current State | Phase 8 Target |
|---------|---------------|----------------|
| Homepage | Dashboard at `/` | Chat at `/` |
| Chat Modes | Quick/Tools/Agent | Tools/Agent only |
| Default Model | Sonnet 4 | Sonnet 4.5 |
| Session Titles | Truncated first message | AI-generated 3-4 words |
| File Changes | Not supported | Proposals with diff/approve |
| Settings | None | Menu with YOLO toggle |

---

## Part A: UI/UX Changes

### A1. Route Restructuring - Make Chat Homepage

**Files to modify:**
- `/apps/web/src/app/page.tsx` - Replace dashboard with chat
- `/apps/web/src/app/layout.tsx` - Remove Navigation component
- `/apps/web/src/app/chat/page.tsx` - Keep for backwards compatibility (redirect)

**New files:**
- `/apps/web/src/app/dashboard/page.tsx` - Dashboard moved here

**Changes:**
1. Move current `page.tsx` dashboard content to `dashboard/page.tsx`
2. Copy current `chat/page.tsx` content to root `page.tsx`
3. Update `chat/page.tsx` to redirect to `/`
4. Remove `Navigation.tsx` import from `layout.tsx`
5. Delete `/apps/web/src/components/Navigation.tsx`

### A2. Mode Simplification - Remove Quick Chat

**Files to modify:**
- `/apps/web/src/components/chat/ModeSelector.tsx`
- `/apps/web/src/components/chat/ChatContainer.tsx`
- `/apps/web/src/lib/chat-api.ts`
- `/services/brain_runtime/models/db_models.py` (backend enum)

**Changes:**
1. `ModeSelector.tsx`: Remove 'quick' from modes array, keep only 'tools' and 'agent'
2. `ChatContainer.tsx`: Find the mode useState hook initialized to `'quick'` and change to `'tools'`
3. `ChatContainer.tsx`: Update placeholder text - remove quick case from the ternary
4. `chat-api.ts`: Update `ChatMode` type to `'tools' | 'agent'`
5. `db_models.py`: Update `ChatModeEnum` to remove 'quick' value

### A3. Default Model - Sonnet 4.5

**File to modify:**
- `/apps/web/src/components/chat/ChatContainer.tsx`

**Change:**
- Find the model useState hook initialized to `'claude-sonnet-4-20250514'`
- Change to `'claude-sonnet-4-5-20250929'`

### A4. Auto-Focus Input Box

**Files to modify:**
- `/apps/web/src/components/chat/MessageInput.tsx`
- `/apps/web/src/components/chat/ChatContainer.tsx`

**Changes:**
1. `MessageInput.tsx`:
   - Add `autoFocus?: boolean` prop
   - Add `useEffect` to focus on mount when `autoFocus` is true
   - Expose ref for parent control via `useImperativeHandle` or prop
2. `ChatContainer.tsx`:
   - Pass `autoFocus={true}` to MessageInput
   - Focus input when `propSessionId` becomes null (new chat)

### A5. Title Generation via Haiku 4.5

**Backend changes:**
- `/services/brain_runtime/api/chat.py`: Add `POST /chat/sessions/{id}/title` endpoint
- `/services/brain_runtime/models/db_models.py`: Add `title: Optional[str]` column to `ChatSessionDB`
- `/services/brain_runtime/models/chat.py`: Add `TitleRequest`/`TitleResponse` models

**Frontend changes:**
- `/apps/web/src/hooks/useChat.ts`: Add title generation after first assistant response
- `/apps/web/src/lib/chat-api.ts`: Add `generateTitle()` function
- `/apps/web/src/components/chat/ChatContainer.tsx`: Display generated title
- `/apps/web/src/components/chat/SessionSidebar.tsx`: Show title instead of preview

**Database migration:**
```sql
ALTER TABLE chat_sessions ADD COLUMN title VARCHAR(100);
```

**Title generation prompt:**
```
Generate a 3-4 word title summarizing this conversation.
User: {first_user_message}
Assistant: {first_assistant_response}
Respond with ONLY the title, no quotes or punctuation.
```

**Title generation timing:**
- Trigger: After first assistant response completes (when streaming ends)
- Condition: Session exists AND session has no title AND not already generating
- If generation fails: Log error, keep session without title (no user-facing error)
- If user sends another message before title generates: Let title generation complete in background

### A6. Settings Menu in SessionSidebar

**New file:**
- `/apps/web/src/components/chat/SettingsMenu.tsx`

**File to modify:**
- `/apps/web/src/components/chat/SessionSidebar.tsx`

**SettingsMenu component structure:**
```tsx
<div className="border-t p-2">
  <button onClick={toggleOpen}>
    <SettingsIcon /> Settings
  </button>
  {isOpen && (
    <div className="absolute bottom-12 left-0 bg-white shadow-lg rounded-md">
      <Link href="/dashboard">Dashboard</Link>
      <Link href="/skills">Skills</Link>
      <Divider />
      <Toggle label="YOLO Mode" value={yoloMode} onChange={setYoloMode} />
    </div>
  )}
</div>
```

**Placement in SessionSidebar:**
- Add at the bottom of the sidebar container, before the final closing `</div>`
- Use `flex flex-col h-full` on container and `mt-auto` on SettingsMenu to push to bottom

### A7. Health Chip - Floating Top-Left

**New file:**
- `/apps/web/src/components/chat/HealthChip.tsx` (simplified HealthIndicator)

**File to modify:**
- `/apps/web/src/app/page.tsx` (new chat homepage)

**Changes:**
1. Create minimal `HealthChip` component that shows green/yellow/red dot
2. Position with `fixed top-4 left-4 z-50`
3. Add to chat page layout outside SessionSidebar

**Health states:**
- **Green**: API responds within 500ms
- **Yellow**: API responds but >500ms, or <5 min since last error
- **Red**: API unreachable or error in last response

**Behavior:**
- Polling interval: Every 30 seconds
- Click: Navigate to `/dashboard`
- Tooltip: Show status text on hover (e.g., "Backend healthy" or "Connection lost")

### A8. Remove Skills Sidebar

**File to modify:**
- `/apps/web/src/components/chat/ChatContainer.tsx`

**Changes:**
1. Remove the SkillsPanel import statement
2. Remove the `selectedSkills` useState hook
3. Remove the `<SkillsPanel ... />` JSX at the end of the component
4. Update `sendMessage` call to pass empty array for `attached_skills`

---

## Part B: Phase 8 Core - Write Mode

### B1. Database Models

**File to modify:**
- `/services/brain_runtime/models/db_models.py`

**New models (complete SQLAlchemy definitions):**
```python
class ProposalStatusEnum(str, enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"
    applied = "applied"


class ProposalOperationEnum(str, enum.Enum):
    create = "create"
    modify = "modify"
    delete = "delete"


class ProposalDB(Base):
    """Database model for file change proposals."""
    __tablename__ = "proposals"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = Column(UUID(as_uuid=True), nullable=False)  # FK to chat_sessions
    status = Column(String(20), nullable=False, default="pending")
    description = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    applied_at = Column(DateTime(timezone=True), nullable=True)
    backup_path = Column(String(500), nullable=True)

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "session_id": str(self.session_id),
            "status": self.status,
            "description": self.description,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "applied_at": self.applied_at.isoformat() if self.applied_at else None,
            "backup_path": self.backup_path,
        }


class ProposalFileDB(Base):
    """Database model for individual files in a proposal."""
    __tablename__ = "proposal_files"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    proposal_id = Column(UUID(as_uuid=True), nullable=False)  # FK to proposals
    file_path = Column(String(1000), nullable=False)
    operation = Column(String(20), nullable=False)  # create, modify, delete
    original_content = Column(Text, nullable=True)
    proposed_content = Column(Text, nullable=True)
    diff_hunks = Column(JSON, nullable=True)

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "proposal_id": str(self.proposal_id),
            "file_path": self.file_path,
            "operation": self.operation,
            "original_content": self.original_content,
            "proposed_content": self.proposed_content,
            "diff_hunks": self.diff_hunks,
        }


class UserSettingsDB(Base):
    """Single-row table for user settings."""
    __tablename__ = "user_settings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    yolo_mode = Column(Boolean, default=False)
    default_model = Column(String(100), default='claude-sonnet-4-5-20250929')
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "yolo_mode": self.yolo_mode,
            "default_model": self.default_model,
        }
```

**Database migration workflow:**
```bash
# Step 1: Add models to db_models.py (as shown above)

# Step 2: Add title column to chat_sessions
psql -d second_brain -c "ALTER TABLE chat_sessions ADD COLUMN title VARCHAR(100);"

# Step 3: Create proposals table
psql -d second_brain -c "
CREATE TABLE proposals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    description TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    applied_at TIMESTAMPTZ,
    backup_path VARCHAR(500)
);"

# Step 4: Create proposal_files table
psql -d second_brain -c "
CREATE TABLE proposal_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proposal_id UUID NOT NULL REFERENCES proposals(id) ON DELETE CASCADE,
    file_path VARCHAR(1000) NOT NULL,
    operation VARCHAR(20) NOT NULL,
    original_content TEXT,
    proposed_content TEXT,
    diff_hunks JSONB
);"

# Step 5: Create user_settings table
psql -d second_brain -c "
CREATE TABLE user_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    yolo_mode BOOLEAN DEFAULT FALSE,
    default_model VARCHAR(100) DEFAULT 'claude-sonnet-4-5-20250929',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);"

# Step 6: Verify tables
psql -d second_brain -c "\dt"
```

**Settings access pattern (single-row):**
```python
async def get_or_create_settings(db: AsyncSession) -> UserSettingsDB:
    """Get or create the singleton settings row."""
    result = await db.execute(select(UserSettingsDB).limit(1))
    settings = result.scalar_one_or_none()
    if not settings:
        settings = UserSettingsDB()
        db.add(settings)
        await db.commit()
        await db.refresh(settings)
    return settings
```

### B2. Proposal Service

**New file:**
- `/services/brain_runtime/core/proposal_service.py`

**Functions:**
```python
class ProposalService:
    """Service for managing file change proposals."""

    async def create_proposal(self, session_id: str, description: str) -> ProposalDB:
        """Create new proposal in pending state."""

    async def add_file_change(
        self,
        proposal_id: str,
        file_path: str,
        operation: Literal["create", "modify", "delete"],
        new_content: Optional[str] = None,
    ) -> ProposalFileDB:
        """Add a file change to an existing proposal."""

    def generate_diff(self, original: str, proposed: str) -> List[dict]:
        """Generate unified diff hunks using difflib."""

    async def approve_proposal(self, proposal_id: str) -> ProposalDB:
        """Mark proposal as approved (does not apply yet)."""

    async def apply_proposal(self, proposal_id: str) -> ProposalDB:
        """Apply approved proposal changes with backup."""

    async def reject_proposal(self, proposal_id: str) -> ProposalDB:
        """Mark proposal as rejected."""

    async def create_backup(self, file_paths: List[str]) -> str:
        """Copy originals to data/backups/{timestamp}/, return backup path."""

    async def cleanup_old_backups(self, max_age_days: int = 30) -> int:
        """Remove backups older than max_age_days, return count deleted."""
```

**Path validation (CRITICAL - vault files only):**
```python
def validate_vault_path(file_path: str) -> Path:
    """
    Validate that file_path is within the vault.
    Raises ProposalError if path escapes vault.
    """
    vault_path = Path(settings.obsidian_location) / "Obsidian-Private"
    full_path = vault_path / file_path

    # Security: ensure path is within vault
    try:
        full_path.resolve().relative_to(vault_path.resolve())
    except ValueError:
        raise ProposalError(f"Path outside vault: {file_path}")

    return full_path
```

**Backup management:**
- Location: `data/backups/{timestamp}/` where timestamp is `YYYYMMDD_HHMMSS`
- Retention: 30 days (configurable via `BACKUP_RETENTION_DAYS` env var)
- Cleanup: Call `cleanup_old_backups()` before creating new backup
- Structure: Preserves relative paths from vault root
```
data/backups/
  20251221_143022/
    Notes/Daily/2025-12-21.md
    Projects/second-brain/README.md
  20251220_091544/
    ...
```

**Error handling:**
```python
class ProposalError(Exception):
    """Base exception for proposal errors."""
    pass

class FileNotFoundError(ProposalError):
    """File does not exist in vault (for modify/delete)."""
    pass

class FileExistsError(ProposalError):
    """File already exists (for create)."""
    pass

class ApplyError(ProposalError):
    """Failed to apply changes (permissions, disk space, etc.)."""
    pass

class BackupError(ProposalError):
    """Failed to create backup."""
    pass
```

### B3. Proposal API

**New file:**
- `/services/brain_runtime/api/proposals.py`

**Endpoints:**
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/proposals` | GET | List proposals (optional: ?status=pending) |
| `/proposals/{id}` | GET | Get proposal with files and diffs |
| `/proposals` | POST | Create proposal (from tool) |
| `/proposals/{id}/approve` | POST | Approve and trigger apply |
| `/proposals/{id}/reject` | POST | Reject proposal |

### B4. Proposal Tools (for LLM)

**New file:**
- `/services/brain_runtime/core/tools/proposal_tools.py`

#### B4.1 Tool Definitions with JSON Schemas

```python
from core.tools.registry import tool

@tool(
    name="propose_file_change",
    description="Propose changes to an existing file in the vault. The user will see a diff and can approve or reject.",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Vault-relative path to the file (e.g., 'Notes/Daily/2025-12-21.md')"
            },
            "new_content": {
                "type": "string",
                "description": "Complete new content for the file. Must include the entire file, not just changes."
            },
            "description": {
                "type": "string",
                "description": "Human-readable description of what changes are being made and why."
            }
        },
        "required": ["file_path", "new_content", "description"]
    }
)
async def propose_file_change(file_path: str, new_content: str, description: str) -> dict:
    """Create a proposal to modify an existing file."""
    # Implementation uses ProposalService
    pass


@tool(
    name="propose_new_file",
    description="Propose creating a new file in the vault. The user will see the content and can approve or reject.",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Vault-relative path for the new file (e.g., 'Notes/Ideas/new-idea.md')"
            },
            "content": {
                "type": "string",
                "description": "Content for the new file."
            },
            "description": {
                "type": "string",
                "description": "Human-readable description of what this file is for."
            }
        },
        "required": ["file_path", "content", "description"]
    }
)
async def propose_new_file(file_path: str, content: str, description: str) -> dict:
    """Create a proposal to add a new file."""
    pass


@tool(
    name="propose_delete_file",
    description="Propose deleting a file from the vault. The user must approve this action.",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Vault-relative path to the file to delete."
            },
            "description": {
                "type": "string",
                "description": "Human-readable explanation of why this file should be deleted."
            }
        },
        "required": ["file_path", "description"]
    }
)
async def propose_delete_file(file_path: str, description: str) -> dict:
    """Create a proposal to delete a file."""
    pass


def register_proposal_tools():
    """Register all proposal tools. Called from register_all_tools()."""
    # Tools are registered via @tool decorator when module is imported
    pass
```

**Tool return values:**
```python
# propose_file_change returns:
{
    "proposal_id": "uuid",
    "status": "pending" | "applied",  # "applied" if YOLO mode
    "auto_applied": bool,
    "diff_preview": "first 500 chars of unified diff",
    "lines_added": int,
    "lines_removed": int,
}

# propose_new_file returns:
{
    "proposal_id": "uuid",
    "status": "pending" | "applied",
    "auto_applied": bool,
    "file_path": str,
    "content_length": int,
}

# propose_delete_file returns:
{
    "proposal_id": "uuid",
    "status": "pending",  # Never auto-applied, even in YOLO mode
    "requires_approval": True,
    "file_path": str,
}
```

#### B4.2 BASE_SYSTEM_PROMPT Update

**File to modify:** `/services/brain_runtime/api/chat.py`

Add to `BASE_SYSTEM_PROMPT` after the Skills Tools section:

```python
## Proposal Tools (Write Mode)
When the user asks you to create, modify, or delete files in their vault:
- **propose_file_change(file_path, new_content, description)**: Modify an existing file
- **propose_new_file(file_path, content, description)**: Create a new file
- **propose_delete_file(file_path, description)**: Delete a file

IMPORTANT:
1. Use proposals instead of describing changes. The user can review diffs and approve.
2. For modifications, provide the COMPLETE new file content, not just the changes.
3. Always include a clear description explaining what you're changing and why.
4. File paths are relative to the vault root (e.g., "Notes/Daily/2025-12-21.md").
5. Delete proposals always require manual approval, even in YOLO mode.
```

#### B4.3 SSE Event Types for Proposals

**Backend - Add to `/services/brain_runtime/models/chat.py`:**
```python
class ProposalFileInfo(BaseModel):
    """Info about a single file in a proposal."""
    path: str
    operation: Literal["create", "modify", "delete"]
    diff_preview: Optional[str] = None
    lines_added: int = 0
    lines_removed: int = 0


class ProposalEventData(BaseModel):
    """Data for proposal SSE event."""
    proposal_id: str
    description: str
    files: List[ProposalFileInfo]
    status: Literal["pending", "approved", "rejected", "applied"]
    auto_applied: bool = False
    requires_approval: bool = True
```

**Frontend - Add to `/apps/web/src/lib/chat-api.ts`:**
```typescript
export interface ProposalFile {
  path: string
  operation: 'create' | 'modify' | 'delete'
  diff_preview?: string
  lines_added: number
  lines_removed: number
}

export interface ChatProposalEvent {
  type: 'proposal'
  proposal: {
    id: string
    description: string
    files: ProposalFile[]
    status: 'pending' | 'approved' | 'rejected' | 'applied'
    auto_applied: boolean
    requires_approval: boolean
  }
}

// Update ChatEvent union:
export type ChatEvent =
  | ChatTextEvent
  | ChatToolCallEvent
  | ChatToolResultEvent
  | ChatFileRefEvent
  | ChatArtifactEvent
  | ChatStatusEvent
  | ChatErrorEvent
  | ChatSubagentEvent
  | ChatProposalEvent  // Add this
```

**Add handler in `streamChatResponse()`:**
```typescript
case 'proposal':
  onProposal?.(parsed.data)
  break
```

#### B4.4 Tool Registration Flow

**Files to modify:**
1. `/services/brain_runtime/core/tools/__init__.py`
2. `/services/brain_runtime/core/tools/proposal_tools.py` (new)

**Step 1: Create proposal_tools.py** (as shown in B4.1)

**Step 2: Update `core/tools/__init__.py`:**
```python
from .proposal_tools import register_proposal_tools

__all__ = [
    # ... existing exports
    "register_proposal_tools",
]

def register_all_tools() -> int:
    register_calendar_tools()
    register_tasks_tools()
    register_vault_tools()
    register_skills_tools()
    register_proposal_tools()  # Add this

    registry = ToolRegistry.get_instance()
    return len(registry.get_all_tools())
```

**Step 3: Restart server** to load new tools

### B5. Settings API

**New file:**
- `/services/brain_runtime/api/settings.py`

**Endpoints:**
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/settings` | GET | Get user settings |
| `/settings` | PATCH | Update settings (yolo_mode, etc.) |

### B6. Frontend - Proposal Components

**New files:**
- `/apps/web/src/components/proposal/ProposalCard.tsx` - Inline card in chat
- `/apps/web/src/components/proposal/DiffViewer.tsx` - Diff modal (use react-diff-viewer)
- `/apps/web/src/components/proposal/ProposalApproval.tsx` - Approve/reject buttons
- `/apps/web/src/hooks/useProposals.ts` - React Query hooks
- `/apps/web/src/lib/proposal-api.ts` - API functions

**ProposalCard structure:**
```tsx
<div className="border rounded-lg p-4 bg-amber-50">
  <div className="flex items-center gap-2">
    <FileIcon />
    <span>{file_path}</span>
    <Badge>{operation}</Badge>
  </div>
  <p className="text-sm text-gray-600">{description}</p>
  <div className="flex gap-2 mt-2">
    <Button onClick={viewDiff}>View Diff</Button>
    <Button onClick={approve} variant="primary">Approve</Button>
    <Button onClick={reject} variant="ghost">Reject</Button>
  </div>
</div>
```

**DiffViewer:**
- Install: `pnpm add react-diff-viewer-continued`
- Show side-by-side or unified diff
- Syntax highlighting for markdown

### B7. YOLO Mode Integration

**IMPORTANT:** YOLO mode auto-applies **creates and modifies only**. Deletes ALWAYS require manual approval.

**Files to modify:**
- `/services/brain_runtime/api/proposals.py` - Check YOLO before requiring approval
- `/services/brain_runtime/core/proposal_service.py` - Auto-apply if YOLO (except deletes)
- `/services/brain_runtime/core/tools/proposal_tools.py` - Handle YOLO in tool execution

**Backend Logic:**
```python
async def handle_proposal_creation(
    proposal_id: str,
    operation: str,
    db: AsyncSession,
) -> dict:
    """Handle proposal creation with YOLO mode logic."""
    settings = await get_or_create_settings(db)

    # SAFETY: Delete proposals NEVER auto-apply
    if operation == "delete":
        return {
            "proposal_id": proposal_id,
            "status": "pending",
            "auto_applied": False,
            "requires_approval": True,
            "message": "Delete proposals require manual approval",
        }

    # YOLO mode: auto-apply creates and modifies
    if settings.yolo_mode:
        await apply_proposal(proposal_id, db)
        return {
            "proposal_id": proposal_id,
            "status": "applied",
            "auto_applied": True,
            "requires_approval": False,
        }

    # Normal mode: require approval
    return {
        "proposal_id": proposal_id,
        "status": "pending",
        "auto_applied": False,
        "requires_approval": True,
    }
```

**SSE Event Flow:**
```
YOLO OFF (all operations):
  Tool returns → Emit proposal event (status="pending") → Frontend shows ProposalCard

YOLO ON + create/modify:
  Tool returns → Apply immediately → Emit proposal event (status="applied", auto_applied=true)
  → Frontend shows "✓ Applied automatically" banner

YOLO ON + delete:
  Tool returns → Emit proposal event (status="pending", requires_approval=true)
  → Frontend shows ProposalCard with "Delete requires approval" message
```

**Frontend handling:**
```typescript
// In ProposalCard component
function ProposalCard({ proposal }: { proposal: Proposal }) {
  if (proposal.auto_applied) {
    return (
      <div className="bg-green-50 border-green-200 ...">
        <CheckIcon /> Applied automatically
        <span>{proposal.description}</span>
      </div>
    )
  }

  // Show full approval UI for pending proposals
  return (
    <div className="bg-amber-50 border-amber-200 ...">
      {proposal.files.some(f => f.operation === 'delete') && (
        <Badge variant="destructive">Delete requires approval</Badge>
      )}
      {/* ... diff viewer, approve/reject buttons */}
    </div>
  )
}
```

**Settings state management:**
```typescript
// SettingsContext.tsx
const SettingsContext = createContext<{
  yoloMode: boolean
  setYoloMode: (value: boolean) => void
}>()

// In SettingsMenu.tsx
function YoloToggle() {
  const { yoloMode, setYoloMode } = useSettings()

  const handleToggle = async (checked: boolean) => {
    // Optimistic update
    setYoloMode(checked)
    try {
      await api.patch('/settings', { yolo_mode: checked })
    } catch (error) {
      // Revert on failure
      setYoloMode(!checked)
      toast.error('Failed to update settings')
    }
  }

  return (
    <div className="flex items-center gap-2">
      <Toggle checked={yoloMode} onChange={handleToggle} />
      <span>YOLO Mode</span>
      <Tooltip>Auto-approve creates and modifies. Deletes always require approval.</Tooltip>
    </div>
  )
}
```

---

## Part C: Creating-Skills Skill

**New file:**
- `/Users/tijlkoenderink/.claude/skills/creating-skills/SKILL.md`

**Content outline:**
```yaml
---
name: Creating Skills
description: Create new Claude Code skills with proper structure, placement, and best practices
when_to_use: when user wants to create a new skill or asks how to make skills
version: 1.0.0
---
```

**Sections:**
1. **Overview** - What skills are, why structure matters
2. **The Iron Law** - `NO SKILL CREATION WITHOUT FOLLOWING TEMPLATE`
3. **When to Use** - Creating new skill, documenting workflow
4. **Skill Creation Workflow**
   - Phase 1: Research existing skills for patterns
   - Phase 2: Choose appropriate name (kebab-case)
   - Phase 3: Create directory structure
   - Phase 4: Write SKILL.md with YAML frontmatter
   - Phase 5: Include all sections (Overview, When to Use, Workflow, Common Mistakes, Quick Reference)
   - Phase 6: Test skill discovery
5. **File Structure Template**
6. **Best Practices** (derived from 38 existing skills)
7. **Common Mistakes**

---

## Implementation Order

### Step 1: Database Migration (10 min)
- Add `title` column to `chat_sessions`
- Create `proposals`, `proposal_files`, `user_settings` tables

### Step 2: Route Restructuring (20 min)
- A1: Move dashboard, make chat homepage
- Remove Navigation component

### Step 3: Mode and Model Changes (15 min)
- A2: Remove quick mode
- A3: Default to Sonnet 4.5

### Step 4: Auto-Focus (15 min)
- A4: MessageInput focus management

### Step 5: Settings Menu (30 min)
- A6: Create SettingsMenu component
- Add to SessionSidebar bottom

### Step 6: Health Chip (20 min)
- A7: Create HealthChip
- Position in chat layout

### Step 7: Remove Skills Sidebar (10 min)
- A8: Remove SkillsPanel from ChatContainer

### Step 8: Title Generation (1 hour)
- A5: Backend endpoint
- Frontend hook + display

### Step 9: Proposal Service (2 hours)
- B2: Core proposal logic
- B1: Database models

### Step 10: Proposal API (1 hour)
- B3: CRUD endpoints

### Step 11: Proposal Tools (1 hour)
- B4: LLM tools for file changes

### Step 12: Settings API (30 min)
- B5: Settings endpoints

### Step 13: Frontend Proposals (2 hours)
- B6: ProposalCard, DiffViewer, hooks

### Step 14: YOLO Mode (30 min)
- B7: Auto-apply integration

### Step 15: Creating-Skills Skill (1 hour)
- C: Write comprehensive skill

---

## Critical Files Summary

**Frontend (modify):**
- `apps/web/src/app/page.tsx`
- `apps/web/src/app/layout.tsx`
- `apps/web/src/components/chat/ChatContainer.tsx`
- `apps/web/src/components/chat/ModeSelector.tsx`
- `apps/web/src/components/chat/MessageInput.tsx`
- `apps/web/src/components/chat/SessionSidebar.tsx`
- `apps/web/src/hooks/useChat.ts`
- `apps/web/src/lib/chat-api.ts`

**Frontend (new):**
- `apps/web/src/app/dashboard/page.tsx`
- `apps/web/src/components/chat/SettingsMenu.tsx`
- `apps/web/src/components/chat/HealthChip.tsx`
- `apps/web/src/components/proposal/ProposalCard.tsx`
- `apps/web/src/components/proposal/DiffViewer.tsx`
- `apps/web/src/components/proposal/ProposalApproval.tsx`
- `apps/web/src/hooks/useProposals.ts`
- `apps/web/src/lib/proposal-api.ts`

**Frontend (delete):**
- `apps/web/src/components/Navigation.tsx`

**Backend (modify):**
- `services/brain_runtime/api/chat.py`
- `services/brain_runtime/models/db_models.py`
- `services/brain_runtime/core/tools/registry.py`
- `services/brain_runtime/main.py` (add routers)

**Backend (new):**
- `services/brain_runtime/api/proposals.py`
- `services/brain_runtime/api/settings.py`
- `services/brain_runtime/core/proposal_service.py`
- `services/brain_runtime/core/tools/proposal_tools.py`
- `services/brain_runtime/models/proposal.py`

**Skill (new):**
- `~/.claude/skills/creating-skills/SKILL.md`

---

## Testing Checklist

### UI/UX (Part A)
- [ ] Navigate to `/` shows chat (not dashboard)
- [ ] Navigate to `/dashboard` shows dashboard
- [ ] Only Tools and Agent modes available (no Quick)
- [ ] Default model is Sonnet 4.5 (`claude-sonnet-4-5-20250929`)
- [ ] Input auto-focuses on page load
- [ ] Input auto-focuses after "New Chat" click
- [ ] Title generated after first assistant response
- [ ] Title shows in header and sidebar (not truncated message)
- [ ] Settings menu opens from sidebar bottom (gear icon)
- [ ] Settings links navigate to Dashboard and Skills
- [ ] Health chip visible top-left, correct color states
- [ ] Skills sidebar removed from chat interface

### Write Mode (Part B)
- [ ] `propose_file_change` tool creates pending proposal
- [ ] `propose_new_file` tool creates pending proposal
- [ ] `propose_delete_file` tool creates pending proposal (never auto-applies)
- [ ] ProposalCard renders inline in chat
- [ ] "View Diff" button opens DiffViewer modal
- [ ] DiffViewer shows side-by-side diff with syntax highlighting
- [ ] "Approve" button applies changes and shows success
- [ ] "Reject" button marks proposal rejected
- [ ] Backups created in `data/backups/{timestamp}/`
- [ ] Old backups (>30 days) cleaned up

### YOLO Mode
- [ ] YOLO toggle works in Settings menu
- [ ] YOLO ON: Create proposals auto-apply (shows green "Applied" banner)
- [ ] YOLO ON: Modify proposals auto-apply (shows green "Applied" banner)
- [ ] YOLO ON: Delete proposals still require approval (shows amber ProposalCard)
- [ ] YOLO OFF: All proposals require approval

### Error Cases
- [ ] Proposal for file outside vault rejected with error
- [ ] `propose_file_change` on non-existent file shows error
- [ ] `propose_new_file` on existing file shows error
- [ ] Apply failure (e.g., permissions) shows error, doesn't corrupt file

### Integration
- [ ] Creating-skills skill discoverable in skill list
- [ ] LLM correctly uses proposal tools when asked to modify files
- [ ] LLM describes what proposal contains (not just "I created a proposal")

---

## Success Criteria

Phase 8 is complete when:

1. **Chat is Homepage**: Root route `/` shows chat interface
2. **Simplified Modes**: Only Tools and Agent modes, no Quick Chat
3. **Sonnet 4.5 Default**: New chats use `claude-sonnet-4-5-20250929`
4. **Auto-Focus**: Input box focused on page load and new chat
5. **Title Generation**: 3-4 word titles via Haiku 4.5 after first exchange
6. **Settings Menu**: Accessible from sidebar with Dashboard/Skills links + YOLO toggle
7. **Health Chip**: Floating indicator top-left with green/yellow/red states
8. **No Skills Sidebar**: Removed from chat interface
9. **Write Mode**: Proposals can be created, viewed with diff, approved, applied with backup
10. **YOLO Mode**: Auto-apply creates/modifies only; deletes ALWAYS require approval
11. **Backup Retention**: Automatic cleanup of backups older than 30 days
12. **Creating-Skills Skill**: Available in `~/.claude/skills/`
13. **LLM Integration**: LLM knows about proposal tools and uses them appropriately
