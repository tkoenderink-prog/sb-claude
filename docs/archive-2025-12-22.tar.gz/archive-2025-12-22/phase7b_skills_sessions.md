# Phase 7B: Automatic Skill Discovery & Session Management

**Status:** COMPLETE
**Created:** 2025-12-21
**Completed:** 2025-12-21
**Depends on:** Phase 7A (Complete)
**Complexity:** Medium-High

---

## Executive Summary

Phase 7B transforms skills from a manual "checkbox" approach to **automatic progressive self-disclosure**, adds a **Claude-like session sidebar**, and provides **skills CRUD with categorization**.

| Feature | Current State | Phase 7B Target |
|---------|---------------|-----------------|
| Skill Selection | Manual checkboxes | Automatic context-aware injection |
| Skill Loading | All content upfront (~5K+ tokens) | Progressive: metadata → instructions → resources |
| Session History | Single session in localStorage | Left sidebar with session list |
| Skill Management | Read-only via API | Full CRUD with categories |
| Skill Organization | Flat list by source | Categorized, searchable, filterable |

---

## Architecture Overview

### Progressive Skill Disclosure (Three Levels)

```
Level 1: Metadata (Always loaded - ~100 tokens total)
├── skill_id, name, description, when_to_use, category, tags

Level 2: Instructions (Loaded when triggered - <5K tokens each)
├── Full SKILL.md content
├── Injected into system prompt when skill matches conversation

Level 3: Resources (Loaded as needed - 0 tokens until accessed)
├── FORMS.md, REFERENCE.md, scripts/
├── Accessed via filesystem tools, never preloaded
```

### Automatic Skill Matching Algorithm

```python
# Conversation context analyzed against skill triggers
conversation_text = extract_recent_context(messages, window=3)

for skill in skill_metadata:
    score = calculate_relevance(
        text=conversation_text,
        when_to_use=skill.when_to_use,
        tags=skill.tags,
        category=skill.category
    )
    if score > THRESHOLD:
        inject_skill(skill)
```

---

## Part 1: Skill Categorization System

### 1.1 Updated Skill Model

**Modify:** `services/skills/models.py`

```python
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field
from datetime import datetime


class SkillCategory(str, Enum):
    """Skill categories for organization and filtering."""
    KNOWLEDGE = "knowledge"        # Mental models, frameworks, references
    WORKFLOW = "workflow"          # Process automation, checklists
    ANALYSIS = "analysis"          # Data analysis, pattern recognition
    CREATION = "creation"          # Content creation, writing
    INTEGRATION = "integration"    # External systems, APIs
    TRAINING = "training"          # Physical training, health
    PRODUCTIVITY = "productivity"  # Task management, time management
    UNCATEGORIZED = "uncategorized"


class SkillMetadata(BaseModel):
    """Level 1: Lightweight metadata for all skills."""
    id: str
    name: str
    description: str
    when_to_use: str
    category: SkillCategory = SkillCategory.UNCATEGORIZED
    tags: list[str] = Field(default_factory=list)
    version: Optional[str] = None
    source: str  # "user", "vault", "system"
    has_checklist: bool = False
    last_modified: Optional[datetime] = None

    # Computed relevance for automatic matching
    trigger_keywords: list[str] = Field(default_factory=list)


class SkillInfo(SkillMetadata):
    """Level 2: Full skill with content (loaded on demand)."""
    path: str
    content: str  # Full SKILL.md content


class SkillCreate(BaseModel):
    """Schema for creating a new skill."""
    name: str
    description: str
    when_to_use: str
    category: SkillCategory = SkillCategory.UNCATEGORIZED
    tags: list[str] = Field(default_factory=list)
    content: str


class SkillUpdate(BaseModel):
    """Schema for updating an existing skill."""
    name: Optional[str] = None
    description: Optional[str] = None
    when_to_use: Optional[str] = None
    category: Optional[SkillCategory] = None
    tags: Optional[list[str]] = None
    content: Optional[str] = None
```

### 1.2 Skill Category Extraction

**Modify:** `services/skills/scanner.py`

```python
import re
from .models import SkillCategory, SkillMetadata


def extract_category_from_content(content: str, tags: list[str]) -> SkillCategory:
    """Infer category from skill content and tags."""
    content_lower = content.lower()
    tags_lower = [t.lower() for t in tags]

    # Category detection rules
    CATEGORY_PATTERNS = {
        SkillCategory.KNOWLEDGE: [
            r"mental model", r"framework", r"concept", r"theory",
            r"understanding", r"principle"
        ],
        SkillCategory.WORKFLOW: [
            r"checklist", r"step-by-step", r"workflow", r"process",
            r"procedure", r"automation"
        ],
        SkillCategory.ANALYSIS: [
            r"analyze", r"pattern", r"data", r"research",
            r"investigate", r"diagnose"
        ],
        SkillCategory.CREATION: [
            r"create", r"write", r"generate", r"compose",
            r"design", r"build"
        ],
        SkillCategory.INTEGRATION: [
            r"api", r"integration", r"sync", r"connect",
            r"external", r"service"
        ],
        SkillCategory.TRAINING: [
            r"training", r"exercise", r"workout", r"mobility",
            r"strength", r"physical"
        ],
        SkillCategory.PRODUCTIVITY: [
            r"task", r"priority", r"time", r"schedule",
            r"planning", r"organize"
        ],
    }

    # Check content and tags
    scores = {cat: 0 for cat in SkillCategory}

    for category, patterns in CATEGORY_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, content_lower):
                scores[category] += 1
            if any(pattern in tag for tag in tags_lower):
                scores[category] += 2  # Tags are more indicative

    # Return highest scoring category
    best = max(scores.items(), key=lambda x: x[1])
    if best[1] > 0:
        return best[0]
    return SkillCategory.UNCATEGORIZED


def extract_trigger_keywords(when_to_use: str, description: str) -> list[str]:
    """Extract keywords that trigger this skill."""
    text = f"{when_to_use} {description}".lower()

    # Remove common stop words
    STOP_WORDS = {"when", "the", "a", "an", "is", "are", "to", "for", "of", "and", "or", "in"}

    # Extract significant words (4+ chars, not stop words)
    words = re.findall(r'\b[a-z]{4,}\b', text)
    keywords = [w for w in words if w not in STOP_WORDS]

    # Deduplicate while preserving order
    seen = set()
    unique = []
    for kw in keywords:
        if kw not in seen:
            seen.add(kw)
            unique.append(kw)

    return unique[:20]  # Limit to top 20 keywords
```

### 1.3 Database Schema for User Skills

**New file:** `services/brain_runtime/migrations/002_add_skills_tables.sql`

```sql
-- User-created skills (stored in database, not filesystem)
CREATE TABLE IF NOT EXISTS user_skills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    when_to_use TEXT NOT NULL,
    category VARCHAR(50) NOT NULL DEFAULT 'uncategorized',
    tags JSONB DEFAULT '[]',
    content TEXT NOT NULL,
    version VARCHAR(20),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ  -- Soft delete
);

-- Skill usage tracking for relevance scoring
CREATE TABLE IF NOT EXISTS skill_usage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    skill_id VARCHAR(255) NOT NULL,  -- Can be filesystem or DB skill
    skill_source VARCHAR(20) NOT NULL,  -- "user", "vault", "database"
    session_id UUID REFERENCES chat_sessions(id) ON DELETE SET NULL,
    matched_by VARCHAR(20) NOT NULL,  -- "automatic", "manual"
    relevance_score FLOAT,
    used_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_user_skills_category ON user_skills(category);
CREATE INDEX idx_user_skills_deleted ON user_skills(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX idx_skill_usage_skill ON skill_usage(skill_id);
CREATE INDEX idx_skill_usage_session ON skill_usage(session_id);
```

### 1.4 Skills CRUD API

**Modify:** `services/brain_runtime/api/skills.py`

```python
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
from typing import Optional
from uuid import UUID, uuid4
from datetime import datetime, timezone

from core.database import get_db
from models.db_models import UserSkillDB
from services.skills.models import (
    SkillMetadata, SkillInfo, SkillCreate, SkillUpdate, SkillCategory
)
from services.skills.scanner import SkillScanner

router = APIRouter(prefix="/skills", tags=["skills"])


# --- Read Operations (existing + enhanced) ---

@router.get("", response_model=list[SkillMetadata])
async def list_skills(
    source: Optional[str] = Query(None, description="Filter by source: user, vault, database"),
    category: Optional[SkillCategory] = Query(None, description="Filter by category"),
    search: Optional[str] = Query(None, description="Search in name/description"),
    db: AsyncSession = Depends(get_db),
):
    """List all skills with optional filtering."""
    skills = []

    # 1. Filesystem skills (user + vault)
    if source is None or source in ("user", "vault"):
        scanner = SkillScanner()
        fs_skills = scanner.scan_all()

        for skill in fs_skills:
            if source and skill.source != source:
                continue
            if category and skill.category != category:
                continue
            if search and search.lower() not in f"{skill.name} {skill.description}".lower():
                continue
            skills.append(skill)

    # 2. Database skills
    if source is None or source == "database":
        query = select(UserSkillDB).where(UserSkillDB.deleted_at.is_(None))

        if category:
            query = query.where(UserSkillDB.category == category.value)

        result = await db.execute(query)
        db_skills = result.scalars().all()

        for db_skill in db_skills:
            if search and search.lower() not in f"{db_skill.name} {db_skill.description}".lower():
                continue
            skills.append(SkillMetadata(
                id=f"db_{db_skill.id}",
                name=db_skill.name,
                description=db_skill.description,
                when_to_use=db_skill.when_to_use,
                category=SkillCategory(db_skill.category),
                tags=db_skill.tags or [],
                version=db_skill.version,
                source="database",
                has_checklist="[ ]" in db_skill.content,
                last_modified=db_skill.updated_at,
            ))

    return skills


@router.get("/categories", response_model=dict)
async def get_categories_with_counts(
    db: AsyncSession = Depends(get_db),
):
    """Get all categories with skill counts."""
    scanner = SkillScanner()
    fs_skills = scanner.scan_all()

    counts = {cat.value: 0 for cat in SkillCategory}

    # Count filesystem skills
    for skill in fs_skills:
        counts[skill.category.value] += 1

    # Count database skills
    result = await db.execute(
        select(UserSkillDB.category, func.count(UserSkillDB.id))
        .where(UserSkillDB.deleted_at.is_(None))
        .group_by(UserSkillDB.category)
    )
    for category, count in result.all():
        counts[category] = counts.get(category, 0) + count

    return counts


@router.get("/{skill_id}", response_model=SkillInfo)
async def get_skill(
    skill_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Get full skill details including content."""
    # Check if database skill
    if skill_id.startswith("db_"):
        db_id = skill_id[3:]
        result = await db.execute(
            select(UserSkillDB)
            .where(UserSkillDB.id == UUID(db_id))
            .where(UserSkillDB.deleted_at.is_(None))
        )
        db_skill = result.scalar_one_or_none()

        if not db_skill:
            raise HTTPException(status_code=404, detail="Skill not found")

        return SkillInfo(
            id=skill_id,
            name=db_skill.name,
            description=db_skill.description,
            when_to_use=db_skill.when_to_use,
            category=SkillCategory(db_skill.category),
            tags=db_skill.tags or [],
            version=db_skill.version,
            source="database",
            has_checklist="[ ]" in db_skill.content,
            last_modified=db_skill.updated_at,
            path="",  # Database skills have no path
            content=db_skill.content,
        )

    # Filesystem skill
    scanner = SkillScanner()
    skill = scanner.get_skill(skill_id)

    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")

    return skill


# --- Create/Update/Delete Operations (NEW) ---

@router.post("", response_model=SkillInfo, status_code=201)
async def create_skill(
    skill: SkillCreate,
    db: AsyncSession = Depends(get_db),
):
    """Create a new user skill (stored in database)."""
    db_skill = UserSkillDB(
        id=uuid4(),
        name=skill.name,
        description=skill.description,
        when_to_use=skill.when_to_use,
        category=skill.category.value,
        tags=skill.tags,
        content=skill.content,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    db.add(db_skill)
    await db.commit()
    await db.refresh(db_skill)

    return SkillInfo(
        id=f"db_{db_skill.id}",
        name=db_skill.name,
        description=db_skill.description,
        when_to_use=db_skill.when_to_use,
        category=skill.category,
        tags=db_skill.tags,
        source="database",
        has_checklist="[ ]" in db_skill.content,
        last_modified=db_skill.updated_at,
        path="",
        content=db_skill.content,
    )


@router.patch("/{skill_id}", response_model=SkillInfo)
async def update_skill(
    skill_id: str,
    updates: SkillUpdate,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing skill (database skills only)."""
    if not skill_id.startswith("db_"):
        raise HTTPException(
            status_code=400,
            detail="Only database skills can be updated via API. Filesystem skills must be edited directly."
        )

    db_id = skill_id[3:]
    result = await db.execute(
        select(UserSkillDB)
        .where(UserSkillDB.id == UUID(db_id))
        .where(UserSkillDB.deleted_at.is_(None))
    )
    db_skill = result.scalar_one_or_none()

    if not db_skill:
        raise HTTPException(status_code=404, detail="Skill not found")

    # Apply updates
    if updates.name is not None:
        db_skill.name = updates.name
    if updates.description is not None:
        db_skill.description = updates.description
    if updates.when_to_use is not None:
        db_skill.when_to_use = updates.when_to_use
    if updates.category is not None:
        db_skill.category = updates.category.value
    if updates.tags is not None:
        db_skill.tags = updates.tags
    if updates.content is not None:
        db_skill.content = updates.content

    db_skill.updated_at = datetime.now(timezone.utc)

    await db.commit()
    await db.refresh(db_skill)

    return SkillInfo(
        id=skill_id,
        name=db_skill.name,
        description=db_skill.description,
        when_to_use=db_skill.when_to_use,
        category=SkillCategory(db_skill.category),
        tags=db_skill.tags,
        source="database",
        has_checklist="[ ]" in db_skill.content,
        last_modified=db_skill.updated_at,
        path="",
        content=db_skill.content,
    )


@router.delete("/{skill_id}", status_code=204)
async def delete_skill(
    skill_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Soft delete a skill (database skills only)."""
    if not skill_id.startswith("db_"):
        raise HTTPException(
            status_code=400,
            detail="Only database skills can be deleted via API. Filesystem skills must be deleted directly."
        )

    db_id = skill_id[3:]
    result = await db.execute(
        update(UserSkillDB)
        .where(UserSkillDB.id == UUID(db_id))
        .where(UserSkillDB.deleted_at.is_(None))
        .values(deleted_at=datetime.now(timezone.utc))
        .returning(UserSkillDB.id)
    )

    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Skill not found")

    await db.commit()
```

---

## Part 2: Automatic Skill Discovery

### 2.1 Skill Matcher Service

**New file:** `services/brain_runtime/core/skills/matcher.py`

```python
"""Automatic skill matching based on conversation context."""

import re
import logging
from typing import Optional
from dataclasses import dataclass

from services.skills.models import SkillMetadata, SkillCategory

logger = logging.getLogger(__name__)


@dataclass
class SkillMatch:
    """A matched skill with relevance score."""
    skill: SkillMetadata
    score: float
    matched_keywords: list[str]
    match_reason: str


class SkillMatcher:
    """Matches skills to conversation context automatically."""

    # Minimum score to trigger skill injection
    THRESHOLD = 0.3

    # Maximum skills to inject per turn
    MAX_SKILLS = 3

    # Category boost weights (some categories more likely needed)
    CATEGORY_WEIGHTS = {
        SkillCategory.WORKFLOW: 1.2,      # Checklists are often needed
        SkillCategory.ANALYSIS: 1.1,      # Analysis skills useful
        SkillCategory.KNOWLEDGE: 1.0,     # Standard weight
        SkillCategory.CREATION: 1.0,
        SkillCategory.INTEGRATION: 0.9,   # Less common
        SkillCategory.TRAINING: 0.8,      # Very specific
        SkillCategory.PRODUCTIVITY: 1.1,
        SkillCategory.UNCATEGORIZED: 0.7,
    }

    def __init__(self, skills_metadata: list[SkillMetadata]):
        self.skills = skills_metadata
        self._build_keyword_index()

    def _build_keyword_index(self):
        """Build inverted index of keywords to skills."""
        self.keyword_index: dict[str, list[SkillMetadata]] = {}

        for skill in self.skills:
            for keyword in skill.trigger_keywords:
                if keyword not in self.keyword_index:
                    self.keyword_index[keyword] = []
                self.keyword_index[keyword].append(skill)

    def match(
        self,
        messages: list[dict],
        context_window: int = 3,
        already_injected: list[str] | None = None,
    ) -> list[SkillMatch]:
        """
        Find skills that match the conversation context.

        Args:
            messages: Conversation history
            context_window: Number of recent messages to analyze
            already_injected: Skill IDs already in this session

        Returns:
            List of matched skills, sorted by relevance
        """
        already_injected = already_injected or []

        # Extract context from recent messages
        recent = messages[-context_window:] if len(messages) > context_window else messages
        context_text = " ".join(
            msg.get("content", "") for msg in recent
            if isinstance(msg.get("content"), str)
        ).lower()

        # Find matching skills
        matches: list[SkillMatch] = []

        for skill in self.skills:
            # Skip already injected skills
            if skill.id in already_injected:
                continue

            score, keywords, reason = self._calculate_score(skill, context_text)

            if score >= self.THRESHOLD:
                matches.append(SkillMatch(
                    skill=skill,
                    score=score,
                    matched_keywords=keywords,
                    match_reason=reason,
                ))

        # Sort by score descending, limit to MAX_SKILLS
        matches.sort(key=lambda m: m.score, reverse=True)
        return matches[:self.MAX_SKILLS]

    def _calculate_score(
        self,
        skill: SkillMetadata,
        context: str,
    ) -> tuple[float, list[str], str]:
        """Calculate relevance score for a skill."""
        score = 0.0
        matched_keywords = []
        reasons = []

        # 1. Keyword matching (primary signal)
        for keyword in skill.trigger_keywords:
            if keyword in context:
                score += 0.15
                matched_keywords.append(keyword)

        if matched_keywords:
            reasons.append(f"keywords: {', '.join(matched_keywords[:3])}")

        # 2. when_to_use pattern matching
        when_patterns = self._extract_patterns(skill.when_to_use)
        for pattern in when_patterns:
            if re.search(pattern, context):
                score += 0.25
                reasons.append(f"trigger: {pattern[:30]}")
                break

        # 3. Category weight adjustment
        category_weight = self.CATEGORY_WEIGHTS.get(skill.category, 1.0)
        score *= category_weight

        # 4. Tag matching boost
        for tag in skill.tags:
            if tag.lower() in context:
                score += 0.1
                reasons.append(f"tag: {tag}")

        # Cap score at 1.0
        score = min(score, 1.0)

        reason = "; ".join(reasons) if reasons else "no specific match"
        return score, matched_keywords, reason

    def _extract_patterns(self, when_to_use: str) -> list[str]:
        """Extract regex patterns from when_to_use text."""
        # Common trigger phrases to look for
        patterns = []

        # "when X" patterns
        when_matches = re.findall(r"when\s+([^,\.]+)", when_to_use.lower())
        for match in when_matches:
            # Convert to loose regex
            pattern = re.escape(match.strip())
            pattern = pattern.replace(r"\ ", r"\s+")
            patterns.append(pattern)

        # "for X" patterns
        for_matches = re.findall(r"for\s+([^,\.]+)", when_to_use.lower())
        for match in for_matches:
            pattern = re.escape(match.strip())
            pattern = pattern.replace(r"\ ", r"\s+")
            patterns.append(pattern)

        return patterns[:5]  # Limit patterns
```

### 2.2 Skill Injection Service

**New file:** `services/brain_runtime/core/skills/injector.py`

```python
"""Progressive skill injection into chat context."""

import logging
from typing import Optional

from services.skills.models import SkillMetadata, SkillInfo
from services.skills.scanner import SkillScanner
from .matcher import SkillMatcher, SkillMatch

logger = logging.getLogger(__name__)


class SkillInjector:
    """
    Handles progressive skill injection into conversations.

    Implements three-level loading:
    - Level 1: Metadata always available for matching
    - Level 2: Instructions loaded when skill triggered
    - Level 3: Resources accessed via tools when needed
    """

    def __init__(self):
        self.scanner = SkillScanner()
        self._metadata_cache: list[SkillMetadata] | None = None
        self._content_cache: dict[str, str] = {}

    @property
    def metadata(self) -> list[SkillMetadata]:
        """Get Level 1: All skill metadata (cached)."""
        if self._metadata_cache is None:
            skills = self.scanner.scan_all()
            self._metadata_cache = [
                SkillMetadata(
                    id=s.id,
                    name=s.name,
                    description=s.description,
                    when_to_use=s.when_to_use,
                    category=s.category,
                    tags=s.tags,
                    version=s.version,
                    source=s.source,
                    has_checklist=s.has_checklist,
                    trigger_keywords=s.trigger_keywords,
                )
                for s in skills
            ]
        return self._metadata_cache

    def get_content(self, skill_id: str) -> Optional[str]:
        """Get Level 2: Skill content (lazy loaded)."""
        if skill_id not in self._content_cache:
            skill = self.scanner.get_skill(skill_id)
            if skill:
                self._content_cache[skill_id] = skill.content
        return self._content_cache.get(skill_id)

    def invalidate_cache(self):
        """Clear caches when skills change."""
        self._metadata_cache = None
        self._content_cache.clear()

    def build_skill_aware_prompt(
        self,
        base_prompt: str,
        messages: list[dict],
        already_injected: list[str] | None = None,
        mode: str = "tools",
    ) -> tuple[str, list[str]]:
        """
        Build system prompt with automatically matched skills.

        Returns:
            tuple of (enhanced_prompt, list of injected skill IDs)
        """
        if mode == "quick":
            # Quick mode: no skills
            return base_prompt, []

        # Match skills to conversation
        matcher = SkillMatcher(self.metadata)
        matches = matcher.match(messages, already_injected=already_injected)

        if not matches:
            return base_prompt, []

        # Build skill context section
        skill_section = self._build_skill_section(matches)

        # Inject into prompt
        enhanced = f"{base_prompt}\n\n{skill_section}"
        injected_ids = [m.skill.id for m in matches]

        logger.info(f"Auto-injected {len(injected_ids)} skills: {injected_ids}")

        return enhanced, injected_ids

    def _build_skill_section(self, matches: list[SkillMatch]) -> str:
        """Build the skills section for the system prompt."""
        lines = [
            "# Automatically Matched Skills",
            "",
            "The following skills have been matched to this conversation. "
            "Use them as appropriate frameworks for your response.",
            "",
        ]

        for match in matches:
            content = self.get_content(match.skill.id)
            if content:
                lines.append(f"## {match.skill.name}")
                lines.append(f"*Matched because: {match.match_reason}*")
                lines.append("")
                lines.append(content)
                lines.append("")

        return "\n".join(lines)

    def get_available_skills_summary(self) -> str:
        """
        Get a brief summary of available skills for the LLM.

        This is included at Level 1 so the LLM knows what's available.
        """
        categories = {}
        for skill in self.metadata:
            cat = skill.category.value
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(f"- {skill.name}: {skill.description[:50]}...")

        lines = ["# Available Skills (request by name if needed)", ""]
        for cat, skills in sorted(categories.items()):
            lines.append(f"## {cat.title()}")
            lines.extend(skills[:5])  # Limit per category
            if len(skills) > 5:
                lines.append(f"- ... and {len(skills) - 5} more")
            lines.append("")

        return "\n".join(lines)
```

### 2.3 Integration with Chat API

**Modify:** `services/brain_runtime/api/chat.py`

```python
from core.skills.injector import SkillInjector

# Global injector instance
_skill_injector: SkillInjector | None = None

def get_skill_injector() -> SkillInjector:
    global _skill_injector
    if _skill_injector is None:
        _skill_injector = SkillInjector()
    return _skill_injector


async def build_system_prompt(
    mode: str,
    messages: list[dict],
    session_injected_skills: list[str],
    manual_skills: list[str] | None = None,
) -> tuple[str, list[str]]:
    """
    Build system prompt with automatic + manual skill injection.

    Returns:
        tuple of (system_prompt, all_injected_skill_ids)
    """
    if mode == "quick":
        return "", []

    # Base prompt with tool descriptions
    base_prompt = build_base_system_prompt(mode)

    injector = get_skill_injector()
    all_injected = list(session_injected_skills)

    # 1. Add manual skills first (user explicitly requested)
    if manual_skills:
        for skill_id in manual_skills:
            if skill_id not in all_injected:
                content = injector.get_content(skill_id)
                if content:
                    base_prompt += f"\n\n## {skill_id}\n{content}"
                    all_injected.append(skill_id)

    # 2. Add automatically matched skills
    enhanced_prompt, auto_injected = injector.build_skill_aware_prompt(
        base_prompt=base_prompt,
        messages=messages,
        already_injected=all_injected,
        mode=mode,
    )

    all_injected.extend(auto_injected)

    # 3. Add skills summary at Level 1 (so LLM knows what's available)
    if mode in ("tools", "agent"):
        skills_summary = injector.get_available_skills_summary()
        enhanced_prompt += f"\n\n{skills_summary}"

    return enhanced_prompt, all_injected


# Update chat endpoint to track injected skills
@router.post("/chat")
async def chat(
    request: ChatRequest,
    db: AsyncSession = Depends(get_db),
):
    session_service = SessionService(db)

    # Load session (includes previously injected skills)
    session_id, is_new = await session_service.get_or_create_session(
        session_id=request.session_id,
        mode=request.mode,
        provider=request.provider,
        model=request.model,
        attached_skills=request.attached_skills,
    )

    # Get already injected skills for this session
    session = await session_service.get_session(session_id)
    session_injected = session.get("injected_skills", []) if session else []

    # Build prompt with automatic skill discovery
    system_prompt, all_injected = await build_system_prompt(
        mode=request.mode,
        messages=request.messages,
        session_injected_skills=session_injected,
        manual_skills=request.attached_skills,
    )

    # Track newly injected skills
    new_skills = [s for s in all_injected if s not in session_injected]
    if new_skills:
        await session_service.update_injected_skills(session_id, all_injected)

    # ... rest of chat logic ...
```

---

## Part 3: Session Sidebar UI

### 3.1 Session List API

**New file:** `services/brain_runtime/api/sessions.py`

```python
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc
from typing import Optional
from datetime import datetime, timedelta, timezone

from core.database import get_db
from models.db_models import ChatSessionDB, ChatMessageDB

router = APIRouter(prefix="/sessions", tags=["sessions"])


@router.get("")
async def list_sessions(
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    search: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    """List chat sessions with preview."""

    # Base query
    query = (
        select(ChatSessionDB)
        .order_by(desc(ChatSessionDB.updated_at))
        .offset(offset)
        .limit(limit)
    )

    result = await db.execute(query)
    sessions = result.scalars().all()

    # Build response with previews
    session_list = []
    for session in sessions:
        # Get first user message as preview
        preview_result = await db.execute(
            select(ChatMessageDB.content)
            .where(ChatMessageDB.session_id == session.id)
            .where(ChatMessageDB.role == "user")
            .order_by(ChatMessageDB.created_at)
            .limit(1)
        )
        preview = preview_result.scalar_one_or_none()

        # Get message count
        count_result = await db.execute(
            select(func.count(ChatMessageDB.id))
            .where(ChatMessageDB.session_id == session.id)
        )
        message_count = count_result.scalar_one()

        session_list.append({
            "id": str(session.id),
            "mode": session.mode,
            "provider": session.provider,
            "model": session.model,
            "preview": (preview[:100] + "...") if preview and len(preview) > 100 else preview,
            "message_count": message_count,
            "created_at": session.created_at.isoformat(),
            "updated_at": session.updated_at.isoformat() if session.updated_at else None,
        })

    # Apply search filter if provided
    if search:
        search_lower = search.lower()
        session_list = [
            s for s in session_list
            if s["preview"] and search_lower in s["preview"].lower()
        ]

    return {
        "sessions": session_list,
        "total": len(session_list),
        "has_more": len(sessions) == limit,
    }


@router.get("/grouped")
async def get_sessions_grouped(
    db: AsyncSession = Depends(get_db),
):
    """Get sessions grouped by time period (Today, Yesterday, This Week, etc.)."""

    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    yesterday_start = today_start - timedelta(days=1)
    week_start = today_start - timedelta(days=7)
    month_start = today_start - timedelta(days=30)

    result = await db.execute(
        select(ChatSessionDB)
        .order_by(desc(ChatSessionDB.updated_at))
        .limit(100)
    )
    sessions = result.scalars().all()

    groups = {
        "today": [],
        "yesterday": [],
        "this_week": [],
        "this_month": [],
        "older": [],
    }

    for session in sessions:
        updated = session.updated_at or session.created_at

        # Get preview
        preview_result = await db.execute(
            select(ChatMessageDB.content)
            .where(ChatMessageDB.session_id == session.id)
            .where(ChatMessageDB.role == "user")
            .order_by(ChatMessageDB.created_at)
            .limit(1)
        )
        preview = preview_result.scalar_one_or_none()

        session_data = {
            "id": str(session.id),
            "preview": (preview[:60] + "...") if preview and len(preview) > 60 else preview,
            "mode": session.mode,
            "updated_at": updated.isoformat(),
        }

        if updated >= today_start:
            groups["today"].append(session_data)
        elif updated >= yesterday_start:
            groups["yesterday"].append(session_data)
        elif updated >= week_start:
            groups["this_week"].append(session_data)
        elif updated >= month_start:
            groups["this_month"].append(session_data)
        else:
            groups["older"].append(session_data)

    return groups
```

### 3.2 Session Sidebar Component

**New file:** `apps/web/src/components/chat/SessionSidebar.tsx`

```typescript
'use client'

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { formatDistanceToNow } from 'date-fns'

interface SessionPreview {
  id: string
  preview: string | null
  mode: string
  updated_at: string
}

interface GroupedSessions {
  today: SessionPreview[]
  yesterday: SessionPreview[]
  this_week: SessionPreview[]
  this_month: SessionPreview[]
  older: SessionPreview[]
}

interface SessionSidebarProps {
  currentSessionId: string | null
  onSelectSession: (sessionId: string) => void
  onNewSession: () => void
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export function SessionSidebar({
  currentSessionId,
  onSelectSession,
  onNewSession,
}: SessionSidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)
  const queryClient = useQueryClient()

  const { data: groups, isLoading } = useQuery<GroupedSessions>({
    queryKey: ['sessions', 'grouped'],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/sessions/grouped`)
      if (!res.ok) throw new Error('Failed to load sessions')
      return res.json()
    },
    refetchInterval: 30000, // Refresh every 30s
  })

  const deleteSession = useMutation({
    mutationFn: async (sessionId: string) => {
      const res = await fetch(`${API_BASE}/chat/sessions/${sessionId}`, {
        method: 'DELETE',
      })
      if (!res.ok) throw new Error('Failed to delete session')
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sessions'] })
    },
  })

  const renderGroup = (title: string, sessions: SessionPreview[]) => {
    if (!sessions.length) return null

    return (
      <div className="mb-4">
        <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-2">
          {title}
        </h3>
        <ul className="space-y-1">
          {sessions.map((session) => (
            <li key={session.id}>
              <button
                onClick={() => onSelectSession(session.id)}
                className={`w-full text-left px-2 py-1.5 rounded-md text-sm truncate hover:bg-gray-100 group flex items-center justify-between ${
                  currentSessionId === session.id
                    ? 'bg-gray-100 font-medium'
                    : ''
                }`}
              >
                <span className="truncate flex-1">
                  {session.preview || 'New conversation'}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    if (confirm('Delete this conversation?')) {
                      deleteSession.mutate(session.id)
                    }
                  }}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 rounded"
                  title="Delete"
                >
                  <svg className="w-3 h-3 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </button>
            </li>
          ))}
        </ul>
      </div>
    )
  }

  if (isCollapsed) {
    return (
      <div className="w-12 border-r bg-gray-50 flex flex-col items-center py-4">
        <button
          onClick={() => setIsCollapsed(false)}
          className="p-2 hover:bg-gray-200 rounded-md"
          title="Expand sidebar"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
        <button
          onClick={onNewSession}
          className="p-2 hover:bg-gray-200 rounded-md mt-2"
          title="New conversation"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      </div>
    )
  }

  return (
    <div className="w-64 border-r bg-gray-50 flex flex-col h-full">
      {/* Header */}
      <div className="p-3 border-b flex items-center justify-between">
        <button
          onClick={onNewSession}
          className="flex items-center gap-2 px-3 py-1.5 bg-gray-900 text-white rounded-md text-sm hover:bg-gray-800"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          New Chat
        </button>
        <button
          onClick={() => setIsCollapsed(true)}
          className="p-1.5 hover:bg-gray-200 rounded-md"
          title="Collapse sidebar"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
      </div>

      {/* Session list */}
      <div className="flex-1 overflow-y-auto p-2">
        {isLoading ? (
          <div className="text-center text-gray-500 text-sm py-4">Loading...</div>
        ) : groups ? (
          <>
            {renderGroup('Today', groups.today)}
            {renderGroup('Yesterday', groups.yesterday)}
            {renderGroup('This Week', groups.this_week)}
            {renderGroup('This Month', groups.this_month)}
            {renderGroup('Older', groups.older)}
          </>
        ) : (
          <div className="text-center text-gray-500 text-sm py-4">
            No conversations yet
          </div>
        )}
      </div>
    </div>
  )
}
```

### 3.3 Updated Chat Page Layout

**Modify:** `apps/web/src/app/chat/page.tsx`

```typescript
'use client'

import { useState, useCallback } from 'react'
import { SessionSidebar } from '@/components/chat/SessionSidebar'
import { ChatContainer } from '@/components/chat/ChatContainer'

export default function ChatPage() {
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('chat_session_id')
    }
    return null
  })

  const handleSelectSession = useCallback((sessionId: string) => {
    setCurrentSessionId(sessionId)
    localStorage.setItem('chat_session_id', sessionId)
  }, [])

  const handleNewSession = useCallback(() => {
    setCurrentSessionId(null)
    localStorage.removeItem('chat_session_id')
  }, [])

  const handleSessionCreated = useCallback((sessionId: string) => {
    setCurrentSessionId(sessionId)
    localStorage.setItem('chat_session_id', sessionId)
  }, [])

  return (
    <div className="flex h-screen">
      {/* Left sidebar - Session list */}
      <SessionSidebar
        currentSessionId={currentSessionId}
        onSelectSession={handleSelectSession}
        onNewSession={handleNewSession}
      />

      {/* Main chat area */}
      <div className="flex-1 flex flex-col">
        <ChatContainer
          sessionId={currentSessionId}
          onSessionCreated={handleSessionCreated}
        />
      </div>
    </div>
  )
}
```

---

## Part 4: Skills Management UI

### 4.1 Skills Page

**New file:** `apps/web/src/app/skills/page.tsx`

```typescript
'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { SkillsList } from '@/components/skills/SkillsList'
import { SkillEditor } from '@/components/skills/SkillEditor'
import { CategoryFilter } from '@/components/skills/CategoryFilter'

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export default function SkillsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [editingSkillId, setEditingSkillId] = useState<string | null>(null)
  const [isCreating, setIsCreating] = useState(false)

  const { data: categories } = useQuery({
    queryKey: ['skills', 'categories'],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/skills/categories`)
      return res.json()
    },
  })

  return (
    <div className="flex h-screen">
      {/* Left sidebar - Categories */}
      <div className="w-56 border-r bg-gray-50 p-4">
        <h2 className="font-semibold mb-4">Categories</h2>
        <CategoryFilter
          categories={categories || {}}
          selected={selectedCategory}
          onSelect={setSelectedCategory}
        />
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b flex items-center justify-between">
          <div className="flex items-center gap-4">
            <input
              type="text"
              placeholder="Search skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="px-3 py-1.5 border rounded-md w-64"
            />
          </div>
          <button
            onClick={() => setIsCreating(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Create Skill
          </button>
        </div>

        {/* Skills list or editor */}
        <div className="flex-1 overflow-hidden flex">
          <div className={`${editingSkillId || isCreating ? 'w-1/2' : 'w-full'} overflow-y-auto p-4`}>
            <SkillsList
              category={selectedCategory}
              search={searchQuery}
              selectedId={editingSkillId}
              onSelect={setEditingSkillId}
            />
          </div>

          {(editingSkillId || isCreating) && (
            <div className="w-1/2 border-l overflow-y-auto">
              <SkillEditor
                skillId={isCreating ? null : editingSkillId}
                onClose={() => {
                  setEditingSkillId(null)
                  setIsCreating(false)
                }}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
```

### 4.2 Skills List Component

**New file:** `apps/web/src/components/skills/SkillsList.tsx`

```typescript
'use client'

import { useQuery } from '@tanstack/react-query'

interface Skill {
  id: string
  name: string
  description: string
  category: string
  source: string
  tags: string[]
}

interface SkillsListProps {
  category: string | null
  search: string
  selectedId: string | null
  onSelect: (id: string) => void
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

const CATEGORY_COLORS: Record<string, string> = {
  knowledge: 'bg-blue-100 text-blue-800',
  workflow: 'bg-green-100 text-green-800',
  analysis: 'bg-purple-100 text-purple-800',
  creation: 'bg-yellow-100 text-yellow-800',
  integration: 'bg-orange-100 text-orange-800',
  training: 'bg-red-100 text-red-800',
  productivity: 'bg-teal-100 text-teal-800',
  uncategorized: 'bg-gray-100 text-gray-800',
}

export function SkillsList({ category, search, selectedId, onSelect }: SkillsListProps) {
  const { data: skills, isLoading } = useQuery<Skill[]>({
    queryKey: ['skills', category, search],
    queryFn: async () => {
      const params = new URLSearchParams()
      if (category) params.set('category', category)
      if (search) params.set('search', search)

      const res = await fetch(`${API_BASE}/skills?${params}`)
      return res.json()
    },
  })

  if (isLoading) {
    return <div className="text-gray-500">Loading skills...</div>
  }

  if (!skills?.length) {
    return <div className="text-gray-500">No skills found</div>
  }

  // Group by category
  const grouped = skills.reduce((acc, skill) => {
    const cat = skill.category
    if (!acc[cat]) acc[cat] = []
    acc[cat].push(skill)
    return acc
  }, {} as Record<string, Skill[]>)

  return (
    <div className="space-y-6">
      {Object.entries(grouped).map(([cat, catSkills]) => (
        <div key={cat}>
          <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">
            {cat}
          </h3>
          <div className="grid gap-3">
            {catSkills.map((skill) => (
              <button
                key={skill.id}
                onClick={() => onSelect(skill.id)}
                className={`text-left p-3 rounded-lg border transition-colors ${
                  selectedId === skill.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-medium">{skill.name}</h4>
                    <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                      {skill.description}
                    </p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${CATEGORY_COLORS[skill.category] || CATEGORY_COLORS.uncategorized}`}>
                    {skill.source}
                  </span>
                </div>
                {skill.tags.length > 0 && (
                  <div className="flex gap-1 mt-2 flex-wrap">
                    {skill.tags.slice(0, 3).map((tag) => (
                      <span key={tag} className="text-xs bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">
                        {tag}
                      </span>
                    ))}
                    {skill.tags.length > 3 && (
                      <span className="text-xs text-gray-400">+{skill.tags.length - 3}</span>
                    )}
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
```

### 4.3 Skill Editor Component

**New file:** `apps/web/src/components/skills/SkillEditor.tsx`

```typescript
'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'

interface SkillDetail {
  id: string
  name: string
  description: string
  when_to_use: string
  category: string
  tags: string[]
  content: string
  source: string
}

interface SkillEditorProps {
  skillId: string | null
  onClose: () => void
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

const CATEGORIES = [
  'knowledge', 'workflow', 'analysis', 'creation',
  'integration', 'training', 'productivity', 'uncategorized'
]

export function SkillEditor({ skillId, onClose }: SkillEditorProps) {
  const queryClient = useQueryClient()
  const isNew = skillId === null

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    when_to_use: '',
    category: 'uncategorized',
    tags: [] as string[],
    content: '',
  })
  const [tagInput, setTagInput] = useState('')

  // Load existing skill
  const { data: skill, isLoading } = useQuery<SkillDetail>({
    queryKey: ['skill', skillId],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/skills/${skillId}`)
      if (!res.ok) throw new Error('Failed to load skill')
      return res.json()
    },
    enabled: !!skillId,
  })

  // Update form when skill loads
  useEffect(() => {
    if (skill) {
      setFormData({
        name: skill.name,
        description: skill.description,
        when_to_use: skill.when_to_use,
        category: skill.category,
        tags: skill.tags,
        content: skill.content,
      })
    }
  }, [skill])

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const res = await fetch(`${API_BASE}/skills`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })
      if (!res.ok) throw new Error('Failed to create skill')
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] })
      onClose()
    },
  })

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const res = await fetch(`${API_BASE}/skills/${skillId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })
      if (!res.ok) throw new Error('Failed to update skill')
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] })
      queryClient.invalidateQueries({ queryKey: ['skill', skillId] })
    },
  })

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/skills/${skillId}`, {
        method: 'DELETE',
      })
      if (!res.ok) throw new Error('Failed to delete skill')
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] })
      onClose()
    },
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (isNew) {
      createMutation.mutate(formData)
    } else {
      updateMutation.mutate(formData)
    }
  }

  const handleAddTag = () => {
    if (tagInput && !formData.tags.includes(tagInput)) {
      setFormData({ ...formData, tags: [...formData.tags, tagInput] })
      setTagInput('')
    }
  }

  const handleRemoveTag = (tag: string) => {
    setFormData({ ...formData, tags: formData.tags.filter((t) => t !== tag) })
  }

  const isReadOnly = skill?.source !== 'database' && !isNew

  if (isLoading) {
    return <div className="p-4">Loading...</div>
  }

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">
          {isNew ? 'Create Skill' : isReadOnly ? 'View Skill' : 'Edit Skill'}
        </h2>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {isReadOnly && (
        <div className="mb-4 p-2 bg-yellow-50 text-yellow-800 text-sm rounded">
          This skill is stored in the filesystem and can only be viewed here.
          Edit the SKILL.md file directly to make changes.
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Name</label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
            disabled={isReadOnly}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Description</label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-3 py-2 border rounded-md h-20"
            disabled={isReadOnly}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">When to Use</label>
          <textarea
            value={formData.when_to_use}
            onChange={(e) => setFormData({ ...formData, when_to_use: e.target.value })}
            className="w-full px-3 py-2 border rounded-md h-20"
            disabled={isReadOnly}
            placeholder="Describe when this skill should be triggered..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Category</label>
          <select
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
            disabled={isReadOnly}
          >
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Tags</label>
          <div className="flex gap-2 mb-2 flex-wrap">
            {formData.tags.map((tag) => (
              <span key={tag} className="flex items-center gap-1 px-2 py-1 bg-gray-100 rounded text-sm">
                {tag}
                {!isReadOnly && (
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ×
                  </button>
                )}
              </span>
            ))}
          </div>
          {!isReadOnly && (
            <div className="flex gap-2">
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                className="flex-1 px-3 py-2 border rounded-md"
                placeholder="Add tag..."
              />
              <button
                type="button"
                onClick={handleAddTag}
                className="px-3 py-2 border rounded-md hover:bg-gray-50"
              >
                Add
              </button>
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Content (Markdown)</label>
          <textarea
            value={formData.content}
            onChange={(e) => setFormData({ ...formData, content: e.target.value })}
            className="w-full px-3 py-2 border rounded-md h-64 font-mono text-sm"
            disabled={isReadOnly}
            required
          />
        </div>

        {!isReadOnly && (
          <div className="flex justify-between pt-4">
            {!isNew && (
              <button
                type="button"
                onClick={() => {
                  if (confirm('Are you sure you want to delete this skill?')) {
                    deleteMutation.mutate()
                  }
                }}
                className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-md"
              >
                Delete
              </button>
            )}
            <div className="flex gap-2 ml-auto">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                {isNew ? 'Create' : 'Save'}
              </button>
            </div>
          </div>
        )}
      </form>
    </div>
  )
}
```

### 4.4 Category Filter Component

**New file:** `apps/web/src/components/skills/CategoryFilter.tsx`

```typescript
interface CategoryFilterProps {
  categories: Record<string, number>
  selected: string | null
  onSelect: (category: string | null) => void
}

const CATEGORY_ICONS: Record<string, string> = {
  knowledge: '📚',
  workflow: '⚙️',
  analysis: '🔍',
  creation: '✏️',
  integration: '🔗',
  training: '💪',
  productivity: '⏱️',
  uncategorized: '📁',
}

export function CategoryFilter({ categories, selected, onSelect }: CategoryFilterProps) {
  const total = Object.values(categories).reduce((sum, n) => sum + n, 0)

  return (
    <ul className="space-y-1">
      <li>
        <button
          onClick={() => onSelect(null)}
          className={`w-full text-left px-2 py-1.5 rounded-md text-sm flex items-center justify-between ${
            selected === null ? 'bg-gray-200 font-medium' : 'hover:bg-gray-100'
          }`}
        >
          <span>All Skills</span>
          <span className="text-gray-500">{total}</span>
        </button>
      </li>
      {Object.entries(categories)
        .filter(([, count]) => count > 0)
        .sort((a, b) => b[1] - a[1])
        .map(([category, count]) => (
          <li key={category}>
            <button
              onClick={() => onSelect(category)}
              className={`w-full text-left px-2 py-1.5 rounded-md text-sm flex items-center justify-between ${
                selected === category ? 'bg-gray-200 font-medium' : 'hover:bg-gray-100'
              }`}
            >
              <span className="flex items-center gap-2">
                <span>{CATEGORY_ICONS[category] || '📁'}</span>
                <span className="capitalize">{category}</span>
              </span>
              <span className="text-gray-500">{count}</span>
            </button>
          </li>
        ))}
    </ul>
  )
}
```

---

## Part 5: Database Model Updates

**Modify:** `services/brain_runtime/models/db_models.py`

```python
# Add to existing file

class UserSkillDB(Base):
    """User-created skills stored in database."""
    __tablename__ = "user_skills"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    when_to_use = Column(Text, nullable=False)
    category = Column(String(50), nullable=False, default="uncategorized")
    tags = Column(JSON, default=list)
    content = Column(Text, nullable=False)
    version = Column(String(20))
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    deleted_at = Column(DateTime(timezone=True))  # Soft delete


class SkillUsageDB(Base):
    """Track skill usage for relevance scoring."""
    __tablename__ = "skill_usage"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    skill_id = Column(String(255), nullable=False)
    skill_source = Column(String(20), nullable=False)
    session_id = Column(UUID(as_uuid=True), ForeignKey("chat_sessions.id", ondelete="SET NULL"))
    matched_by = Column(String(20), nullable=False)  # "automatic" or "manual"
    relevance_score = Column(Float)
    used_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


# Update ChatSessionDB to track injected skills
class ChatSessionDB(Base):
    # ... existing fields ...

    # Add this field
    injected_skills = Column(JSON, default=list)  # Skills auto-injected during session
```

---

## Implementation Checklist

### Phase 7B-1: Skill Categorization (Complete)
- [x] Run database migration `002_add_skills_tables.sql`
- [x] Update `services/skills/models.py` with SkillCategory enum
- [x] Update `services/skills/scanner.py` with category extraction
- [x] Update `services/brain_runtime/api/skills.py` with CRUD endpoints
- [x] Test: `curl localhost:8000/skills/categories` ✓

### Phase 7B-2: Automatic Skill Discovery (Complete)
- [x] Create `core/skills/matcher.py`
- [x] Create `core/skills/injector.py`
- [x] Update `api/chat.py` to use automatic injection
- [x] Update `ChatSessionDB` to track injected skills
- [x] Test: Skill matching integrated with chat API

### Phase 7B-3: Session Sidebar (Complete)
- [x] Create `api/sessions.py` with grouped endpoints
- [x] Create `SessionSidebar.tsx` component
- [x] Update `app/chat/page.tsx` with new layout
- [x] Test: Sessions grouped by Today/Yesterday/This Week/etc. ✓

### Phase 7B-4: Skills Management UI (Complete)
- [x] Create `app/skills/page.tsx`
- [x] Create `SkillsList.tsx` component
- [x] Create `SkillEditor.tsx` component
- [x] Create `CategoryFilter.tsx` component
- [x] Navigation updated with Skills link

### Phase 7B-5: Testing & Polish (Complete)
- [x] Python lint: ruff passes with 0 errors
- [x] Frontend lint: ESLint passes with no warnings
- [x] Build: Next.js build succeeds
- [x] API endpoints verified working
- [x] Update CLAUDE.md with Phase 7B status

---

## Success Criteria

Phase 7B is complete when:

1. **Automatic Discovery**: Skills are matched to conversations without manual selection
2. **Progressive Loading**: Only metadata loaded upfront; content lazy-loaded
3. **Session Sidebar**: Claude-like left sidebar with grouped session history
4. **Skills CRUD**: Create, read, update, delete skills via UI
5. **Categorization**: Skills organized by category with filtering
6. **Token Efficiency**: Skill metadata <200 tokens, full injection <5K tokens per skill
7. **No Regressions**: All Phase 7A functionality still works

---

## Appendix: Token Budget Analysis

### Current Approach (Manual Checkbox)
- All 38 skills listed = ~3,800 tokens (names + descriptions)
- User selects 3 skills = ~6,000 tokens (full content)
- **Total**: ~9,800 tokens before conversation starts

### Phase 7B Approach (Progressive)
- Level 1 metadata = ~200 tokens (skill names only)
- Level 2 auto-injected (avg 2 skills) = ~3,000 tokens
- Level 3 resources = 0 tokens (filesystem access)
- **Total**: ~3,200 tokens (67% reduction)

### Tool Search Tool (Future)
- With Anthropic's Tool Search Tool beta
- All skills deferred = ~100 tokens
- LLM discovers relevant skills dynamically
- **Total**: ~100-3,000 tokens depending on usage
